<?php require APPROOT . '/views/inc/main_header.php'; ?>

    <main class="content">
        <div class="body-left">

                    
        </div>

        <div class="body-right">

        <form action="<?php echo URLROOT; ?>/users/reset_password" method="POST">        

        <div class="container-10">
            <h3 class="para-1">Recover password</h3>
                    <p class="para-2">Please enter your email to reset your password. You'll receive an email with instructions. If you are experiencing problems with remembering your email, please contact careU Pharmacy Platform Support.</p>
                    <label for="userEmail">Email<span style="color:red;">*</span></label><br>
                    <input type="email"  name="email" value="<?php echo $data['email']; ?>">
                    <!-- email error msg-->
                    <span style="color: red;"><?php echo $data['email_err'];?></span>
                    <br>
                    <br>
                    
                    
                    
                    <button type="submit" name="login" class="button-10" style="vertical-align:middle"><span>Send mail</span></button>
                    <br>
                    <!-- <php echo $msg; ?> -->
                    <br>
                    
            
        </div>
        </form>
        </div>

        
    </main>

    <!-- <script src="/public/js/flashmsg_view.js"></script> -->
    <script src="<?php echo URLROOT;?>/public/js/flashmsg_reset_pw.js"></script>

<?php require APPROOT . '/views/inc/footer.php'; ?>