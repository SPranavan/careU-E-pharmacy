<?php require APPROOT . '/views/inc/main_header.php'; ?>

<head>
    


    
</head>

<body>
<!-- <div class="slider">
      <ul>
      <li><img class="sli-img" src="<?php echo URLROOT;?>/public/img/pharmacist/pharm_6.jpg" /></li>
        <li><img class="sli-img" src="<?php echo URLROOT;?>/public/img/pharmacist/pharm_7.jpg" /></li>
        <li><img class="sli-img" src="<?php echo URLROOT;?>/public/img/pharmacist/pharmacy_2.jpg" alt="image two" /></li>
        <li><img class="sli-img" src="<?php echo URLROOT;?>/public/img/pharmacist/pharm_4.jpg" /></li>
        <li><img class="sli-img" src="<?php echo URLROOT;?>/public/img/pharmacist/pharm_5.jpg" /></li>
        <!-- <li><img src="/img3.jpg" alt="image three" /></li>
        <li><img src="/img4.jpg" alt="image four" /></li> -->
      <!-- </ul>
    </div> -->

    <!-- <script src="<?php echo URLROOT; ?>/public/js/slide.js"></script> --> -->
</body>
    <main class="content">
        <div class="body-left">

                    
        </div>

        <div class="body-right">

        <form action="<?php echo URLROOT; ?>/users/login" method="POST">        

        <div class="container-1">
            <h3 class="para-1">Already a customer ?</h3>
                    <p class="para-2">If you have an account with us, log in using your email address.</p>
                    <label for="userEmail">Email / Phone Number<span style="color:red;">*</span></label><br>
                    <input type="email"  name="email" value="<?php echo $data['email']; ?>">
                    <!-- email error msg-->
                    <span style="color: red;"><?php echo $data['email_err'];?></span>
                    <br>
                    <br>
                    
                    <label for="password">Password<span style="color:red;">*</span></label><br>
                    <input type="password" name="password" value="<?php echo $data['password']; ?>">
                    <!-- password error msg-->
                    <span style="color: red;"><?php echo $data['password_err']; ?></span>
                    <br>
                    <br>
                    
                    <button type="submit" name="login" class="button-2" style="vertical-align:middle"><span>Sign In</span></button>
                    <br>
                    <!-- <php echo $msg; ?> -->
                    <br>
                    <a href="#" class="fpw"><span>Forget your password?</span></a>
            
        </div>
        </form>
        </div>

        
    </main>
    <script src="<?php echo URLROOT;?>/public/js/flashmsg_view.js"></script>


<?php require APPROOT . '/views/inc/footer.php'; ?>