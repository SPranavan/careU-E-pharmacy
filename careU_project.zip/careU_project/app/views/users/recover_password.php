<?php require APPROOT . '/views/inc/main_header.php'; ?>

    <main class="content">
        <div class="body-left">

                    
        </div>

        <div class="body-right">

        <form action="<?php echo URLROOT; ?>/users/recover_password" method="POST">        

        <div class="container-10">
            <h3 class="para-1">Recover password</h3>
                    <p class="para-2">Please reset your password below.</p>
                    <label for="newpw">New Password*<span style="color:red;">*</span></label><br>
                    <input type="password"  name="password" value="<?php echo $data['password']; ?>">
                    <!-- email error msg-->
                    <span style="color: red;"><?php echo $data['password_err'];?></span>
                    <br>
                    <br>

                    <label for="connewpw">Confirm New Password*<span style="color:red;">*</span></label><br>
                    <input type="password"  name="confirm_password" value="<?php echo $data['confirm_password']; ?>">
                    <!-- email error msg-->
                    <span style="color: red;"><?php echo $data['confirm_password_err'];?></span>
                    <br>
                    <br>
                    
                    
                    
                    <button type="submit" name="reset" class="button-10" style="vertical-align:middle"><span>Reset passwrod</span></button>
                    <br>
                    <!-- <php echo $msg; ?> -->
                    <br>
                    
            
        </div>
        </form>
        </div>

        
    </main>

    <script src="<?php echo URLROOT;?>/public/js/flashmsg_view.js"></script>

<?php require APPROOT . '/views/inc/footer.php'; ?>