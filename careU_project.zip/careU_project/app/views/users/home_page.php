<?php require APPROOT . '/views/inc/home_header.php'; ?>

<head>
    <link rel="stylesheet" type="text/css" href="<?php echo URLROOT; ?>/public/css/pharmacists/slider.css">


    
</head>

<body>
<div class="slider">
      <ul>
      <li><img class="sli-img" src="<?php echo URLROOT;?>/public/img/pharmacist/pharm_6.jpg" /></li>
        <li><img class="sli-img" src="<?php echo URLROOT;?>/public/img/pharmacist/pharm_7.jpg" /></li>
        <li><img class="sli-img" src="<?php echo URLROOT;?>/public/img/pharmacist/pharmacy_2.jpg" alt="image two" /></li>
        <li><img class="sli-img" src="<?php echo URLROOT;?>/public/img/pharmacist/pharm_4.jpg" /></li>
        <li><img class="sli-img" src="<?php echo URLROOT;?>/public/img/pharmacist/pharm_5.jpg" /></li>
        <!-- <li><img src="/img3.jpg" alt="image three" /></li>
        <li><img src="/img4.jpg" alt="image four" /></li> -->
      </ul>
    </div>

    <script src="<?php echo URLROOT; ?>/public/js/slide.js"></script>

    <div class="meds">
    <div id="details" class="details">
    <?php
    $countdata = count($data);

    for ($i = 0; $i < $countdata; $i++) {
        if ($i % 2 == 0) {
            echo '
            <div class="box2">';
        }
        echo '
            <div class="box1">
            <img src="'.URLROOT.'/public/img/medicine/'.$data[$i]->image.'" alt="call">
            <p>Item name :<span class="data"> ' . $data[$i]->name . ' </span> </p>
                <p id="Heart">Price :<span class="data"> ' . $data[$i]->price . '</span> </p>
                
                <p>Quantity measure :<span class="data"> ' . $data[$i]->quantity_measurement . '</span> </p>
                <a href = "'.URLROOT.'/users/login"><button class="cart">Add to Cart</button></a>
            </div> ';

            if ($i % 2 == 1) {
                echo '
                </div>';
            }

    };


    
    ?>



</div>

    </div>
</body>

<?php require APPROOT . '/views/inc/footer.php'; ?>