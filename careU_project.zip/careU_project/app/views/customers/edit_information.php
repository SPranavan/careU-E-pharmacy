<?php require APPROOT . '/views/inc/customer_header.php'; ?>
<?php

// php code to Update data from mysql database Table

if(isset($_POST['update']))
{
    
$hostname = "localhost";
$username = "root";
$password = "";
$databaseName = "careu";

$connect = mysqli_connect($hostname, $username, $password, $databaseName);

// get values form input text and number

$user_ID = $_POST['user_ID'];
$mobile = $_POST['mobile'];
$email = $_POST['email'];
$address = $_POST['address'];
$city = $_POST['city'];
        
// mysql query to Update data
$query = "UPDATE `users` SET `mobile`='".$mobile."',`email`='".$email."',`address`= '".$address."',`city`= '".$city."'  WHERE `user_ID` = ".$user_ID;

$result = mysqli_query($connect, $query);

if($result)
{
    echo 'Data Updated';
}else{
    echo 'Data Not Updated';
}
mysqli_close($connect);
}

?>

<head>
<link rel="stylesheet" type="text/css" href="<?php echo URLROOT; ?>/public/css/customer/edit_information.css">  
</head>

    <main class="content">


    <div class="nav" id="nav-id">
    <ul>
        <li><img src="<?php echo URLROOT; ?>/public/img/customer/menu.png" class="img-nav" alt="account">
            <a href="<?php echo URLROOT; ?>/Customers/myaccount">Account Details</a></li>
        <li><img src="<?php echo URLROOT; ?>/public/img/customer/rotation-lock.png" class="img-nav" alt="pw">
            <a href="<?php echo URLROOT; ?>/Customers/change_password">Change Password</a></li>
        <li><img src="<?php echo URLROOT; ?>/public/img/customer/user1.png" class="img-nav" alt="details">
            <a href="<?php echo URLROOT; ?>/Customers/edit_information">Edit Details</a></li>
    </ul>
    </div>



    <div class="details">
    <h1>Edit Details</h1>
    <form method="POST" action="<?php echo URLROOT; ?>/Customers/edit_information/">
            <div class="data">
                <label for="">Email address</label><br>
                <input type="text" name="email" id="email" value="<?php echo $data['user']->email; ?>">
            </div>
            <div class="data">
                <label for="">Mobile number</label><br>
                <input type="text" name="mobile" id="mobile" value="<?php echo $data['user']->mobile; ?>">
            </div>
            <div class="data">
                <label for="">Address</label><br>
                <input type="text"  name="address" id="address" value="<?php echo $data['user']->address; ?>">
            </div>
            <div class="data">
                <label for="">City</label><br>
                <input type="text"  name="city" id="city" value="<?php echo $data['user']->city; ?>">
            </div>
            <input type="submit" class="data-btn" value="Update">
    </form>

</div>



   





































<!-- 
      
            <div class="form-div-outer form-div">
            <form action="php_update_data_from_mysql_database_table.php" method="post">

                ID To Update: <input type="text" name="user_ID" required><br><br>

                New Mobile Number: <input type="tel" name="mobile"><br><br>

                New Email: <input type="email" name="email"><br><br>

                New Address: <input type="text" name="address"><br><br>

                New City: <select id="city" name="city">
                            <option value="Kandy">Kandy</option>
                            <option value="Colombo">Colombo</option>
                            <option value="Jaffna">Jaffna</option>
                          </select><br><br>

                <input type="submit" name="update" value="Update Data">

            </form>
            </div> -->
                

           




























        

<!-- <p class="p-edit">Edit Account</p>

<div class="edit-box-information">

<form method="POST">
    
    <label class="label-edit" for="name">Name</label><br>
    <input type="text" class="input-edit" id="name" name="name"><br>
    <label class="label-edit" style="top: 100px;" for="number">Mobile Number</label><br>
    <input type="text" class="input-edit" style="margin: 80px 0px;" id="number" name="number"><br>

    <div class="change">
        <a href="change_username">Change Username</a><br>
        <a href="change_email">Change Email</a><br>
        <a href="change_password">Change Passwoed</a><br>
        <a href="change_address"><b>Change Address</b></a>
    </div>
    

</form>

<div class="edit-box-changeusername">

<form method="POST">
    
    <label class="label-edit" for="name">New Address</label><br>
    <input type="text" class="input-edit" id="name" name="name"><br>
    <label class="label-edit" style="top: 110px;" for="number">City</label><br>
    <input type="text" class="input-edit" style="margin: 80px 0px;" id="number" name="number"><br>

    <button class="change-button">Save</button>

    
    

</form>

</div>
 -->
        
    </main>


<?php require APPROOT . '/views/inc/footer.php'; ?>