<?php require APPROOT . '/views/inc/customer_header.php'; ?>

<head>
<link rel="stylesheet" type="text/css" href="<?php echo URLROOT; ?>/public/css/customer/feedback.css">
</head>

    <main class="content">
        
        <div class="form-div-outer form-div">
            <h1>Feedback Form</h1>
            <form action="<?php echo URLROOT;?>/Customers/feedback_upload" method="POST">
                <label for="message">Message:</label>
                <textarea id="message" name="message" placeholder="Enter your feedback" required></textarea>

                <input type="submit" name="submit" value="Submit">
            </form>

        </div>
    
    </main>



<?php require APPROOT . '/views/inc/footer.php'; ?>