<?php require APPROOT . '/views/inc/customer_header.php'; ?>


<head>
<link rel="stylesheet" type="text/css" href="<?php echo URLROOT; ?>/public/css/customer/myaccount.css">
</head>

    <main class="content">
        
    
<!-- <p class="p-myaccount">My Account</p>

<div class="form-div-outer form-div">
    
                
                    <p>Name : <?php echo $data['user']->fName. " " . $data['user']->lName; ?></p>
                    <p>Email : <?php echo $data['user']->email; ?></p>
                    <p>Birth Date : <?php echo $data['user']->birthDate; ?><p>
                    <p>Mobile Number : <?php echo $data['user']->mobile; ?></p>
                    <p>Address : <?php echo $data['user']->address. " " . $data['user']->city; ?></p>
                
        
    

        <div class="change-myaccount">
            <a href="<?php echo URLROOT; ?>/Customers/edit_information" class="a-myaccount">Edit Details</a>
        </div>

</div> -->





 







<div class="nav">
    <ul>
        <li><img src="<?php echo URLROOT; ?>/public/img/customer/menu.png" class="img-nav" alt="account">
            <a href="<?php echo URLROOT; ?>/Customers/myaccount">Account Details</a></li>
        <li><img src="<?php echo URLROOT; ?>/public/img/customer/rotation-lock.png" class="img-nav" alt="pw">
            <a href="<?php echo URLROOT; ?>/Customers/change_password">Change Password</a></li>
        <li><img src="<?php echo URLROOT; ?>/public/img/customer/user1.png" class="img-nav" alt="details">
            <a href="<?php echo URLROOT; ?>/Customers/edit_information">Edit Details</a></li>
    </ul>
</div>






 
<div class="details">
    <h1>Account Details</h1>
    <div class="data">
        <label for="">Name</label><br>
        <input type="text" value="<?php echo $data['user']->fName." ".$data['user']->lName; ?>" readonly>
    </div>
    <div class="data">
        <label for="">Email address</label><br>
        <input type="text" value="<?php echo $data['user']->email; ?>" readonly >
    </div>
    <div class="data">
        <label for="">BirthDate</label><br>
        <input type="text" value="<?php echo $data['user']->birthDate; ?>" readonly>
    </div>
    <div class="data">
        <label for="">Mobile number</label><br>
        <input type="text" value="<?php echo $data['user']->mobile; ?>" readonly >
    </div>
    <div class="data">
        <label for="">Address</label><br>
        <input type="text" value="<?php echo $data['user']->address. ", " . $data['user']->city; ?>" readonly>
    </div>

</div>


</body>





    



        
    </main>


<?php require APPROOT . '/views/inc/footer.php'; ?>