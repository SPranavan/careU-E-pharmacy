<?php require APPROOT . '/views/inc/customer_header.php'; ?>

<head>
<link rel="stylesheet" type="text/css" href="<?php echo URLROOT; ?>/public/css/customer/change_password.css">
</head>

    <main class="content">
        
    
    <div class="nav">
    <ul>
        <li><img src="<?php echo URLROOT; ?>/public/img/customer/menu.png" class="img-nav" alt="account">
            <a href="<?php echo URLROOT; ?>/Customers/myaccount">Account Details</a></li>
        <li><img src="<?php echo URLROOT; ?>/public/img/customer/rotation-lock.png" class="img-nav" alt="pw">
            <a href="<?php echo URLROOT; ?>/Customers/change_password">Change Password</a></li>
        <li><img src="<?php echo URLROOT; ?>/public/img/customer/user1.png" class="img-nav" alt="details">
            <a href="<?php echo URLROOT; ?>/Customers/edit_information">Edit Details</a></li>
    </ul>
</div>



<div class="details">
    <h1>Change Password</h1>
    <form action="./update_pw" method="POST">
        <div class="data">
            <label for="">Current Password</label><br>
            <input name="cur_pw" type="password" value="">
            <?php
                if (isset($_SESSION['error1'])) {
                    echo '<span>'.$_SESSION["error1"].'</span>';
                    unset($_SESSION['error1']);
                }
            ?>
        </div>
        <div class="data">
            <label for="">New Password</label><br>
            <input name="new_pw" type="password" value="">
        </div>
        <div class="data">
            <label for="">Confirm New Password</label><br>
            <input name="con_pw" type="password" value="">
            <?php
                if (isset($_SESSION['error2'])) {
                    echo '<span class="error2">'.$_SESSION["error2"].'</span>';
                    unset($_SESSION['error2']);
                }
    
            ?>
            
        </div>
        
        <button type="submit" >Update</button>
    </form>

</div>






    </main>


<?php require APPROOT . '/views/inc/footer.php'; ?>