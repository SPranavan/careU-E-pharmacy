<?php
// print_r($data);die();
 require APPROOT . '/views/inc/customer_header.php'; 
?>

<head>
<link rel="stylesheet" type="text/css" href="<?php echo URLROOT; ?>/public/css/customer/checkout.css">
</head>

    <main class="content">

    <div class="cart-heading">
        <h1>Cart</h1>   
    </div>

    <div class="outer-div inner-div">
        <!-- <div class="inner-div"> -->
            
        <table style="width:100%">
        <tr>
            <th>Product</th>
            <th>Price</th>
            <th>Quantity</th>
            <th>Subtotal</th>
            <th></th>
        </tr>

        <?php  foreach ($data['medicine'] as $row) { ?>
            
        
        <tr>
            <td><?php echo $row->name ?></td>
            <td><?php echo $row->price ?></td>
            <td>
                <form action="<?php echo URLROOT; ?>/customers/updatecart/<?php echo $row->cartID ?>" method="post">
                
                <input type="number" min="1" max="20" name="quantity" value="<?php echo $row->quantity ?>" required>
                <button class="update" type="submit">Update</button>
                </form>
            </td>
            <td><?php echo number_format($row->price * $row->quantity, 2)?></td>
            <td>
                <!-- <a class="delete" href='<?php echo URLROOT; ?>/customers/deletecart/<?php echo $row->cartID ?>'>Delete</a> -->
                <button class="delete" onclick="location.href='<?php echo URLROOT; ?>/customers/deletecart/<?php echo $row->cartID ?>'">Delete</button>

            </td>
        </tr>
    <?php } ?>
               
</table>

    <div>
        <button class="return-cart" onclick="window.location.href='order';">Return To Shop</button>
    </div>
        <!-- </div> -->

    </div>


    <!-- <?php
        // $_SESSION['order_id'] = strval($data['order']->orderID);
        $_SESSION['amount'] = $data['sub_total'];
        $_SESSION['item'] = $row->name;
        $_SESSION['orderID'] = $row->orderID;
    ?> -->


    <div class="payment-box">
        <h3>SUMMARY</h3>
        <p>Subtotal: Rs.<?php echo $data['sub_total'] ?></p>
        <p>Delivery Fee: Rs.300</p>
        <p>Order Total: Rs.<?php echo $data['sub_total']+300 ?></p>
        <button class="checkout" onclick="paymentgateway()">Proceed to Checkout</button>
    </div>

    <script src="<?php echo URLROOT;?>/public/js/payment.js"></script>
    
    <script type="text/javascript" src="https://www.payhere.lk/lib/payhere.js"></script>
    

    </main>

<?php require APPROOT . '/views/inc/footer.php'; ?>
