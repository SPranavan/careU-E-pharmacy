<?php
// print_r($data);die();
 require APPROOT . '/views/inc/customer_header.php'; 
?>

<head>
<link rel="stylesheet" type="text/css" href="<?php echo URLROOT; ?>/public/css/customer/order_details.css">
</head>

    <main class="content">

    <div class="cart-heading">
        <h1>Order Details</h1>   
    </div>

    <div class="outer-div inner-div">
        <!-- <div class="inner-div"> -->
            
        <table style="width:100%">
        <tr>
            <th>Date</th>
            <th>Order Status</th>
            <th>Payment Status</th>
            <th>Delivery Status</th>
            <th>Packing Status</th>
            <th>Cancel Order</th>
        </tr>

        <?php  foreach ($data['medicine'] as $row) { ?>
            
        
        <tr>
            <td><?php echo $row->date ?></td>
            <td><?php echo $row->order_status ?></td>
            <td><?php echo $row->payment_status ?></td>
            <td><?php echo $row->delivery_status?></td>
            <td><?php echo $row->packing_status?></td>
            <td>
                <!-- <a class="delete" href='<?php echo URLROOT; ?>/customers/cancelorder/<?php echo $row->orderID ?>'>Cancel Order</a> -->
                <!-- <button class="delete" onclick="location.href='<?php echo URLROOT; ?>/customers/cancelorder/<?php echo $row->cartID ?>'">Cancel Order</button> -->
                <form method="post" action="<?php echo URLROOT; ?>/customers/cancelorder/<?php echo $row->orderID ?>">
                <button type="submit" class="delete">Cancel Order</button>
                </form>


            </td>
        </tr>
    <?php } ?>
               
</table>


        </div>







    

    </main>

<?php require APPROOT . '/views/inc/footer.php'; ?>
