<?php require APPROOT . '/views/inc/customer_header.php'; ?>

    <main class="content">
        
        <img class="home_logo" src="<?php echo URLROOT;?>/public/img/customer/delivery.png" alt="home_logo">
        
    </main>


<?php require APPROOT . '/views/inc/footer.php'; ?>