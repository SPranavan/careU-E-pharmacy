<?php require APPROOT . '/views/inc/customer_header.php'; 
// print_r($_POST['medicineID']);
?>

<head>
    <link rel="stylesheet" type="text/css" href="<?php echo URLROOT; ?>/public/css/customer/order.css">
    <link rel="stylesheet" type="js" href="<?php echo URLROOT; ?>/public/js/search.js">
</head>

<main class="content">

    <!-- <div>
        <input type="text" placeholder="Search for products....." id="search-input">
    </div> -->

    <?php if (!empty($data) && is_array($data)) : // Check if $data is not empty and is an array ?>
        <?php foreach ($data as $dataArray) : // Loop through each data array ?>
            <div class="details">
            <?php if (!empty($dataArray['title'])) : ?>
                <h2 class=""><?php echo $dataArray['title']; ?></h2>
            <?php endif; ?>
            <div class="full-details">
                <?php if (!empty($dataArray['items']) && is_array($dataArray['items'])) : ?>
                    <?php foreach ($dataArray['items'] as $item) : // Loop through each item in the current data array ?>


                    <div class="box1"> 
                        <form method="POST" action="<?php echo URLROOT ?>/Customers/order_upload">
                        <!-- <img class="img-icon" src="<?php echo URLROOT;?>/public/img/customer/milk.jpg" alt="milk powder"> -->
                        <!-- <span class="data"><?php echo $item->image; ?></span> -->
                        <img src="<?php echo URLROOT; ?>/public/img/medicine/<?php echo $item->image; ?>" alt="call">
                        <p class="hidden">ID: <span class="data"><?php echo $item->medicineID; ?></span></p>
                        <p>Item Name: <span class="data"><?php echo $item->name; ?></span></p>
                        <p>Quantity: <span class="data"><?php echo $item->quantity_measurement; ?></span></p>
                        <p>Price: Rs   <span class="data"><?php echo $item->price; ?></span></p>
                            <input type="hidden" name="medicineID" value="<?php echo $item->medicineID; ?>">
                            <input type="hidden" name="name" value="<?php echo $item->name; ?>">
                            <input type="hidden" name="price" value="<?php echo $item->price; ?>">
                            <input type="submit" name="addCart" class="cart-button" value="Add to Cart">


                        </form>
                    </div>




                       

                    <?php endforeach; ?>
                <?php else : ?>
                    <p>No data available.</p> <!-- Display an error message if $dataArray['items'] is empty or not an array -->
                <?php endif; ?>

            </div>
            </div>

        <?php endforeach; ?>
    <?php else : ?>
        <p>No data available.</p> <!-- Display an error message if $data is empty or not an array -->
    <?php endif; ?>
    

</main>

<?php require APPROOT . '/views/inc/footer.php'; ?>
