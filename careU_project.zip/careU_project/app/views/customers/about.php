<?php require APPROOT . '/views/inc/customer_header.php'; ?>

<head>
<link rel="stylesheet" type="text/css" href="<?php echo URLROOT; ?>/public/css/customer/feedback.css">
</head>

    <main class="content">
        
    <div class="contact1 contact-div">
            <h2>About Us</h2>
            <p>
                <strong>CareU Pharmacy</strong>
            </p>
            <p>
            35 Reid Ave, Colombo 00700, Sri Lanka
            </p>
            <p>
                <strong>Telephone </strong>: (+94) 099 888 1234 / (+94) 099 888 5678
            </p>
            <!-- <p>
                <strong>Hotline </strong>: (+94) 021 223 0626
            </p> -->
            <p>
                <strong>Email </strong>: careU.meds@gmail.com
            </p>
            
        </div>

        <p>
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3960.902976870189!2d79.85857797488613!3d6.902205493097124!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3ae25963120b1509%3A0x2db2c18a68712863!2sUniversity%20of%20Colombo%20School%20of%20Computing%20(UCSC)!5e0!3m2!1sen!2slk!4v1683214489975!5m2!1sen!2slk" width="1200" height="600" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
        </p>
    
    </main>


<?php require APPROOT . '/views/inc/footer.php'; ?>