<?php require APPROOT . '/views/admins/admin_header2.php'; ?>

    <main class="content">
    
    <div>
    <img class="adminLogo1" src="<?php echo URLROOT;?>/public/img/admins/Admin.png" alt="AdminLogo">

    <div>
        <div class="btnset1">
        <a href="<?php echo URLROOT; ?>/admins/view_manager"><button class="dashbtn1">Manager<br><hr><h3><?php echo $data['count_manager'] ?></h3></button></a>
        <a href="<?php echo URLROOT; ?>/admins/view_pharmacist"><button class="dashbtn2">Pharmacists<br><hr><h3><?php echo $data['count_pharmacist'] ?></h3></button></a>
        </div>
        <div class="btnset2">
        <a href="<?php echo URLROOT; ?>/admins/view_storekeeper"><button class="dashbtn1">Store Keepers<br><hr><h3><?php echo $data['count_storekeeper'] ?></h3></button></a>
        <a href="<?php echo URLROOT; ?>/admins/view_deliveryperson"><button class="dashbtn2">Delivery Drivers<br><hr><h3><?php echo $data['count_deliveryperson'] ?></h3></button></a>
        </div>
        <div class="btnset3">
        <a href="<?php echo URLROOT; ?>/admins/view_customer"><button class="dashbtn">Customers<br><br><hr><h3><?php echo $data['count_customer'] ?></h3></button></a>
        </div>
    </div>

    </div>
     <!-- Dashboard Body -->
      <!-- Dashboard Body -->
    <div class="dashboard">
        <!-- User Overview -->
  <div class="user-overview">
  <h2>User Overview</h2>
  <table>
    <tr>
      <th>Users</th>
      <th>Customers</th>
      <th>Managers</th>
      <th>Delivery Drivers</th>
      <th>Storekeepers</th>
      <th>Pharmacist</th>
    </tr>
    <tr>
      <td id="x">Total</td>
      <td id="total-customers"><?php echo $data['count_customerTot'] ?></td>
      <td id="total-managers"><?php echo $data['count_managerTot'] ?></td>
      <td id="total-drivers"><?php echo $data['count_deliverypersonTot'] ?></td>
      <td id="total-storekeepers"><?php echo $data['count_storekeeperTot'] ?></td>
      <td id="total-pharmacists"><?php echo $data['count_pharmacistTot'] ?></td>
    </tr>
    <tr>
      <td id="x">Active</td>
      <td id="active-customers"><?php echo $data['count_customer'] ?></td>
      <td id="active-managers"><?php echo $data['count_manager'] ?></td>
      <td id="active-drivers"><?php echo $data['count_deliveryperson'] ?></td>
      <td id="active-storekeepers"><?php echo $data['count_storekeeper'] ?></td>
      <td id="active-pharmacists"><?php echo $data['count_pharmacist'] ?></td>
    </tr>
    <tr>
      <td id="x">Deactivated</td>
      <td id="deactivated-customers"><?php echo $data['count_customerDe'] ?></td>
      <td id="deactivated-managers"><?php echo $data['count_managerDe'] ?></td>
      <td id="deactivated-drivers"><?php echo $data['count_deliverypersonDe'] ?></td>
      <td id="deactivated-storekeepers"><?php echo $data['count_storekeeperDe'] ?></td>
      <td id="deactivated-pharmacists"><?php echo $data['count_pharmacistDe'] ?></td>
    </tr>
  </table>
</div>


        <!-- Audit Logs -->
        <div class="audit-logs">
            <h2>Audit Logs</h2>
            <hr>
            <ul id="audit-log-list">
                <?php foreach ($data['users'] as $user): ?>
                    <li>&nbsp&nbsp<?php echo $user->fName; ?> <?php echo $user->lName; ?> created user account on <?php echo date('F d, Y', strtotime($user->joinedDate)); ?></li>
                <?php endforeach; ?>
            </ul>
        </div>

        

        <!-- Reporting -->
        <div class="reporting">
    <h2>Reporting</h2>
    
    <button id="generate-report-btn">Generate Report</button>
    <div id="report-results">
        <h3>Active Users Report</h3>
        <hr>
        <p>Number of active users in the last 30 days:<b> <?php echo $data['activeUsersCount']; ?></b></p>
        <p>Report generated on: <b><?php echo $data['currentDate']; ?></b></p>
    </div>
    </div>

        

        
    </main>

    


<?php require APPROOT . '/views/inc/footer.php'; ?>