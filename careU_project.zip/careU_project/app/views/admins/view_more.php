<?php require APPROOT . '/views/admins/admin_header2.php'; ?>



    <main class="content" >

    <div id="blur" class="container">
    <h3 class="viewer-name"><?php echo $data['userRole']->userRole; ?></h3>
    <div class="box3">

                <div class="dropdown_area" style="background-image: url(
                            <?php 
                                if($_SESSION['profile'] != null){
                                    echo URLROOT. "/public/img/user-pics/". $_SESSION['profile'];
                                }else{
                                    echo URLROOT. "/public/img/user-pics/user_public.jpg";
                                }
                            ?>); width: 230px; height: 230px;">
                </div>
        
        
    </div>

    
        <div class="body-right-view">

                <div class="container3">

                <form action="<?php echo URLROOT; ?>/admins/view_more" method="POST">
                    <div class="row">
                    <div class="col-25">
                        <label for="empID">Employee ID:</label>
                    </div>
                    <div class="col-75">
                        <input type="text" id="empID" name="user_ID" value="<?php echo $data['user_details']->user_ID; ?>" readonly>
                        <br><br>
                    </div>
                    </div> 

                    <div class="row">
                    <div class="col-25">
                        <label for="fname">First Name:</label>
                    </div>
                    <div class="col-75">
                        <input type="text" id="fname" name="fName" value="<?php echo $data['user_details']->fName; ?>" readonly><br>
                        
                        <br>
                    </div>
                    </div>

                    <div class="row">
                    <div class="col-25">
                        <label for="lname">Last Name:</label>
                    </div>
                    <div class="col-75">
                        <input type="text" id="lname" name="lName" value="<?php echo $data['user_details']->lName; ?>" readonly><br>
                        <br>
                    </div>
                    </div>

                    <div class="row">
                    <div class="col-25">
                        <label for="birthDate">Birth Date:</label>
                    </div>
                    <div class="col-75">
                        <input type="date" id="birthDate" name="birthDate" value="<?php echo $data['user_details']->birthDate; ?>" readonly><br>
                        <br>
                    </div>
                    </div>

                    <div class="row">
                    <div class="col-25">
                        <label for="age">Age:</label>
                    </div>
                    <div class="col-75">
                        <input type="number" id="age" name="age" value="<?php echo $data['age']->age; ?>" readonly><br>
                        <br>
                    </div>
                    </div>

                    <div class="row">
                    <div class="col-25">
                        <label for="telNo">Mobile Number:</label>
                    </div>
                    <div class="col-75">
                        <input type="tel" id="telNo" name="mobile" value="<?php echo $data['user_details']->mobile; ?>" placeholder="07Xxxxxxxx" readonly><br>
                        <br>
                    </div>
                    </div>

                    <div class="row">
                    <div class="col-25">
                        <label for="mail">Email:</label>
                    </div>
                    <div class="col-75">
                        <input type="email" id="mail" name="email" value="<?php echo $data['user_details']->email; ?>" readonly><br>
                        <br>
                    </div>
                    </div>

                    <div class="row">
                    <div class="col-25">
                        <label for="sa">Street Address:</label>
                    </div>
                    <div class="col-75">
                        <input type="text" id="sa" name="address" value="<?php echo $data['user_details']->address; ?>" readonly><br>
                        <br>
                    </div>
                    </div>

                    <div class="row">
                    <div class="col-25">
                        <label for="city">City:</label>
                    </div>
                    <div class="col-75">
                        <input type="text" id="city" name="city" value="<?php echo $data['user_details']->city; ?>" readonly><br>
                        <br>
                    </div>
                    </div>

                    <div class="row">
                    <div class="col-25">
                        <label for="joinedDate">Joined Date:</label>
                    </div>
                    <div class="col-75">
                        <input type="datetime-local" id="joinedDate" name="joinedDate" value="<?php echo $data['user_details']->joinedDate; ?>" readonly><br>
                        <br><br>
                    </div>
                    </div>

                    <div class="row">
                    <div class="col-25">
                        <label for="status">Active Status:</label>
                    </div>
                    <div class="col-75">
                        <input type="text" id="status" name="status" value="<?php echo $data['user_details']->active_status; ?>" readonly><br>
                        <br>
                    </div>
                    </div>

                    
                    
                    
            </form>

         

            <form id="confirmationForm" action="<?php echo URLROOT; ?>/admins/user_account_status" method="POST">
                <div class="row">
                    <input type="hidden" name="user_ID" value="<?php echo $data['user_details']->user_ID;?>">
                    <input type="hidden" name="user_role" value="<?php echo $data['user_details']->user_role;?>">
                    <input type="hidden" name="status" value="<?php echo $data['user_details']->active_status;?>">
                    <a href="<?php echo URLROOT; ?>/admins/view_<?php echo ($data['user_details']->user_role); ?>" class="goback"><span>Back</span></a>

                    <button id="submitBtn">
                        <?php if(($data['user_details']->active_status)=='Active'){
                            echo ("Delete Account");
                        }
                        elseif(($data['user_details']->active_status)=='Deactivated'){
                            echo ("Activate Account");
                        }
                        ; ?>
                    </button>
                </div>
            </form>

            <div id="popup" class="popup">
            <div class="popup-content">
            <h2>Confirmation</h2>
            <p>Are you sure you want to proceed?</p>
            <div class="input-container">
                <textarea id="popupTextarea" name="popupTextarea" placeholder="Please provide a reason:"></textarea>
            </div>
            <div class="button-container">
                <button id="cancelBtn">Cancel</button>
                <button id="confirmBtn">Confirm</button>
            </div>
        </div>


            </div>

        </div>
          
        </div>
    </div>

    <script>
    const submitBtn = document.getElementById('submitBtn');
    const confirmBtn = document.getElementById('confirmBtn');
    const cancelBtn = document.getElementById('cancelBtn');
    const popup = document.getElementById('popup');
    const popupTextarea = document.getElementById('popupTextarea');

    submitBtn.addEventListener('click', function(event) {
        event.preventDefault();
        popup.style.display = 'block';
    });

    confirmBtn.addEventListener('click', function() {
        // Get the textarea value
        const reason = popupTextarea.value.trim();

        if (reason === '') {
            alert('Please provide a reason.');
            return;
        }

        // Set the textarea value to a hidden field in the form
        const hiddenField = document.createElement('input');
        hiddenField.setAttribute('type', 'hidden');
        hiddenField.setAttribute('name', 'popupTextarea');
        hiddenField.setAttribute('value', reason);
        document.getElementById('confirmationForm').appendChild(hiddenField);

        // Submit the form
        document.getElementById('confirmationForm').submit();
    });

    cancelBtn.addEventListener('click', function() {
        popup.style.display = 'none';
    });
</script>


   
    

        
       
    </main>

    

            
     

    


<?php require APPROOT . '/views/inc/footer.php'; ?>

