<?php require APPROOT . '/views/inc/manager_header.php'; ?>

    <head>
        <link rel="stylesheet" type="text/css" href="<?php echo URLROOT; ?>/public/css/managers/report.css">
        <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
        <link rel="stylesheet" type="text/css" href="<?php echo URLROOT; ?>/public/css/managers/manager_footer_report.css">
    </head>

    <!-- <?php echo $data[0]->amount; ?> -->

    <div class="report-div1">
        <p class="report-heading-1">Sales Report</p>
        <p class="report-heading-2">Monthly Sales Graph</p>
        
            <table class="table-7">
                <thead>
                    <tr>
                        <th>Month - Year (2022)</th>
                        <th>Sales Amount (LKR)</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>January </td>
                        <td><?php echo $data['sales'][0] ?></td>
                    </tr>
                    <tr>
                        <td>February </td>
                        <td><?php echo $data['sales'][1] ?></td>
                    </tr>
                    <tr>
                        <td>March </td>
                        <td><?php echo $data['sales'][2] ?></td>
                    </tr>
                    <tr>
                        <td>April </td>
                        <td><?php echo $data['sales'][3] ?></td>
                    </tr>
                    <tr>
                        <td>May </td>
                        <td><?php echo $data['sales'][4] ?></td>
                    </tr>
                    <tr>
                        <td>June </td>
                        <td><?php echo $data['sales'][5] ?></td>
                    </tr>
                    <tr>
                        <td>July </td>
                        <td><?php echo $data['sales'][6] ?></td>
                    </tr>
                    <tr>
                        <td>August </td>
                        <td><?php echo $data['sales'][7] ?></td>
                    </tr>
                    <tr>
                        <td>September </td>
                        <td><?php echo $data['sales'][8] ?></td>
                    </tr>
                    <tr>
                        <td>October </td>
                        <td><?php echo $data['sales'][9] ?></td>
                    </tr>
                    <tr>
                        <td>November </td>
                        <td><?php echo $data['sales'][10] ?></td>
                    </tr>
                    <tr>
                        <td>December </td>
                        <td><?php echo $data['sales'][11] ?></td>
                    </tr>
                </tbody>
            </table>

            <div class="report-div2">
                <!-- graph bar (sales per month)-->
                <div id="graph-1">
                    <canvas id="myChart-1"></canvas>
                </div>
            </div>

        <p class="report-heading-3">Sales by Product Category</p>

            <div class="report-div3">
                <!-- graph pie (sales by product)-->
                <div id="graph-2">
                    <canvas id="myChart-2"></canvas>
                </div>
            </div>

        <p class="report-heading-4">Sales by Location</p>
            
            <div class="report-div4">
                <!-- graph line (sales by location)-->
                <div id="graph-3">
                    <canvas id="myChart-3"></canvas>
                </div>
            </div>
    </div>
   



    <script>
        
        //bar chart (sales per month)
        const labels = ['january','february','march','april','may','june','july','august','september','october','november','december'];
        const data = {
        labels: labels,
        datasets: [{
            label: 'Monthly Sales',
            data: [
                   [<?php echo $data['sales'][0]; ?>],
                   [<?php echo $data['sales'][1]; ?>], 
                   [<?php echo $data['sales'][2]; ?>], 
                   [<?php echo $data['sales'][3]; ?>], 
                   [<?php echo $data['sales'][4]; ?>], 
                   [<?php echo $data['sales'][5]; ?>], 
                   [<?php echo $data['sales'][6]; ?>], 
                   [<?php echo $data['sales'][7]; ?>], 
                   [<?php echo $data['sales'][8]; ?>], 
                   [<?php echo $data['sales'][9]; ?>],
                   [<?php echo $data['sales'][10]; ?>], 
                   [<?php echo $data['sales'][11]; ?>]
            ],
            backgroundColor: [
            '#F9F54B',
            '#05BFDB',
            '#917FB3',
            '#E49393',
            '#FEE8B0',
            '#643A6B',
            '#5D9C59',
            '#FF6000',
            '#E11119',
            '#00FFCA',
            '#454545',
            '#EB455F'
            ],
            borderWidth: 1
        }]
        };

        const config = {
        type: 'bar',
        data: data,
        options:{
            plugins:{
                legend:{
                    labels:{
                        font: {
                            size: 14
                        }
                    }
                }
            },
            scales:{
                y:{
                    title:{
                        display:true,
                        text:"Sales (LKR)",
                        font: {
                            size: 14
                        }
                    }
                }
            }
        }
        
        };

        var mychart = new Chart(
            document.getElementById('myChart-1'),
            config
        ); 



//---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

        //pie chart (sales by product)
        const labels_2 = ['Medicine','Medical devices','Personal care', 'heart', 'diabetes', 'infection', 'gastro', 'muscle', 'nourishments', 'accessories', 'skin care', 'women personal care', 'oral care', 'first aid', 'health devices', 'supports'];
        const data_2 = {
        labels: labels_2,
        datasets: [{
            label: 'Sales by Medicine Category (LKR)',
            data: [
                [<?php echo $data['sales_category'][3]; ?>],
                [<?php echo $data['sales_category'][4]; ?>],
                [<?php echo $data['sales_category'][5]; ?>],
                [<?php echo $data['sales_category'][6]; ?>],
                [<?php echo $data['sales_category'][7]; ?>],
                [<?php echo $data['sales_category'][8]; ?>],
                [<?php echo $data['sales_category'][9]; ?>],
                [<?php echo $data['sales_category'][10]; ?>],
                [<?php echo $data['sales_category'][11]; ?>],
                [<?php echo $data['sales_category'][12]; ?>],
                [<?php echo $data['sales_category'][13]; ?>],
                [<?php echo $data['sales_category'][14]; ?>],
                [<?php echo $data['sales_category'][15]; ?>]
            ],
            backgroundColor: [
            '#0A4D68',
            '#EB455F',
            '#05BFDB',
            '#917FB3',
            '#E49393',
            '#FEE8B0',
            '#643A6B',
            '#5D9C59',
            '#FF6000',
            '#E11119',
            '#00FFCA',
            '#454545',
            '#F9F54B'            
            ],
            hoverOffset: 4
        },{
            label: 'Sales by Medicine Category (LKR)',
            data: [
                [<?php echo $data['sales_category'][0]; ?>],
                [<?php echo $data['sales_category'][1]; ?>],
                [<?php echo $data['sales_category'][2]; ?>]
            ],
            backgroundColor: [
            '#0A4D68',
            '#EB455F',
            '#F9F54B'            
            ],
            hoverOffset: 4
        }]
        };

        const config_2 = {
            type: 'pie',
            data: data_2,
            options:{
                plugins:{
                    legend:{
                        display:false
                    }
                }
            }
            
        };

        var mychart = new Chart(
            document.getElementById('myChart-2'),
            config_2
        ); 


//---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
        
    <?php 
        $l1=$data['sales_location'][0];
        $l2=$data['sales_location'][1];
        $l3=$data['sales_location'][2];
        $l4=$data['sales_location'][3];
        $l5=$data['sales_location'][4];
        $l6=$data['sales_location'][5];
        $l7=$data['sales_location'][6];
        $l8=$data['sales_location'][7];
        $l9=$data['sales_location'][8];
        $l10=$data['sales_location'][9];
        $l11=$data['sales_location'][10];
        $l12=$data['sales_location'][11];
        $l13=$data['sales_location'][12];
        $l14=$data['sales_location'][13];
        $l15=$data['sales_location'][14];
    ?>
    
        //line chart (sales by location)
        const labels_3 = ['colombo 01','colombo 02','colombo 03','colombo 04','colombo 05','colombo 06','colombo 07','colombo 08','colombo 09','colombo 10','colombo 11','colombo 12','colombo 13','colombo 14','colombo 15'];
        const data_3 = {
            labels: labels_3,
            datasets: [
                {
                label: 'Sales by Location',
                borderColor:'#443C68',
                data: [
                   <?php echo intval($l1) ?>,
                   <?php echo intval($l2) ?>, 
                   <?php echo intval($l3) ?>, 
                   <?php echo intval($l4) ?>, 
                   <?php echo intval($l5) ?>, 
                   <?php echo intval($l6) ?>, 
                   <?php echo intval($l7) ?>, 
                   <?php echo intval($l8) ?>, 
                   <?php echo intval($l9) ?>, 
                   <?php echo intval($l10) ?>,
                   <?php echo intval($l11) ?>, 
                   <?php echo intval($l12) ?>,
                   <?php echo intval($l13) ?>,
                   <?php echo intval($l14) ?>,
                   <?php echo intval($l15) ?>
            ]
            }
        ]
        };

        const config_3 = {
            type: 'line',
            data: data_3,
            options:{
                plugins:{
                    legend:{
                        labels:{
                            font: {
                                size: 14
                            }
                        }
                    }
                },
                scales:{
                    y:{
                        title:{
                            display:true,
                            text:"Sales (LKR)",
                            font: {
                                size: 14
                            }
                        }
                    }
                }
            }
        };

        var mychart = new Chart(
            document.getElementById('myChart-3'),
            config_3
        ); 

    </script>
       
<?php require APPROOT . '/views/inc/footer.php'; ?>