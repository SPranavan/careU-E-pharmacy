
<?php require APPROOT . '/views/inc/manager_header.php'; ?>
    
    <head>
        <link rel="stylesheet" type="text/css" href="<?php echo URLROOT; ?>/public/css/managers/refund_order.css">
    </head>

    <div class="refund-order-div1">
        <p class="refund-order-heading">Refund Order #<?php echo $data['order']->orderID; ?></p>
        <div class="refund-order-div2">

            <form class="table-re-form" id="refund-form">                
                <table class="table-re">
                    <thead>
                        <tr>
                            <th span="1" style="width: 1%;"></th>
                            <th span="1" style="width: 14%;">Item</th>
                            <th span="1" style="width: 10%;">Cost</th>
                            <th span="1" style="width: 10%;">Quantity</th>
                            <th span="1" style="width: 10%;">Total</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            $images = explode(',', $data['order']->images);
                            $itemNames = explode(',', $data['order']->item_names);
                            $quantities = explode(',', $data['order']->quantities);
                            $prices = explode(',', $data['order']->prices);
                            $sub_totals = explode(',', $data['order']->sub_totals);
                            
                            $Sum=0;
                            for ($j = 0; $j < count($itemNames); $j++) {
                                $subtotal= $sub_totals[$j];
                                $Sum += (int)$subtotal;          //added subtotal
                            }
                        
                        for ($k = 0; $k < count($itemNames); $k++) {
                            echo '<tr>';
                            echo '<td class="refund-order-tcol-right"> <img src="'. URLROOT .'/public/img/medicine/' . $images[$k] .'" id="med_img"> </td>';
                            echo '<td class="refund-order-tcol-right">' . $itemNames[$k] . '</td>';
                            echo '<td class="refund-order-tcol-right">' . 'LKR '.$prices[$k] . '</td>';
                            echo '<td class="refund-order-tcol-right">' . $quantities[$k] . '</td>';
                            echo '<td class="refund-order-tcol-right">' . 'LKR '.$sub_totals[$k] . '</td>';
                            echo '</tr>';
                        }
                    ?>
                    </tbody>
                </table>
            </form>


            <?php
                $_SESSION['order_id'] = strval($data['order']->orderID);
                $_SESSION['amount'] = $Sum;
                $_SESSION['item'] = $itemNames;
                $_SESSION['first_name'] = $data['order']->fName;
                $_SESSION['last_name'] = $data['order']->lName;
                $_SESSION['email'] = $data['order']->email;
                $_SESSION['phone'] = strval($data['order']->mobile);
                $_SESSION['address'] = $data['order']->address;
                $_SESSION['city'] = $data['order']->city;
            ?>

            <div id="refund-customer-details">
                        <span>Customer Name : &nbsp&nbsp&nbsp&nbsp <?php echo $data['name'] ?></span><br>
                        <span>Contact No : &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp <?php echo $data['phone'] ?></span>
            </div>

            <div id="refund-amount-total">
                <span>Items Subtotal:&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp LKR <?php echo $Sum ?></span>
                <br>
                <span>Order Total:&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbspLKR <?php echo $Sum ?></span>
                <br>
                ----------------------------------------------------
                <br>
                <span style="color:red;">Refunded:&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp - LKR <?php echo $Sum ?></span>
            </div>

            <button id="refund-order-bt1" onclick="paymentgateway()">Refund</button>
            <a href="<?php echo URLROOT; ?>/Managers/cancelled_orders"> <button id="refund-order-bt2">Cancel</button></a><br><br>
        </div>
    </div>

    <script src="<?php echo URLROOT;?>/public/js/script.js"></script>
    
    <script type="text/javascript" src="https://www.payhere.lk/lib/payhere.js"></script>

<?php require APPROOT . '/views/inc/footer.php'; ?>
