<?php require APPROOT . '/views/inc/manager_header.php'; ?>

    <head>
        <link rel="stylesheet" type="text/css" href="<?php echo URLROOT; ?>/public/css/managers/pass_order.css">
    </head>

    <div class="pass-order-div1">
        <p class="pass-heading">Delivery Person List</p>

        <div class="tablefixed">
        <table class="table-2">
            <thead>
                <tr>
                    <th span="1" style="width: 10%;">Id</th>
                    <th span="1" style="width: 20%;">Name</th>
                    <th span="1" style="width: 10%;">Phone</th>
                    <th span="1" style="width: 20%;">Email</th>
                    <th span="1" style="width: 15%;">Availability Status</th>
                    <th span="1" style="width: 25%;">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    $countdata = count($data['delivery_persons']);
                    for ($i = 0; $i < $countdata; $i++) {
                        $row = $data['delivery_persons'][$i];
                        echo '<tr>
                        <td>' . $row->user_ID . '</td>
                        <td>' . $row->fName." ".$row->lName. '</td>
                        <td>' . $row->mobile . '</td>
                        <td>' . $row->email . '</td>
                        <td>' . $data['delivery_persons_individual'][$i]->availability_status . '</td>
                        <td><a href="'.URLROOT.'/Managers/Pass_order_accept/' . $data['order_id'] . '/'. $row->user_ID .'"><button>Pass the order</button></a>  
                        </tr>';
                    }
                ?>
            </tbody>
        </table>
        </div>
    </div>
<?php require APPROOT . '/views/inc/footer.php'; ?>