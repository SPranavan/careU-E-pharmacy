<?php require APPROOT . '/views/inc/manager_header.php'; ?>

    <head>
        <link rel="stylesheet" type="text/css" href="<?php echo URLROOT; ?>/public/css/managers/feedback.css">
    </head>

    <!-- sort box -->
    <form class="sort-container" method="POST" action="<?php echo URLROOT; ?>/Managers/sort_feedback">
        <label>Sort by : &nbsp</label><br>
        <select name="sort">
            <option value="date_added">Date Added</option>
        </select>
        <button type="submit" name="submit">search</button>
    </form>

    <div class="feedback-div1">    
        <p class="feedback-heading">Feedback</p>

        <div class="tablefixed">
            <table class="table-5">
                <thead>
                    <tr>
                        <th span="1" style="width: 15%;">Feedback Id</th>
                        <th span="1" style="width: 15%;">Customer ID</th>
                        <th span="1" style="width: 15%;">Date Added</th>
                        <th span="1" style="width: 40%;">Feedback</th>
                        <th span="1" style="width: 20%;text-align:left;">Action</th>
                    </tr>
                </thead>
                <tbody>
                <?php
                            $countdata = count($data);
                            for ($i = 0; $i < $countdata; $i++) {

                                echo '
                                <tr>
                                <td>' . $data[$i]->feedbackID . '</td>
                                <td>' . $data[$i]->customerID . '</td>
                                <td>' . $data[$i]->date . '</td>
                                <td class="limited">' . $data[$i]->description . '</td>
                                <td id="f_action"><a href="'.URLROOT.'/Managers/Feedback_details/' . $data[$i]->feedbackID .'" ><button >View</button></a></td>
                                </tr>';
                            }
                        ?>
                </tbody>
            </table>
        </div>
    </div>
<?php require APPROOT . '/views/inc/footer.php'; ?>