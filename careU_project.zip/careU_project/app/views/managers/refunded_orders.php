<?php require APPROOT . '/views/inc/manager_header.php'; ?>

    <head>
        <link rel="stylesheet" type="text/css" href="<?php echo URLROOT; ?>/public/css/managers/refunded_orders.css">
    </head>

    <div class="refunded-order-div1">
        <p class="refunded-heading">Refunded Orders</p>

        <div class="tablefixed">
        <table class="table-10">
            <thead>
                <tr>
                    <th span="1" style="width: 7%;">Order Id</th>
                    <th span="1" style="width: 8%;">Date</th>
                    <th span="1" style="width: 8%;">Customer Id</th>
                    <th span="1" style="width: 15%;">Item</th>
                    <th span="1" style="width: 8%;">Quantity</th>
                    <th span="1" style="width: 8%;">Refund Amount (LKR)</th>
                    <th span="1" style="width: 8%;">Order status</th>
                    <th span="1" style="width: 12%;text-align:left;">Refunded Date</th>

                </tr>
            </thead>
            <tbody>
                <?php
                    $invoiceId = '';
                    $countdata = count($data);
                    for ($i = 0; $i < $countdata; $i++) {
                        if ($data[$i]->invoiceID !== $invoiceId) {
                            if ($data[$i]->invoiceID !== $invoiceId) {
                                // new invoice, display a row for it
                                $itemNames = explode(',', $data[$i]->item_names);
                                $quantities = explode(',', $data[$i]->quantities);
                                $sub_total = explode(',', $data[$i]->sub_total);
                                $itemRows = '';
                                $quantityRows = '';
                                $Sum=0;
                                for ($j = 0; $j < count($itemNames); $j++) {
                                    $itemName = $itemNames[$j];
                                    $quantity = $quantities[$j];
                                    $sum= $sub_total[$j];
                                    $itemRows .= $itemName .'<br>';
                                    $quantityRows .= $quantity . '<br>';
                                    $Sum += (int)$sum;
                                }
                                echo '
                                <tr>
                                    <td>' . $data[$i]->orderID . '</td>
                                    <td>' . $data[$i]->date_time . '</td>
                                    <td>' . $data[$i]->user_ID . '</td>
                                    <td>' . $itemRows . '</td>
                                    <td>' . $quantityRows . '</td>
                                    <td>' . $Sum . '</td>
                                    <td>' . $data[$i]->order_status . '</td>
                                    <td style="text-align:left;">' . date('Y-m-d') . '</td>
                                </tr>';
                            $invoiceId = $data[$i]->invoiceID;
                        }
                    }
                    }
                ?>
            </tbody>
        </table>
        </div>
    </div>
<?php require APPROOT . '/views/inc/footer.php'; ?>