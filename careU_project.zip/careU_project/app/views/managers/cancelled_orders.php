<?php require APPROOT . '/views/inc/manager_header.php'; ?>

    <head>
        <link rel="stylesheet" type="text/css" href="<?php echo URLROOT; ?>/public/css/managers/cancelled_orders.css">
    </head>

    <div class="cancelled-order-div1">
        <p class="cancelled-heading">Cancelled Orders</p>

        <div class="tablefixed">
        <table class="table-3">
            <thead>
                <tr>
                    <th span="1" style="width: 8%;">Order Id</th>
                    <th span="1" style="width: 10%;">Date</th>
                    <th span="1" style="width: 16%;">Item</th>
                    <th span="1" style="width: 7%;">Quantity</th>
                    <th span="1" style="width: 10%;">Amount (LKR)</th>
                    <th span="1" style="width: 15%;">Ship to</th>
                    <th span="1" style="width: 12%;">Payment Status</th>
                    <th span="1" style="width: 15%;text-align:left;">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    $invoiceId = '';
                    $countdata = count($data);
                    for ($i = 0; $i < $countdata; $i++) {
                        if ($data[$i]->invoiceID !== $invoiceId) {
                            if ($data[$i]->invoiceID !== $invoiceId) {
                                // new invoice, display a row for it
                                $itemNames = explode(',', $data[$i]->item_names);
                                $quantities = explode(',', $data[$i]->quantities);
                                $sub_total = explode(',', $data[$i]->sub_total);
                                $itemRows = '';
                                $quantityRows = '';
                                $Sum=0;
                                for ($j = 0; $j < count($itemNames); $j++) {
                                    $itemName = $itemNames[$j];
                                    $quantity = $quantities[$j];
                                    $sum= $sub_total[$j];
                                    $itemRows .= $itemName .'<br>';
                                    $quantityRows .= $quantity . '<br>';
                                    $Sum += (int)$sum;
                                }
                                echo '
                                    <tr>
                                    <td>' . $data[$i]->orderID . '</td>
                                    <td>' . $data[$i]->date_time . '</td>
                                    <td>' . $itemRows . '</td>
                                    <td>' . $quantityRows . '</td>
                                    <td>' . $Sum . '</td>
                                    <td>' . $data[$i]->shippingAddress . '</td>      
                                    <td>' . $data[$i]->payment_status . '</td>';
                                    if ($data[$i]->payment_status == 'not paid') {
                                        echo '<td style="text-align:left;"><a href="'.URLROOT.'/Managers/refund/' . $data[$i]->orderID .'"><button disabled>Refund</button></a></td>';
                                    }
                                    else{
                                        echo '<td style="text-align:left;"><a href="'.URLROOT.'/Managers/refund/' . $data[$i]->orderID .'"><button>Refund</button></a></td>';
                                    }
                                echo '</tr>';
                                $invoiceId = $data[$i]->invoiceID;
                            }
                        }
                    }
                ?>
            </tbody>
        </table>
        </div>
    </div>
<?php require APPROOT . '/views/inc/footer.php'; ?>