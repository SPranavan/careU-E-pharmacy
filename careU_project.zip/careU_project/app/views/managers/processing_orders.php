<?php require APPROOT . '/views/inc/manager_header.php'; ?>

    <head>
        <link rel="stylesheet" type="text/css" href="<?php echo URLROOT; ?>/public/css/managers/processing_orders.css">
    </head>

    <div class="processing-order-div1">
        <p class="processing-heading">Processing Orders</p>

        <div class="tablefixed">
        <table class="table-8">
            <thead>
                <tr>
                    <th span="1" style="width: 8%;">Order Id</th>
                    <th span="1" style="width: 10%;">Date</th>
                    <th span="1" style="width: 18%;">Item</th>
                    <th span="1" style="width: 4%;">Quantity</th>
                    <th span="1" style="width: 16%;">ship to</th>
                    <th span="1" style="width: 13%;">Delivery Status</th>
                    <th span="1" style="width: 14%;">Delivery Person id</th>
                    <th span="1" style="width: 22%;text-align:left;">Action</th>

                </tr>
            </thead>
            <tbody>
                <?php
                    $invoiceId = '';
                    $countdata = count($data);
                    for ($i = 0; $i < $countdata; $i++) {
                        if ($data[$i]->invoiceID !== $invoiceId) {
                            if ($data[$i]->invoiceID !== $invoiceId) {
                                // new invoice, display a row for it
                                $itemNames = explode(',', $data[$i]->item_names);
                                $quantities = explode(',', $data[$i]->quantities);
                                $itemRows = '';
                                $quantityRows = '';
                                for ($j = 0; $j < count($itemNames); $j++) {
                                    $itemName = $itemNames[$j];
                                    $quantity = $quantities[$j];
                                    $itemRows .= $itemName .'<br>';
                                    $quantityRows .= $quantity . '<br>';
                                }
                                echo '
                                <tr>
                                    <td>' . $data[$i]->orderID . '</td>
                                    <td>' . $data[$i]->date_time . '</td>
                                    <td>' . $itemRows . '</td>
                                    <td>' . $quantityRows . '</td>
                                    <td>' . $data[$i]->shippingAddress . '</td>
                                    <td>' . $data[$i]->delivery_status . '</td>      
                                    <td>' . $data[$i]->deliverypersonID . '</td>
                                    <td style="text-align:left;"><a href="'.URLROOT.'/Managers/remind_order/' . $data[$i]->orderID."/".$data[$i]->deliverypersonID .'" ><button>Reminder</button></a></td>
                                </tr>';
                            $invoiceId = $data[$i]->invoiceID;
                        }
                    }
                    }

                ?>
            </tbody>
        </table>
        </div>
    </div>
<?php require APPROOT . '/views/inc/footer.php'; ?>