<?php

    $merchant_id="1222979";
    $merchant_secret="MzExNzg4Mzc2NTE2MjMyOTc1NTA0MTk3NzUxOTcyMjY2NTQ3NTQyNw==";
    $currency="LKR";
    
    $order_id= $_SESSION['order_id'] ;
    $amount= $_SESSION['amount'];    
    $item= $_SESSION['item'];
    $first_name= $_SESSION['first_name'];
    $last_name= $_SESSION['last_name'];
    $email= $_SESSION['email'];
    $phone= $_SESSION['phone'];
    $address= $_SESSION['address'];
    $city= $_SESSION['city'];

    $payment_id= "320032340391";

    $hash = strtoupper(
        md5(
            $merchant_id . 
            $order_id . 
            number_format($amount, 2, '.', '') . 
            $currency .  
            strtoupper(md5($merchant_secret)) 
        ) 
    );

    $array=[];
    $array["item"]=$item;
    $array["first_name"]=$first_name;
    $array["last_name"]=$last_name;
    $array["email"]=$email;
    $array["phone"]=$phone;
    $array["address"]=$address;
    $array["city"]=$city;

    $array["merchant_id"]=$merchant_id;
    $array["amount"]=$amount;
    $array["order_id"]=$order_id;
    $array["currency"]=$currency;
    $array["hash"]=$hash;

    $array["payment_id"]=$payment_id;

    $jsonObj=json_encode($array);

    echo $jsonObj;
?>