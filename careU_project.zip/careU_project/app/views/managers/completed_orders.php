<?php require APPROOT . '/views/inc/manager_header.php'; ?>

    <head>
        <link rel="stylesheet" type="text/css" href="<?php echo URLROOT; ?>/public/css/managers/completed_orders.css">
    </head>

    <div class="completed-order-div1">
        <p class="completed-heading">Completed Orders</p>

        <div class="tablefixed">
        <table class="table-9">
            <thead>
                <tr>
                    <th span="1" style="width: 7%;">Order Id</th>
                    <th span="1" style="width: 9%;">Date</th>
                    <th span="1" style="width: 15%;">Item</th>
                    <th span="1" style="width: 7%;">Quantity</th>
                    <th span="1" style="width: 7%;">Amount</th>
                    <th span="1" style="width: 14%;">ship to</th>
                    <th span="1" style="width: 11%;">Delivery Person id</th>
                    <th span="1" style="width: 15%;text-align:left;">Order status</th>

                </tr>
            </thead>
            <tbody>
                <?php
                    $invoiceId = '';
                    $countdata = count($data);
                    for ($i = 0; $i < $countdata; $i++) {
                        if ($data[$i]->invoiceID !== $invoiceId) {
                            if ($data[$i]->invoiceID !== $invoiceId) {
                                // new invoice, display a row for it
                                $itemNames = explode(',', $data[$i]->item_names);
                                $quantities = explode(',', $data[$i]->quantities);
                                $sub_total = explode(',', $data[$i]->sub_total);
                                $itemRows = '';
                                $quantityRows = '';
                                $Sum=0;
                                for ($j = 0; $j < count($itemNames); $j++) {
                                    $itemName = $itemNames[$j];
                                    $quantity = $quantities[$j];
                                    $sum= $sub_total[$j];
                                    $itemRows .= $itemName .'<br>';
                                    $quantityRows .= $quantity . '<br>';
                                    $Sum += (int)$sum;
                                }
                                echo '
                                <tr>
                                    <td>' . $data[$i]->orderID . '</td>
                                    <td>' . $data[$i]->date_time . '</td>
                                    <td>' . $itemRows . '</td>
                                    <td>' . $quantityRows . '</td>
                                    <td>' . $Sum . '</td>
                                    <td>' . $data[$i]->shippingAddress . '</td>
                                    <td>' . $data[$i]->deliverypersonID . '</td>      
                                    <td style="text-align:left;">' . $data[$i]->order_status . '</td>
                                </tr>';
                            $invoiceId = $data[$i]->invoiceID;
                        }
                    }
                    }

                    //     echo '
                    //     <tr>
                    //     <td>' . $data[$i]->orderID . '</td>
                    //     <td>' . $data[$i]->date_time . '</td>
                    //     <td>' . $data[$i]->item_name . '</td>
                    //     <td>' . $data[$i]->quantity . '</td>
                    //     <td>' . $data[$i]->shippingAddress . '</td>  
                    //     <td>' . $data[$i]->deliverypersonID . '</td>
                    //     <td>' . $data[$i]->order_status . '</td>    
                    //     </tr>';

                ?>
            </tbody>
        </table>
        </div>
    </div>
<?php require APPROOT . '/views/inc/footer.php'; ?>