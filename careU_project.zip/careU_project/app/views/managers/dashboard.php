<?php require APPROOT . '/views/inc/manager_header.php'; ?>
<head>
    <link rel="stylesheet" type="text/css" href="<?php echo URLROOT; ?>/public/css/managers/dashboard.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.5.0/Chart.min.js"></script>

</head>

<div class="head1">
    <p>Dashboard</p>
</div>

<div class="box1">
    <h3><?php echo $data['pending_count'] ?></h3>
    <!-- pending orders -->
</div>

<div class="box2">
    <h3><?php echo $data['cancelled_count'] ?></h3>
    <!-- cancelled orders -->
</div>

<div class="box3">
    <h3><?php echo $data['deliverypersons_count'] ?></h3>
    <!-- <p>Available Delivery Person</p> -->
</div>

<div class="box4">
    <h3><?php echo $data['feedback_count'] ?></h3>
    <!-- <p>Available Feedback</p> -->
</div>

<div class="chart">
    <canvas id="myChart"></canvas>

    <script>

        
        var xValues = ['January','February','March','April','May','June','July','August','September','October','November','Decemeber'];

        new Chart("myChart", {
            type: "line",
            data: {
                labels: xValues,
                datasets: [{
                    data: [
                   <?php echo $data['monthly_sales'][0]; ?>,
                   <?php echo $data['monthly_sales'][1]; ?>, 
                   <?php echo $data['monthly_sales'][2]; ?>, 
                   <?php echo $data['monthly_sales'][3]; ?>, 
                   <?php echo $data['monthly_sales'][4]; ?>, 
                   <?php echo $data['monthly_sales'][5]; ?>, 
                   <?php echo $data['monthly_sales'][6]; ?>
                   <?php echo $data['monthly_sales'][7]; ?>
                   <?php echo $data['monthly_sales'][8]; ?>
                   <?php echo $data['monthly_sales'][9]; ?>
                   <?php echo $data['monthly_sales'][10]; ?>
                   <?php echo $data['monthly_sales'][11]; ?>
            ],
                    borderColor: "#212A3E",
                    fill: false
                }]
            },
            options: {
                legend: {
                    display: true
                },
                scales:{
                    yAxes:[{
                        scaleLabel:{
                            display:true,
                            labelString:'Sales (LKR)'
                        }
                    }],
                    xAxes:[{
                        scaleLabel:{
                            display:true,
                            labelString:'Month'
                        }
                    }]
                }
            }
        });
    </script>

</div>
<div class="head2">
    <p>Monthly Analysis</p>
</div>
<?php require APPROOT . '/views/inc/footer.php'; ?>