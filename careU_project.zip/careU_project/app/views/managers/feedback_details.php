<?php require APPROOT . '/views/inc/manager_header.php'; ?>

    <head>
        <link rel="stylesheet" type="text/css" href="<?php echo URLROOT; ?>/public/css/managers/feedback_details.css">
    </head>

    <div class="feedback-details-div1">
        <p class="feedback-details-heading">Feedback Details</p>
        <div class="feedback-details-div2">
            <table class="table-6">
                <tbody>
                    <tr>
                        <td class="feedback-details-tcol-left">Feedback Id</td>
                        <td class="feedback-details-tcol-right">&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<?php echo $data['feedback']->feedbackID; ?></td>
                    </tr>
                    <tr>
                        <td class="feedback-details-tcol-left">Customer Id</td>
                        <td class="feedback-details-tcol-right">&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<?php echo $data['feedback']->customerID; ?></td>
                    </tr>
                    <tr>
                        <td class="feedback-details-tcol-left">Customer Name</td>
                        <td class="feedback-details-tcol-right">&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<?php echo $data['name']->name; ?></td>
                    </tr>
                    <tr>
                        <td class="feedback-details-tcol-left">Date Added</td>
                        <td class="feedback-details-tcol-right">&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<?php echo $data['feedback']->date; ?></td>
                    </tr>
                    <tr>
                        <td class="feedback-details-tcol-left">Description</td>
                        <td class="feedback-details-tcol-right" id="feedback_description"><?php echo $data['feedback']->description; ?></td>
                    </tr>
                </tbody>
            </table>
            <a href="<?php echo URLROOT; ?>/Managers/Feedback" style='text-decoration:none;'><button class="feedback-details-bt1">Back</button></a>
            <a href="<?php echo URLROOT; ?>/Managers/delete_feedback/<?php echo $data['feedback']->feedbackID; ?>" style='text-decoration:none;'><button class="feedback-details-bt2">Delete</button></a>
        </div>
        <div class="feedback-details-div3">
            <form class="feedback-details-form" method="POST" action="<?php echo URLROOT; ?>/Managers/feedback_response/<?php echo $data['feedback']->customerID; ?>" >
                <label for="customer_id">Customer Id</label>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
                <input type="text" class="feedback-details-input" id="c_id" name="customer_id" value=<?php echo $data['feedback']->customerID;  ?> disabled><br>
                
                <label for="date">Date</label>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
                <input type="text" class="feedback-details-input" id="date" name="date" value=<?php echo date("Y-m-d H:i:s"); ?> disabled><br><br>

                <label for="Response">Response</label> &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp  
                <input type="radio" id="response" name="feedback_type" value="1" checked> <label for="vehicle1"> Postive Feedback</label><br><br>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
                <input type="radio" id="response" name="feedback_type" value="0"> <label for="vehicle2"> Negative Feedback</label><br>

                <button type="submit" class="feedback-details-bt3">Send E-mail</button>
        </div>
    </div>
<?php require APPROOT . '/views/inc/footer.php'; ?>