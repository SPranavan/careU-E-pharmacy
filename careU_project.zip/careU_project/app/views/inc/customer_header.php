<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo SITENAME; ?></title>
    <link rel="stylesheet" type="text/css" href="<?php echo URLROOT; ?>/public/css/customer/customer-header.css">
    <link rel="stylesheet" type="text/css" href="<?php echo URLROOT; ?>/public/css/customer/customer-footer.css">
    <!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"> -->
    
</head>
<body>

    <section>
        <div class="wrapper">
            <header>

                <div class="topNav-add">
                        
    
                        <div class="topNav-right">
                            <div class="login-link">
                                <img class="login-icon" src="<?php echo URLROOT;?>/public/img/header/Login.png" alt="icon">
                                <a href="<?php echo URLROOT; ?>/Customers/myaccount"><h4 class="myacc-a">MY ACCOUNT</h4></a>
                                <a href="<?php echo URLROOT; ?>/users/logout"><h4 class="login-a"> |&nbsp LOGOUT</h4></a>

                            </div>
    
                            
                </div>
    
    
                <div class="topNav">
                    <a href="/careU_project/Customers/home"><img class="logo" src="<?php echo URLROOT;?>/public/img/header/Logo_White.png" alt="logo">
                    <h3 class="logoName">Pharmacy</h3></a>
    
                    
                   

                    <!-- <div class="name">
                        <p><?php echo $_SESSION['user_fName'] . " " . $_SESSION['user_lName'] ?></p>
                    </div> -->
    
                    
    
                        <div class="topNav-right">
                            <a href=""><button type="submit" name="submit" class="button1" style="vertical-align:middle"><span><?php echo $_SESSION['user_fName'].' '.$_SESSION['user_lName']  ?></span></button></a>
                        </div>
    
                    </div>
    
                    
                </div>
                <br>
                <div class="bottomNav">
    
                    <div class="bottomNav-left">
                        <div class="bottomnav">
                            <a href="<?php echo URLROOT; ?>/Customers/order">ONLINE SHOP</a>
                            <a href="<?php echo URLROOT; ?>/Customers/cart">CART</a>
                            <a href="<?php echo URLROOT; ?>/Customers/order_details">ORDER DETAILS</a>
                            <a href="<?php echo URLROOT; ?>/Customers/feedback">FEEDBACK</a>
                            <a href="<?php echo URLROOT; ?>/Customers/about">ABOUT US</a>
                            <a href="<?php echo URLROOT; ?>/Customers/prescription_upload" class="split">DOCTOR'S PRESCRIPTION</a>
                        </div>
    
                        
                        
                        
                    </div>
    
                </div>
            </header>


            