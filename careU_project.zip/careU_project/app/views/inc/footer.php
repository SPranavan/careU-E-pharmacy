<footer>
                <div class="left">
                    <a href="#" class="about"><span>ABOUT US &nbsp</span></a>
                    <a href="#" class="terms"><span>| &nbsp&nbsp TERMS AND CONDITIONS</span></a>
                    <br>
                    <div class="left-bottom">
                        <img class="copyright" src="<?php echo URLROOT;?>/public/img/footer/copyright.png" alt="copyright">
                        <p class="all">&nbsp 2022 All Rights Reserved</p>
                    </div>
    
                </div>
    
                <div class="right">
                    <p class="contact">Contact Us</p>
                    <br>
                    <div class="right-bottom1">
                        <img class="call" src="<?php echo URLROOT;?>/public/img/footer/call.png" alt="call">
                        <p class="num">&nbsp 021 2230626</p>
                    </div>
                    <br>
                    <div class="right-bottom2">
                        <a href="#"><img class="wa" src="<?php echo URLROOT;?>/public/img/footer/whatsapp.png" alt="whatsApp"></a>
                        <a href="#"><img class="fb" src="<?php echo URLROOT;?>/public/img/footer/facebook.png" alt="FB"></a>
                        <a href="#"><img class="insta" src="<?php echo URLROOT;?>/public/img/footer/instagram.png" alt="IG"></a>
                    </div>
    
                </div>
            </footer>
        </div>
    
    </section>
    
        
    
</body>
</html>

