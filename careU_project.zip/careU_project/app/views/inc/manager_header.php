<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo SITENAME; ?></title>
    <link rel="stylesheet" type="text/css" href="<?php echo URLROOT; ?>/public/css/managers/manager_header.css">
    <link rel="stylesheet" type="text/css" href="<?php echo URLROOT; ?>/public/css/managers/manager_footer.css">
    <link rel="stylesheet" type="text/css" href="<?php echo URLROOT; ?>/public/css/login.css">  
    <link href="https://fonts.googleapis.com/css2?family=Mali:wght@600&display=swap" rel="stylesheet">
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    
</head>
<body>
    <header>

        <div class="topNav-add">
                
                <div class="topNav-right">
                    <div class="login-link">
                        <img class="login-icon" src="<?php echo URLROOT;?>/public/img/header/Login.png" alt="icon">
                        <a href="<?php echo URLROOT; ?>/users/logout"><h4 class="login-a">LOGOUT</h4></a>
                        <a href="<?php echo URLROOT; ?>/Managers/account"><h4 class="myacc-a"> |&nbsp MY ACCOUNT</h4></a>
                    </div>
                    
        </div>


        <div class="topNav">
            <img class="logo" src="<?php echo URLROOT;?>/public/img/header/Logo_White.png" alt="logo">
            <h3 class="logoName">Pharmacy</h3>

            <!-- <div class="search-container">
                <form action="/action_page.php">
                <input type="text" placeholder="Search..." name="search">
                <button type="submit"><i class="fa fa-search"></i></button>
                </form>
            </div>          -->

                <div class="topNav-right">
                    <a href=""><button type="submit" name="submit" class="button1" style="vertical-align:middle"><spa><span><?php echo $_SESSION['user_fName'].' '.$_SESSION['user_lName']  ?></span></button></a>
                </div>

            </div>

            
        </div>
        <br>
        <div class="bottomNav">

            <div class="bottomNav-left">

                <img class="Img1" src="<?php echo URLROOT;?>/public/img/header/report.png" alt="Report">
                <a href=""><h5 class="item1"></h5></a>
                
                <div class="dropdown1">
                <button class="dropbtn1"><a href="<?php echo URLROOT; ?>/managers/Report" style="text-decoration: none;color: inherit;">Report</a></button>
                <!-- <div class="dropdown-content1">
                    
                </div> -->
                </div>
                
                <img class="Img2" src="<?php echo URLROOT;?>/public/img/header/feedback.png" alt="Feedback">
                <a href=""><h5 class="item2"></h5></a>
                <div class="dropdown2">
                <button class="dropbtn2"><a href="<?php echo URLROOT; ?>/managers/Feedback" style="text-decoration: none;color: inherit;">Feedback</a></button>
                <!-- <div class="dropdown-content2">
                    
                </div> -->
                </div>
                    
                <img class="Img3" src="<?php echo URLROOT;?>/public/img/header/orders.png" alt="Orders">
                <a href=""><h5 class="item3"></h5></a>
                
                <div class="dropdown3">
                <button class="dropbtn3">Orders</button>
                <div class="dropdown-content3">
                    <a href="<?php echo URLROOT; ?>/managers/Initiated_orders">Pending Orders</a>
                    <a href="<?php echo URLROOT; ?>/managers/Processing_orders">Processing Orders</a>
                    <a href="<?php echo URLROOT; ?>/managers/Completed_orders">Completed Orders</a>
                    <a href="<?php echo URLROOT; ?>/managers/Cancelled_orders">Cancelled Orders</a>
                    <a href="<?php echo URLROOT; ?>/managers/Refunded_orders">Refunded Orders</a>
                </div>
                </div>
               
            </div>

        </div>
    </header>    
