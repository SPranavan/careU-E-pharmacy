<div id="id01" class="modal">
  <span onclick="document.getElementById('id01').style.display='none'" class="close" title="Close Modal">&times;</span>
  <form class="modal-content" action="/action_page.php">
    <div class="container">
      <h1>Feedback</h1>
      <input class="review" type="text">
      <div class="clearfix">
        <button type="submit" class="sub-btn">submit</button>
      </div>
    </div>
  </form>
</div>