<?php require APPROOT . '/views/inc/pharmacist_header.php'; ?>

<head>
    <link rel="stylesheet" type="text/css" href="<?php echo URLROOT; ?>/public/css/pharmacists/slider.css">


    
</head>

<body>
<div class="slider">
      <ul>
      <li><img class="sli-img" src="<?php echo URLROOT;?>/public/img/pharmacist/pharm_6.jpg" /></li>
        <li><img class="sli-img" src="<?php echo URLROOT;?>/public/img/pharmacist/pharm_7.jpg" /></li>
        <li><img class="sli-img" src="<?php echo URLROOT;?>/public/img/pharmacist/pharmacy_2.jpg" alt="image two" /></li>
        <li><img class="sli-img" src="<?php echo URLROOT;?>/public/img/pharmacist/pharm_4.jpg" /></li>
        <li><img class="sli-img" src="<?php echo URLROOT;?>/public/img/pharmacist/pharm_5.jpg" /></li>
        <!-- <li><img src="/img3.jpg" alt="image three" /></li>
        <li><img src="/img4.jpg" alt="image four" /></li> -->
      </ul>
    </div>

    <script src="<?php echo URLROOT; ?>/public/js/slide.js"></script>
</body>



<?php require APPROOT . '/views/inc/pharmacistfooter.php'; ?>