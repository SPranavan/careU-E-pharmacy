<?php require APPROOT . '/views/inc/pharmacist_header.php'; ?>

<head>
    <link rel="stylesheet" type="text/css" href="<?php echo URLROOT; ?>/public/css/pharmacists/prescription_available.css">
</head>



<div class="available">
    <p>Available Prescriptions</p>
</div>

<div class="details">
    <table>
        <hr class="hr1">
        <tr>
            <th>Prescription ID</th>
            <th>Date</th>
            <th>Time</th>
            <th></th>
        </tr>
        <hr class="hr2">
        

        <tr>
            <td>Alfreds Futterkiste</td>
            <td>Maria Anders</td>
            <td>Germany</td>
            <td><button>view</button></td>
        </tr>
        <tr>
            <td>Alfreds Futterkiste</td>
            <td>Maria Anders</td>
            <td>Germany</td>
            <td><button>view</button></td>
        </tr>
        <tr>
            <td>Alfreds Futterkiste</td>
            <td>Maria Anders</td>
            <td>Germany</td>
            <td><button>view</button></td>
        </tr>
        <tr>
            <td>Alfreds Futterkiste</td>
            <td>Maria Anders</td>
            <td>Germany</td>
            <td><button>view</button></td>
        </tr>
    </table>

</div>







<?php require APPROOT . '/views/inc/pharmacistfooter.php'; ?>