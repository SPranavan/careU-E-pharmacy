<?php
// print_r($data);die();
 require APPROOT . '/views/inc/pharmacist_header.php'; ?>

<head>
    <link rel="stylesheet" type="text/css" href="<?php echo URLROOT; ?>/public/css/pharmacists/new_order.css">
    <!-- <script>
        // Get the modal
        var modal = document.getElementById('id01');

        // When the user clicks anywhere outside of the modal, close it
        window.onclick = function(event) {
            if (event.target == modal) {
                modal.style.display = "none";
            }
        }
    </script>
</head>
<?php //require APPROOT . '/views/inc/feedback_pop_up.php'; ?> -->

<div class="available">
    <p>New Orders</p>
</div>

<div class="box">
<div class="details">
    <table>
        <hr class="hr1">
        <tr>
            <th>Customer name</th>
            <th>Address</th>
            <th>Medicines</th>
        
            <th></th>
            <th></th>
        </tr>
        <hr class="hr2">
        <?php
        $countdata = count($data);
        for($i = 0; $i < $countdata; $i++){
            if($i==0){
            echo '
            <tr>
            <td>' .$data[$i]->fName.'</td>
            <td>' .$data[$i]->address.'</td>
            <td>' .$data[$i]->name.'</td>'; ?>
            <td><a href="./accept_order/<?php echo $data[$i]->orderID ?>"><button>Accept</button> </a></td>
            <td><a href="./reject_order/<?php echo $data[$i]->orderID ?>"><button>Reject</button></a></td>
        </tr>
       <?php }
        elseif($data[$i]->fName == $data[$i-1]->fName){
                
            echo '<td></td>
            <td></td>
            
            <td>'.$data[$i]->name.'</td>'; 
            echo '</tr>';
        }
        else{
            echo '
            <tr>
            <td>' .$data[$i]->fName.'</td>
            <td>' .$data[$i]->address.'</td>
            <td>' .$data[$i]->name.'</td>'; ?>
            <td><a href="./accept_order/<?php echo $data[$i]->orderID ?>"><button>Accept</button> </a></td>
            <td><a href="./reject_order/<?php echo $data[$i]->orderID ?>"><button>Reject</button></a></td>
        <?php echo '</tr>';
        
       
        }}
    ?> 
        

        
        
        
    </table>

</div>
</div>

<?php require APPROOT . '/views/inc/pharmacistfooter.php'; ?>