<?php require APPROOT . '/views/inc/pharmacist_header.php';
// print_r(($data));
// die(); ?>

<head>
    <link rel="stylesheet" type="text/css" href="<?php echo URLROOT; ?>/public/css/pharmacists/completed_orders.css">
    <script>
        // Get the modal
        var modal = document.getElementById('id01');

        // When the user clicks anywhere outside of the modal, close it
        window.onclick = function(event) {
            if (event.target == modal) {
                modal.style.display = "none";
            }
        }
    </script>
</head>
<?php require APPROOT . '/views/inc/feedback_pop_up.php'; ?>

<div class="available">
    <p>Completed Orders</p>
</div>

<div class="box">
    <div class="details">
        <table>
            <hr class="hr1">
            <thead>
                <tr>


                    <th>Customer Name</th>
                    <th>Address</th>
                    <th>Medicines</th>

                </tr>
                <thead>
                    <hr class="hr2">

                    <?php
                    $countdata = count($data);
                    for ($i = 0; $i < $countdata; $i++) {

                        if ($i == 0) {
                            echo '
                    <tr>
                    <td>' . $data[$i]->fName . '</td>
                    <td>' . $data[$i]->address . '</td>
                    <td>' . $data[$i]->name . '</td>'; ?>
                            <td><button onclick="location.href='./delete/<?php echo $data[$i]->orderID ?>'">Delete</button></td>

                            </tr>
                        <?php  } elseif ($data[$i]->fName == $data[$i - 1]->fName) {
                             echo '<td></td>
                                    <td></td>
                                    <td>' . $data[$i]->name . '</td>';
                            echo '</tr>';
                        } else {

                            echo '
                    <tr>
                    <td>' . $data[$i]->fName . '</td>
                    <td>' . $data[$i]->address . '</td>
                    <td>' . $data[$i]->name . '</td>'; ?>
                            <td><button onclick="location.href='./delete/<?php echo $data[$i]->orderID ?>'">Delete</button></td>

                    <?php echo '</tr>';
                        }
                    }
                    ?>

        </table>

    </div>
</div>

<?php require APPROOT . '/views/inc/pharmacistfooter.php'; ?>