<?php
// print_r(($med_types));die();
 require APPROOT . '/views/inc/pharmacist_header.php';
require APPROOT . '/views/pharmacist/popup/prescription_view.php';


?>


<head>
    <link rel="stylesheet" type="text/css" href="<?php echo URLROOT; ?>/public/css/pharmacists/available_prescription.css">
    <link rel="stylesheet" type="text/css" href="<?php echo URLROOT; ?>/public/css/pharmacists/prescription_view.css">
</head>

<div class="available">
    <p>Available Prescriptions</p>
</div>

<div class="box">
    <div class="details">
        <table>
            <hr class="hr1">
            <tr>
                <th>Customer Name</th>
                <th>Address</th>
                <th>Message</th>
                <th></th>
            </tr>
            <hr class="hr2">

            <?php

            $countdata = count($data[0]);
            for ($i = 0; $i < $countdata; $i++) {
                echo '
        <tr>
            <td>' . $data[0][$i]->fName . '</td>
            <td>' . $data[0][$i]->address . '</td>
            <td>' . $data[0][$i]->message . '</td>'; ?>
                <td><button onclick="document.getElementById('pre_img').src = '<?php echo URLROOT; ?>/public/img/prescription/<?php echo $data[0][$i]->prescription ?>'; document.getElementById('reject').href = './reject_prescription/<?php echo $data[0][$i]->prescriptionID ?>';document.getElementById('accept').href = './accept_prescription/<?php echo $data[0][$i]->prescriptionID ?>'; document.getElementById('preid').innerHTML = '<?php echo $data[0][$i]->prescriptionID ?>'; document.getElementById('id01').style.display='block'">View</button></td>
            <?php echo '</tr>';
            }
            ?>
        </table>

    </div>
</div>

<?php require APPROOT . '/views/inc/pharmacistfooter.php';

