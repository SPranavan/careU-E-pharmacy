<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script>
  $(document).ready(function() {
    $("#dropdown1").change(function() {
      var drop1 = $(this).val();
      var opt = "<option value='NULL' selected hidden disabled>Select an option</option>";
      $.ajax({
        url: './dropdown_search',
        type: 'post',
        data: {
          dd1: drop1
        },
        success: function(response) {
          $("#dropdown2").html(response);
          $("#dropdown3").html(opt);
        }
      });
    });
  });
</script>

<script>
  $(document).ready(function() {
    $("#dropdown2").change(function() {
      var drop2 = $(this).val();
      $.ajax({
        url: './dropdown_search2',
        type: 'post',
        data: {
          dd2: drop2
        },
        success: function(response) {
          console.log(response);
          $("#dropdown3").html(response);
        }
      });
    });
  });
</script>

<script>
  $(document).ready(function() {
    $("#dropdown3").change(function() {
      var drop3 = $(this).val();
      $.ajax({
        url: './dropdown_search3',
        type: 'post',
        data: {
          dd3: drop3
        },
        success: function(response) {
          console.log(response);
          $("#quantity").attr({
            "max":response
          });
          $("#add-med").html ( ' Add Medicine');
          
         
        }
      });
    });
  });
</script>

<script>
  $(document).ready(function() {
    $("#quantity").keyup(function() {
      const quan_max =$("#quantity").attr("max");
      var quantity = $(this).val();
      if ($(this).val() < parseInt(quan_max)) {
        console.log(quantity + "  " + quan_max);
        $("#add-med").html ( 'Add Medicine');
      } else {
        console.log("Check 2");
        $("#add-med").html ( 'Select Quantity Less Than '+quan_max);
      }
    });
  });
</script>

<script>
  $(document).ready(function() {
    $("#add-med").click(function() {
      var dropdown1 = $("#dropdown1").val();
      var dropdown2 = $("#dropdown2").val();
      var dropdown3 = $("#dropdown3").val();
      var quantity = $("#quantity").val();
      var quan_max =$("#quantity").attr("max");
      var preid = $("#preid").html();
      if (parseInt(quan_max) > quantity) {
        $.ajax({
        url: './add_medicine_invoice',
        type: 'post',
        data: {
          drop1: dropdown1,
          drop2: dropdown2,
          drop3: dropdown3,
          quan:quantity,
          pid:preid
        },
        success: function(response) {
          console.log(response);
          $("#medtable").html(response);
        }
      });
        
      } else {
        $("#add-med").html ( 'Select Quantity Less Than '+quan_max);
        console.log(quan_max);
        
      }
      
    });
  });
</script>

<div id="id01" class="modal">
  <div class="modal-content">
  <div>
  <span onclick="document.getElementById('id01').style.display='none'" class="close" title="Close Modal">&times;</span>
  <div class="container">
    <h1>Prescription <span id="preid"></span></h1>
    <h2>Create Invoice </h2>
    <img id="pre_img" src="" class="review">
    <div class="option">
    
      <div class="dropdown12">
        <select id="dropdown1" required>
          <option value="NULL" selected hidden disabled>Select an option</option>
          <?php
          foreach ($data[1] as $row) {
            echo '<option value="' . $row->medicine_type1 . '">' . $row->medicine_type1 . '</option>';
          }
          ?>

        </select>

        <select id="dropdown2" required>
          <option value="">Select an option</option>
        </select>

      </div>

      <div class="dropdown34">
        <select id="dropdown3" required>
          <option value="">Select an option</option>
        </select>
        
        <input max='' id="quantity" type="text" placeholder="Insert Quantity" required>
      </div>
      
    </div>
    <div id ='but_cont'>
      <button type="submit" id="add-med" class="add">Add Medicine</button>
    </div>
    <div class="table1">
    <table id="medtable">
        <tr>
          <th>Medicine</th>
          <th>Quantity</th>
        </tr>
        
      </table>
      </div>
    </div>


    <!-- <div class="clearfix"> -->
      <a id="reject" href=""><button type="button" class="sub-btn">Reject</button></a>
      <a id="accept" href=""><button type="button" class="sub-btn">Accept</button> </a>
    <!-- </div> -->
  </div>
  </div>
</div>