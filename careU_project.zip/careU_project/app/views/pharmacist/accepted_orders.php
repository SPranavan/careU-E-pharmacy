<?php 

require APPROOT . '/views/inc/pharmacist_header.php'; 
;?>

<head>
    <link rel="stylesheet" type="text/css" href="<?php echo URLROOT; ?>/public/css/pharmacists/accepted_orders.css">
    
</head>

<div class="available">
    <p>Accepted Orders</p>
</div>

<div class="box">
<div class="details">
    <table>
        <hr class="hr1">
        <tr>
            
            <th>Customer Name</th>
            <th>Address</th>
            <th>Medicines</th>
            <th>Packed</th>
        </tr>
        <hr class="hr2">
        
        <?php
        $countdata = count($data);
        for($i = 0; $i < $countdata; $i++){
            echo '<tr> ';
            if($i == 0){
                echo '
                <td>'.$data[$i]->fName.'</td>
                <td>'.$data[$i]->address.'</td>
                <td>'.$data[$i]->name.'</td>'; 
                
                if ($data[$i] -> packing_status == "unpacked"){ ?>
                    <td><input type="checkbox" onchange="location.href='./packed_ord/<?php echo $data[$i]->orderID ?>'"></td>
                    
                <?php
                     } else {?>
                        <td><input type="checkbox" checked onchange="location.href='./unpacked_ord/<?php echo $data[$i]->orderID ?>'"></td>
                        <td><button onclick="location.href='./packed_done_ord/<?php echo $data[$i]->orderID ?>'">Done</button></td>
                <?php } 
            }
            elseif($data[$i]->fName == $data[$i-1]->fName){
                
                echo '<td></td>
                <td></td>
                <td>'.$data[$i]->name.'</td>'; 
            }
            else{
            echo '
            <td>'.$data[$i]->fName.'</td>
            <td>'.$data[$i]->address.'</td>
            <td>'.$data[$i]->name.'</td>'; 

            if ($data[$i] -> packing_status == "unpacked"){ ?>
                <td><input type="checkbox" onchange="location.href='./packed_ord/<?php echo $data[$i]->orderID ?>'"></td>
            <?php
                 } else {?>
                    <td><input type="checkbox" checked onchange="location.href='./unpacked_ord/<?php echo $data[$i]->orderID ?>'"></td>
                    <td><button onclick="location.href='./packed_done_ord/<?php echo $data[$i]->orderID ?>'">Done</button></td>
            <?php } 
            }?>
           <?php
            echo '
            
        </tr>';
    }
                 ?>
        
    </table>

</div>
</div>

<?php require APPROOT . '/views/inc/pharmacistfooter.php'; ?>