<?php require APPROOT . '/views/inc/pharmacist_header.php'; ?>

<head>
    <link rel="stylesheet" type="text/css" href="<?php echo URLROOT; ?>/public/css/pharmacists/accepted_prescription.css">
    <!-- <script>
        function showMessage(){
            window.alert("this is a po-up message!");
        }
    </script> -->
</head>

<div class="available">
    <p>Accepted Prescription</p>
</div>

<div class="box">
    <div class="details">
        <table>
            <hr class="hr1">
            <tr>
                <th>Customer Name</th>
                <th>Address</th>
                <th>Message</th>
                <th>Packed</th>

                <th></th>
            </tr>
            <hr class="hr2">

            <?php
            $countdata = count($data);
            for ($i = 0; $i < $countdata; $i++) {
                echo '
        <tr>
            <td>' . $data[$i]->fName . '</td>
            <td>' . $data[$i]->address . '</td>
            <td>' . $data[$i]->message . '</td>'; ?>
                <?php
                if ($data[$i]->packing_status == "unpacked") { ?>
                    <td><input type="checkbox" onchange="location.href='./packed_presc/<?php echo $data[$i]->prescriptionID ?>'"></td>
                <?php } else { ?>
                    <td><input type="checkbox" checked onchange="location.href='./un_packed_presc/<?php echo $data[$i]->prescriptionID ?>'"></td>
                    <td><button onclick="location.href='./packed_done/<?php echo $data[$i]->prescriptionID ?>'">Done</button></td>
            <?php }
                echo '
            
        </tr>';
            }
            ?>
        </table>

    </div>
</div>

<?php require APPROOT . '/views/inc/pharmacistfooter.php'; ?>