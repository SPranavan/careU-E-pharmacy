<?php require APPROOT . '/views/inc/pharmacist_header.php'; ?>

<head>
    <link rel="stylesheet" type="text/css" href="<?php echo URLROOT; ?>/public/css/pharmacists/completed_prescription.css">
    <script>
        // Get the modal
        var modal = document.getElementById('id01');

        // When the user clicks anywhere outside of the modal, close it
        window.onclick = function(event) {
            if (event.target == modal) {
                modal.style.display = "none";
            }
        }
    </script>
</head>
<?php require APPROOT . '/views/inc/feedback_pop_up.php'; ?>

<div class="available">
    <p>Completed Prescriptions</p>
</div>

<div class="box">
    <div class="details">
        <table>
            <hr class="hr1">
            <tr>
                <th>Name</th>
                <th>Address</th>
                <th>Message</th>


                <th></th>
                <th></th>
            </tr>
            <hr class="hr2">

            <?php
            $countdata = count($data);
            for ($i = 0; $i < $countdata; $i++) {
            ?>
                <tr>
                    <td><?php echo $data[$i]->fName ?></td>
                    <td><?php echo $data[$i]->address ?></td>
                    <td><?php echo $data[$i]->message ?></td>


                </tr>
            <?php  }
            ?>
        </table>

    </div>
</div>

<?php require APPROOT . '/views/inc/pharmacistfooter.php'; ?>