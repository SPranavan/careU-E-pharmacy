<?php require APPROOT . '/views/inc/storekeeper_header.php'; ?>
    
    <head>
        <link rel="stylesheet" type="text/css" href="<?php echo URLROOT; ?>/public/css/storekeepers/delete_personalcare.css">
    </head>

    <!-- sort box -->
    <form class="sort-container" method="POST" action="<?php echo URLROOT; ?>/StoreKeepers/sort_pc_womenpc">
        <label>Sort by :</label><br>
        <select name="sort">
            <option value="alphabetical">Alphabetical</option>
            <option value="expiry_date">Expiry date</option>
            <option value="quantity">Quantity</option>
        </select>
        <button type="submit" name="submit">search</button>
    </form>

    <div class="delete-personalcare-div1">
        <p class="delete-personalcare-heading-1">Edit Personal Care</p>
        <div class="delete-personalcare-div2">
            <br><a href="delete_pc_nourishments">Nourishments</a><br><br>
            <a href="delete_pc_accessories">Accessories</a><br><br>
            <a href="delete_pc_skincare">Skin Care</a><br><br>
            <a class="current">Woman Pesonal Care</a><br><br>
            <a href="delete_pc_oralcare">Oral Care</a>
        </div>

        
        <!-- <p class="view-medicine-heading-2">Initiated Orders</p> -->
        <div class="delete-personalcare-div3">
            <?php 
                $countdata = count($data);

                for ($i=0; $i < $countdata; $i++) { 
                    echo '
                    <a href="'.URLROOT.'/StoreKeepers/fetch_medicine/' . $data[$i]->medicineID .'" id="wrap_card_link">
                    <div class="box_card">
                        <img src="'.URLROOT.'/public/img/medicine/'.$data[$i]->image.'" alt="call">
                        <p>Item ID :<span class="data"> '.$data[$i]-> medicineID.' </span> </p>
                        <p>Item Name :<span class="data"> '.$data[$i]-> name.'</span> </p>
                        <p>Stock :<span class="data"> '.$data[$i]-> quantity.'</span> </p>
                        <p>Date of expiry :<span class="data"> '.$data[$i]-> expiry_date.'</span> </p>
                    </div> </a>';
                };
                        
            ?>
        </div>
    </div>
<?php require APPROOT . '/views/inc/footer.php'; ?>