<?php require APPROOT . '/views/inc/storekeeper_header.php'; ?>
    
    <head>
        <link rel="stylesheet" type="text/css" href="<?php echo URLROOT; ?>/public/css/storekeepers/view_medicine_Detail.css">
    </head>
    
    <div class="view-medicine-Detail-div1">
        <p class="view-medicine-Detail-heading-1">Delete Medicine</p>
        <div class="view-medicine-Detail-div2">
            <div class="view-medicine-Detail-div3">
                <img src="<?php echo URLROOT; ?>/public/img/medicine/<?php echo $data['medicine']->image; ?>" alt="call" id="med_img">
            </div>
            <table class="table-k">
                <tbody>
                    <tr>
                        <td class="view-medicine-Detail-tcol-left">Item Id</td>
                        <td class="view-medicine-Detail-tcol-right">&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<?php echo $data['medicine']->medicineID; ?></td>
                    </tr>
                    <tr>
                        <td class="view-medicine-Detail-tcol-left">Item Name</td>
                        <td class="view-medicine-Detail-tcol-right">&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<?php echo $data['medicine']->name; ?></td>
                    </tr>
                    <tr>
                        <td class="view-medicine-Detail-tcol-left">Service</td>
                        <td class="view-medicine-Detail-tcol-right">&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<?php echo $data['medicine']->medicine_type1; ?></td>
                    </tr>
                    <tr>
                        <td class="view-medicine-Detail-tcol-left">Medicine Type</td>
                        <td class="view-medicine-Detail-tcol-right">&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<?php echo $data['medicine']->medicine_type2; ?></td>
                    </tr>
                    <tr>
                        <td class="view-medicine-Detail-tcol-left">Quantity Mesurement</td>
                        <td class="view-medicine-Detail-tcol-right">&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<?php echo $data['medicine']->quantity_measurement; ?></td>
                    </tr>
                    <tr>
                        <td class="view-medicine-Detail-tcol-left">Total Items</td>
                        <td class="view-medicine-Detail-tcol-right">&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<?php echo $data['medicine']->quantity; ?></td>
                    </tr>
                    <tr>
                        <td class="view-medicine-Detail-tcol-left">Date of Expiary</td>
                        <td class="view-medicine-Detail-tcol-right">&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<?php echo $data['medicine']->expiry_date; ?></td>
                    </tr>
                    <tr>
                        <td class="view-medicine-Detail-tcol-left">Price per Capsule (LKR)</td>
                        <td class="view-medicine-Detail-tcol-right">&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<?php echo $data['medicine']->price; ?></td>
                    </tr>
                </tbody>
            </table>
            
            <a href="<?php echo URLROOT; ?>/StoreKeepers/view_medicine_heart" style='text-decoration:none;'><button class="view-medicine-Detail-bt1">Back</button></a>
            <a href="<?php echo URLROOT; ?>/StoreKeepers/delete_medicine/<?php echo $data['medicine']->medicineID; ?>" style='text-decoration:none;'><button class="view-medicine-Detail-bt2">Delete</button></a>
        </div>
        </div> 
    </div>
<?php require APPROOT . '/views/inc/footer.php'; ?>