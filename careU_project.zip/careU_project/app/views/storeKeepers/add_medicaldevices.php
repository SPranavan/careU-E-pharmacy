<?php require APPROOT . '/views/inc/storekeeper_header.php'; ?>
    
    <head>
        <link rel="stylesheet" type="text/css" href="<?php echo URLROOT; ?>/public/css/storekeepers/add_medicaldevices.css">
    </head>

    <div class="add-medicaldevices-div1">
        <p class="add-medicaldevices-heading">Add Medical Devices</p>
        <div class="add-medicaldevices-div2">
            
            <form action="<?php echo URLROOT; ?>/StoreKeepers/add_medicaldevices_form" method="POST" class="add-medicaldevices-form">
                <label for="service">Service</label>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
                <input type="text" class="add-medicaldevices-input" id="service" name="service" value="medical devices"><br>

                <label for="medicine_type">Medicine type</label>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
                <select class="add-medicaldevices-select" id="medicine_type" name="medicine_type">
                    <option value="first aid">First Aid</option>
                    <option value="health device">Health Devices</option>
                    <option value="support">Supports</option>
                </select><br>

                 <!-- auto incremented medicineID -->

                <div class="half-input-div"> 
                    <label for="Medicine_id">Medicine Id</label>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
                    <input type="text" class="add-medicaldevices-input" id="m_id" name="medicine_id" value="<?php echo $data['medicine_id']; ?>" ><br>
                    <span id="invalid-value"><?php echo $data['medicine_id_err']; ?></span>
                </div>
                
                <div class="half-input-div">
                    <label for="Medicine_name">Medicine Name</label>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
                    <input type="text" class="add-medicaldevices-input" id="m_name" name="medicine_name" value="<?php echo $data['medicine_name']; ?>" ><br>
                    <span id="invalid-value"><?php echo $data['medicine_name_err']; ?></span>
                </div>

                <div class="medicine-form-group">
                    <label for="Quantity_mesurement">Quantity mesurement</label> &nbsp&nbsp&nbsp&nbsp
                    <input type="text" class="add-medicaldevices-input" id="q_m" name="quantity_mesurement" value="<?php echo $data['quantity_mesurement']; ?>" ><br>
                </div>

                <div class="half-input-div">
                    <label for="Date_of_expiry">Date of Expiry</label> &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
                    <input type="date" class="add-medicaldevices-input" id="ex_date" name="expiry_date" value="<?php echo $data['date_of_expiry']; ?>" ><br>
                    <span id="invalid-value"><?php echo $data['date_of_expiry_err']; ?></span>
                </div>

                <div class="half-input-div">
                    <label for="Total_items">Total Items</label> &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
                    <input type="text" class="add-medicaldevices-input"id="count" name="total_items" value="<?php echo $data['total_items']; ?>" ><br>
                    <span id="invalid-value"><?php echo $data['total_items_err']; ?></span>
                </div>

                <div class="half-input-div">
                    <label for="price">Price(LKR)</label>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
                    <input type="text" class="add-medicaldevices-input" id="price" name="price" value="<?php echo $data['price']; ?>" ><br><br>
                    <span id="invalid-value"><?php echo $data['price_err']; ?></span>
                </div><br> 

                <div class="medicine-form-group">
                    <label for="File_input">File Input</label>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
                    <input type="file" class="add-medicaldevices-input" id="avatar" name="avatar" value="<?php echo $data['price']; ?>" ><br><br>
                </div>

                <div class="prescription-group">
                    <label id="prescription_label" for="File_input">Prescription Medicine</label>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
                    <input type="checkbox" class="add-medicaldevices-input" id="prescription_input" name="prescription" ><br><br>
                </div>

                <input type="submit" id="add-medicaldevices-bt1" name="add" value="add" class="view-medicaldevices-bt1">

                <a href="add_medicaldevices"><input type="button" id="add-medicaldevices-bt2" name="cancel" value="cancel" class="view-medicaldevices-bt1"></a><br><br>
            </form> 
        </div>
    </div>
<?php require APPROOT . '/views/inc/footer.php'; ?>