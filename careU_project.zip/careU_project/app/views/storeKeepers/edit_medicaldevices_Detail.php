<?php require APPROOT . '/views/inc/storekeeper_header.php'; ?>

<head>
    <link rel="stylesheet" type="text/css"
        href="<?php echo URLROOT; ?>/public/css/storekeepers/edit_medicine_Detail.css">
</head>

<div class="edit-medicine-div1">
    <p class="edit-medicine-heading">Edit Medical Devices</p>
    <div class="edit-medicine-div2">

        <form
            action="<?php echo URLROOT; ?>/StoreKeepers/edit_medicaldevices_form/<?php echo $data['medicine']->medicineID; ?>"
            method="POST" class="edit-medicine-form">

            <div class="edit-medicine-Detail-im">
                <img src="<?php echo URLROOT; ?>/public/img/medicine/<?php echo $data['medicine']->image; ?>" alt="call"
                    id="med_img">
            </div>

            <label for="Medicine_id">Medicine
                Id</label>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
            <input type="text" class="edit-medicine-input" id="m_id" name="medicine_id"
                value="<?php echo $data['medicine']->medicineID; ?>" disabled><br>

            <label for="Medicine_name">Medicine
                Name</label>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
            <input type="text" class="edit-medicine-input" id="m_name" name="medicine_name"
                value="<?php echo $data['medicine']->name; ?>" disabled><br>

            <label for="Quantity_mesurement">Quantity mesurement</label> &nbsp&nbsp&nbsp
            <input type="text" class="edit-medicine-input" id="q_m" name="quantity_mesurement"
                value="<?php echo $data['medicine']->quantity_measurement; ?>" disabled><br>

            <div class="half-input-div">
                <label for="Date_of_expiry">Date of Expiry</label>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
                <input type="date" class="edit-medicine-input" id="ex_date" name="expiry_date" value=<?php echo $data['medicine']->expiry_date; ?>><br>
                <span id="invalid-value"><?php echo $data['date_negative_err']; ?></span>
            </div>

            <label for="Total_items">Total Items</label>
            &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
            <input type="text" class="edit-medicine-input" id="count" name="total_items"
                value=<?php echo $data['medicine']->quantity; ?> disabled><br>
            <input type="hidden" class="edit-medicine-input" id="count" name="total_items_hidden" value=<?php echo $data['medicine']->quantity; ?>>

            <div class="half-input-div">    
                <label for="Price">Price (LKR)</label> &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
                <input type="text" class="edit-medicine-input" id="count" name="updated_price" value=<?php echo $data['medicine']->price; ?> ><br>
                <input type="hidden" class="edit-medicine-input" id="count" name="updated_price_hidden" value=<?php echo $data['medicine']->price; ?> ><br>
                <span id="invalid-value"><?php echo $data['price_negative_err']; ?></span>
            </div>

            <input type="radio" id="edit-medicine-radio" name="medicine_operation" value="add" checked="checked"> <label>Add Medicine</label>
            &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
            <input type="radio" id="edit-medicine-radio" name="medicine_operation" value="remove"> <label>Remove Medicine</label><br>


            <div class="half-input-div">
                <label for="Amount">Amount</label>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
                <input type="text" class="edit-medicine-input" id="updated_quantity" name="updated_quantity" value=0 ><br>
                <input type="hidden" class="edit-medicine-input" id="updated_quantity_hidden" name="updated_quantity_hidden" value=0 ><br>
                <span id="invalid-value"><?php echo $data['quantity_negative_err']; ?></span>
            </div>

            <input type="submit" id="edit-medicine-bt1" name="edit" value="submit" class="edit-medicine-bt1">

            <a href="<?php echo URLROOT; ?>/StoreKeepers/delete_medicine_heart"><input type="button"
                    id="edit-medicine-bt2" name="cancel" value="cancel" class="edit-medicine-bt2"></a><br><br>
        </form>
    </div>
</div>
<?php require APPROOT . '/views/inc/footer.php'; ?>