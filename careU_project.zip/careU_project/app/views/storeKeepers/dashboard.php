<?php require APPROOT . '/views/inc/storekeeper_header.php'; ?>
<head>
    <link rel="stylesheet" type="text/css" href="<?php echo URLROOT; ?>/public/css/storeKeepers/dashboard.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.5.0/Chart.min.js"></script>

</head>

<div class="head1">
    <p>Dashboard</p>
</div>

<div class="box1">
<h3><?php echo $data['meds_count'] ?></h3>
    <!-- <p>Available Medicines</p> -->  
</div>

<a href="<?php echo URLROOT; ?>/StoreKeepers/low_stock_reminder">
    <div class="box2">
        <h3><?php echo $data['lowstock_count'] ?></h3>
        <!-- <p>Low Stock Medicines</p> -->
    </div>
</a>

<a href="<?php echo URLROOT; ?>/StoreKeepers/expired_medicine_reminder">
    <div class="box3">
        <h3><?php echo $data['expired_count'] ?></h3>
        <!-- <p>Expired Medicines</p> -->
    </div>
</a>

<div class="chart">
    <canvas id="myChart"></canvas>

    <script>
        var xValues = ['january','february','march','april','may','june','july','august','september','october','november','december'];

        new Chart("myChart", {
            type: "line",
            data: {
                labels: xValues,
                datasets: [{
                    data: [
                   <?php echo $data['monthly_quantity'][0]; ?>,
                   <?php echo $data['monthly_quantity'][1]; ?>, 
                   <?php echo $data['monthly_quantity'][2]; ?>, 
                   <?php echo $data['monthly_quantity'][3]; ?>, 
                   <?php echo $data['monthly_quantity'][4]; ?>, 
                   <?php echo $data['monthly_quantity'][5]; ?>, 
                   <?php echo $data['monthly_quantity'][6]; ?>, 
                   <?php echo $data['monthly_quantity'][7]; ?>, 
                   <?php echo $data['monthly_quantity'][8]; ?>, 
                   <?php echo $data['monthly_quantity'][9]; ?>,
                   <?php echo $data['monthly_quantity'][10]; ?>, 
                   <?php echo $data['monthly_quantity'][11]; ?>
            ],
                    borderColor: "red",
                    fill: false
                }]
            },
            options: {
                legend: {
                    display: true
                },
                scales:{
                    yAxes:[{
                        scaleLabel:{
                            display:true,
                            labelString:'Sold Medicine count'
                        }
                    }],
                    xAxes:[{
                        scaleLabel:{
                            display:true,
                            labelString:'Month'
                        }
                    }]
                }
            }
        });
    </script>

</div>
<div class="head2">
    <p>Quantity Analysis</p>
</div>
<?php require APPROOT . '/views/inc/footer.php'; ?>