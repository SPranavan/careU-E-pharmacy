<?php require APPROOT . '/views/inc/storekeeper_header.php'; ?>
    
    <!-- <?php session_start(); ?> -->

    <head>
        <link rel="stylesheet" type="text/css" href="<?php echo URLROOT; ?>/public/css/storekeepers/view_medicine.css">
    </head>

    //search box
    <form class="search-container" method="POST" action="<?php echo URLROOT; ?>/StoreKeepers/search_medicine_diabetes">
        <input type="text" name="search" placeholder="Search..." >
        <button type="submit" name="submit">🔎</button>
    </form>

    <div class="view-medicine-div1">
        <p class="view-medicine-heading-1">View Medicine</p>
        <div class="view-medicine-div2">
            <br><a href="view_medicine_heart">Heart</a><br><br>
            <a class="current">Diabetes</a><br><br>
            <a href="view_medicine_infection">Infection</a><br><br>
            <a href="view_medicine_gastro">Gastro Infectional System</a><br><br>
            <a href="view_medicine_muscle">Muscle and Joint</a>
        </div>

        <div class="tablefixed">
        <!-- <p class="view-medicine-heading-2">Initiated Orders</p> -->
        <table class="table-8">
            <thead>
                <tr>
                    <th span="1" style="width: 12%;">Id</th>
                    <th span="1" style="width: 25%;">Name</th>
                    <th span="1" style="width: 12%;">Generic Name</th>
                    <th span="1" style="width: 15%;">Price(LKR)</th>
                    <th span="1" style="width: 11%;">Total Items</th>
                    <th span="1" style="width: 25%;">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    $countdata = count($data);
                    for ($i = 0; $i < $countdata; $i++) {

                        echo '
                        <tr>
                        <td>' . $data[$i]->medicineID . '</td>
                        <td>' . $data[$i]->name . '</td>
                        <td>' . $data[$i]->quantity_measurement . '</td>
                        <td>' . $data[$i]->price . '</td>
                        <td>' . $data[$i]->quantity . '</td>
                        <td><a href="'.URLROOT.'/StoreKeepers/show_medicine/' . $data[$i]->medicineID .'"><button>View</button></a></td>
                        </tr>';
                    }
                ?>                
            </tbody>
        </table>
        </div>
    </div>
<?php require APPROOT . '/views/inc/footer.php'; ?>