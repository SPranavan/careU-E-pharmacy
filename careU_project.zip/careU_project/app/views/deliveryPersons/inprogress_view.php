<?php require APPROOT . '/views/deliveryPersons/deliveryPerson_header2.php'; ?>

<link rel="stylesheet" type="text/css" href="<?php echo URLROOT; ?>/public/css/deliveryPersons/viewmore.css">


<main class="content" >

<div id="blur" class="container">

<div class="body-left-view-vm">
    
    
    <h3 class="viewer-name-t">Customer Details:</h3>
    
    <div class="container4">
    <hr>
    <div class="row">
                <div class="col-25">
                    <label for="cusID">Customer ID:</label>
                </div>
                <div class="col-75">
                    <input type="text" id="customerID" name="customerID" value="<?php echo $data['delivery_details']->customerID; ?>" readonly>
                    <br><br>
                </div>
                </div> 

                <div class="row">
                <div class="col-25">
                    <label for="name">First Name:</label>
                </div>
                <div class="col-75">
                <input type="text" id="fname" name="fName" value="<?php echo $data['user_details']->fName; ?>" readonly><br>
                    
                <br>
                </div>
                </div>

                <div class="row">
                <div class="col-25">
                    <label for="name">Last Name:</label>
                </div>
                <div class="col-75">
                <input type="text" id="lname" name="lName" value="<?php echo $data['user_details']->lName; ?>" readonly><br>
                    
                <br>
                </div>
                </div>

                <div class="row">
                <div class="col-25">
                    <label for="telNo">Contact Number:</label>
                </div>
                <div class="col-75">
                    <input type="tel" id="telNo" name="mobile" value="<?php echo $data['user_details']->mobile; ?>" placeholder="07Xxxxxxxx" readonly><br>
                    <br>
                </div>
                </div>

                <div class="row">
                <div class="col-25">
                    <label for="mail">Email:</label>
                </div>
                <div class="col-75">
                    <input type="email" id="mail" name="email" value="<?php echo $data['user_details']->email; ?>" readonly><br>
                    <br>
                </div>
                </div>

                <div class="row">
                <div class="col-25">
                    <label for="sa">Street Address:</label>
                </div>
                <div class="col-75">
                    <input type="text" id="sa" name="address" value="<?php echo $data['user_details']->address; ?>" readonly><br>
                    <br>
                </div>
                </div>

                <div class="row">
                <div class="col-25">
                    <label for="city">City:</label>
                </div>
                <div class="col-75">
                    <input type="text" id="city" name="city" value="<?php echo $data['user_details']->city; ?>" readonly><br>
                    <br>
                </div>
                </div>


    </div>
    
    
</div>


    <div class="body-right-view-vm">
    <h3 class="viewer-name-tt">Order Details:</h3>
    <br>
    

            <div class="container5">

            <hr>

                <div class="row">
                <div class="col-25">
                    <label for="delID">Delivery ID:</label>
                </div>
                <div class="col-75">
                    <input type="text" id="deliveryID" name="deliveryID" value="<?php echo $data['delivery_details']->deliveryID; ?>" readonly>
                    <br><br>
                </div>
                </div> 

                <div class="row">
                <div class="col-25">
                    <label for="odID">Order ID:</label>
                </div>
                <div class="col-75">
                    <input type="text" id="orderId" name="orderId" value="<?php echo $data['delivery_details']->OrderPresID; ?>" readonly>
                    <br><br>
                </div>
                </div> 

                <div class="row">
                <div class="col-25">
                    <label for="invID">Invoice ID:</label>
                </div>
                <div class="col-75">
                    <input type="text" id="invoiceID" name="invoiceID" value="<?php echo $data['delivery_details']->invoiceID; ?>" readonly>
                    <br><br>
                </div>
                </div> 

                <div class="row">
                <div class="col-25">
                    <label for="oDate">Order Date:</label>
                </div>
                <div class="col-75">
                    <input type="datetime-local" id="date" name="date" value="<?php echo $data['delivery_details']->orderDate; ?>" readonly><br>
                    <br>
                </div>
                </div>

                <div class="row">
                <div class="col-25">
                    <label for="aDate">Accepted Date:</label>
                </div>
                <div class="col-75">
                    <input type="datetime-local" id="acceptDate" name="acceptDate" value="<?php echo $data['delivery_details']->acceptDate; ?>" readonly><br>
                    <br>
                </div>
                </div>

                <div class="row">
                <div class="col-25">
                    <label for="status">Status:</label>
                </div>
                <div class="col-75">
                <input type="text" id="availability_status" name="availability_status" value="<?php if ($data['delivery_details']->availability_status == 'in progress') { echo 'In Progress'; } ?>" readonly><br>
                    
                    <br>
                </div>
                </div>

                

                          
                   
        

                <form id="deliveryForm" action="<?php echo URLROOT; ?>/deliveryPersons/inprogress_action" method="POST">
                <div class="row">
                    <input type="hidden" name="deliveryID" value="<?php echo $data['delivery_details']->deliveryID;?>">
                    <input type="hidden" name="orderId" value="<?php echo $data['delivery_details']->orderId;?>">

                    <input type="submit" value="Reject" class="reject" name="reject">
                    <input type="submit" value="Confirm Delivery" class="confirm" name="confirm">
                    <a href="<?php echo URLROOT; ?>/deliveryPersons/inprogress_orders ?>" class="goback"><span>Back</span></a>
                </div>

            <div id="popup" class="popup">
            <div class="popup-content">
                <h2>Reject Delivery</h2>
                <p>Are you sure you want to proceed?</p>
                <div class="input-container">
                    <textarea id="popupTextarea" name="popupTextarea" placeholder="Reason for rejection:"></textarea>
                    <input type="hidden" value="reject" id="rejectDelivery">
                </div>
                <div class="button-container">
                    <button id="cancelBtn">Cancel</button>
                    <button id="confirmBtn">Confirm</button>
                </div>
            </div>
        </div>
        </form>

<div class="confirmation-popup1" id="confirmationPopup">
    <div class="confirmation-popup1-content">
        <h2>Confirm Delivery</h2>
        <p>Are you sure you want to confirm the delivery?</p>
        <button id="cancelConfirmationBtn">Cancel</button>
        <button id="confirmDeliveryBtn">Confirm</button>
    </div>
</div>



<script>
    document.addEventListener('DOMContentLoaded', function () {
        var deliveryForm = document.getElementById('deliveryForm');
        var confirmationPopup = document.getElementById('confirmationPopup');
        var cancelConfirmationBtn = document.getElementById('cancelConfirmationBtn');
        var confirmDeliveryBtn = document.getElementById('confirmDeliveryBtn');
        var popup = document.getElementById('popup');
        var cancelBtn = document.getElementById('cancelBtn');
        var confirmBtn = document.getElementById('confirmBtn');
        var popupTextarea = document.getElementById('popupTextarea');
        var rejectDelivery = document.getElementById('rejectDelivery');
        var currentForm = null;

        // Handle confirm delivery button click
        confirmDeliveryBtn.addEventListener('click', function () {
            if (currentForm) {
                currentForm.submit(); // Submit the form
                currentForm = null;
            }
            confirmationPopup.style.display = 'none';
        });

        // Handle cancel confirmation button click
        cancelConfirmationBtn.addEventListener('click', function () {
            confirmationPopup.style.display = 'none';
        });

        // Attach event listeners to all confirm buttons
        var confirmBtns = document.querySelectorAll('.confirm');
        confirmBtns.forEach(function (btn) {
            btn.addEventListener('click', function (event) {
                event.preventDefault();
                currentForm = btn.closest('form');
                confirmationPopup.style.display = 'block';
            });
        });

        // Handle reject button click
        var rejectBtn = document.querySelector('.reject');
        rejectBtn.addEventListener('click', function (event) {
            event.preventDefault();
            currentForm = rejectBtn.closest('form');
            popup.style.display = 'block';
        });

        // Handle confirm rejection button click
        confirmBtn.addEventListener('click', function() {
    // Get the textarea value
            const reason = popupTextarea.value.trim();

            if (reason === '') {
                alert('Please provide a reason.');
                return;
            }

            // Set the textarea value to the hidden input field
            rejectDeliveryInput.value = reason;

            // Submit the form
            confirmationForm.submit();

            // Hide the popup
            popup.style.display = 'none';
        });

        // Handle cancel rejection button click
        cancelBtn.addEventListener('click', function () {
            popup.style.display = 'none';
        });
    });
</script>






    
   
</main>



        
 




<?php require APPROOT . '/views/inc/footer.php'; ?>