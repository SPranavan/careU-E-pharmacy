<?php require APPROOT . '/views/deliveryPersons/deliveryPerson_header2.php'; ?>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <main class="content">

    <img class="deliveryLogo1" src="<?php echo URLROOT;?>/public/img/deliveryPersons/delivery_logo.png" alt="AdminLogo">
    <div>
        <div class="btnset1">
        <a href="<?php echo URLROOT; ?>/deliveryPersons/pending_orders"><button class="dashbtn2">Pending Orders <hr><br><i><?php echo $data['countPendingOrders'] ?></i></button></a>
        <a href="<?php echo URLROOT; ?>/deliveryPersons/inprogress_orders"><button class="dashbtn2">In-Progress Orders<hr><br><i><?php echo $data['countInprogressOrders'] ?></i></button></a>
        <a href="<?php echo URLROOT; ?>/deliveryPersons/delivered_orders"><button class="dashbtn2">Delivered Orders<hr><br><i><?php echo $data['countDeliveredOrders'] ?></i></button></a>


        </div>
       
    </div>

    <div class="audit-logs">
            <h2>Audit Logs</h2>
            <hr>
            <ul id="audit-log-list">
            <?php foreach ($data['getDeliveredOrdersDetails'] as $detail): ?>
                    <li>Delivery ID: <?php echo $detail->deliveryID ; ?> order <?php echo $detail->availability_status; ?> on <?php if ($detail->deliveredDate !== null) {echo $detail->deliveredDate;
            } else {
                echo $detail->rejectedDate;
            } ?></li>
            <?php endforeach; ?>
                <!-- More log entries will be dynamically populated here -->
            </ul>
    </div>
        

    <div class="container7">
    <h1>Delivery Report</h1>
    <div class="chart-container">
      <canvas id="pie-chart" width="280px" height="280px"></canvas>
    </div>
    </div>

        
    </main>

    <script>
      document.addEventListener('DOMContentLoaded', function() {
      var deliveryStatusCounts = <?php echo json_encode($data['deliveryStatusCounts']); ?>;
      
      var labels = deliveryStatusCounts.map(function(item) {
        return item.availability_status === 'delivered' ? 'Delivered' : 'Rejected';
      });
      
      var counts = deliveryStatusCounts.map(function(item) {
        return item.count;
      });
      
      var ctx = document.getElementById('pie-chart').getContext('2d');
      var chart = new Chart(ctx, {
        type: 'pie',
        data: {
          labels: labels,
          datasets: [{
            label: 'Delivery Status',
            data: counts,
            backgroundColor: [
              '#855C74',
              '#84B0CF'
            ],
            borderWidth: 1
          }]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            tooltip: {
              callbacks: {
                label: function(context) {
                  var label = context.label || '';
                  var value = context.parsed || 0;
                  var dataset = context.dataset || {};
                  var total = dataset.data.reduce(function(acc, val) {
                    return acc + val;
                  });
                  var percentage = total > 0 ? ((value / total) * 100).toFixed(2) + '%' : '0%';
                  return label + ': ' + value + ' (' + percentage + ')';
                }
              }
            }
          },
          legend: {
            position: 'right'
          }
        }
      });
    });




    </script>


<?php require APPROOT . '/views/inc/footer.php'; ?>