<?php require APPROOT . '/views/deliveryPersons/deliveryPerson_header.php'; ?>


    <main class="content" >

    <div id="blur" class="container">
    
    
        <div class="body-right-view">
          <h3 class="topic1-view">Pending Orders</h3>

          <div class="search-container">
                        <form action="<?php echo URLROOT;?>/admins/search_manager" method="POST">
                            <input type="text" placeholder="Search..." name="search" id="search">
                            <button type="submit" name="search" id="btn-search"><i class="fa fa-search"></i></button>
                        </form>
          </div>
          <br>

            <div class="container2-view">

            <table>
                
                    <tr>
                        <th style="width:10%">Order/Pres ID</th>
                        <th style="width:15%">Invoice ID</th>
                        <th style="width:15%">Customer ID</th>
                        <th style="width:20%">Order Date</th>
                        <th style="width:30%">Shipping Address</th>
                        <th style="width:10%">Action</th>
                    </tr>
                    <!-- PHP CODE TO FETCH DATA FROM ROWS -->
                    
                    <tbody class="all-data">

                        <?php 
                                                                                                                                                                                                                        
                            // Assuming $PendingOrdersDetails and $PendingOrdersPresDetails are arrays

                            // Loop through PendingOrdersDetails
                            foreach ($data['PendingOrdersDetails'] as $orderObject) {
                                echo '
                                <tr class="dataset1">
                                    <td>OD'. $orderObject->orderID . '</td>
                                    <td>' . $orderObject->invoiceID . '</td>
                                    <td>' . $orderObject->customerID . '</td>
                                    <td>' . $orderObject->date . '</td>
                                    <td>
                                        <form action="'.URLROOT.'/deliveryPersons/locate" method="POST">
                                            <input type="hidden" name="customerID" value="' . $orderObject->customerID . '">
                                            <input type="hidden" name="address" value="' . $orderObject->address . '">
                                            <input type="hidden" name="city" value="' . $orderObject->city . '">
                                            <input type="submit" id="location" value="' . $orderObject->address . " " . $orderObject->city . '">
                                        </form>
                                    </td>
                                    <td class="vm">
                                        <form id="confirmationForm" action="'.URLROOT.'/deliveryPersons/accept_pendingOrder" method="POST">
                                            <input type="hidden" name="orderID" value="' . $orderObject->orderID . '">
                                            <input type="hidden" name="customerID" value="' . $orderObject->customerID . '">
                                            <input type="hidden" name="invoiceID" value="' . $orderObject->invoiceID . '">
                                            <input type="hidden" name="date" value="' . $orderObject->date . '">
                                            <button id="submitBtn" class="viewMore" type="submit">Accept</button>
                                        </form>
                                    </td>
                                </tr>
                                ';
                            }

                            // Loop through PendingOrdersPresDetails
                            foreach ($data['PendingOrdersPresDetails'] as $orderPresObject) {
                                echo '
                                <tr class="dataset1">
                                    <!-- Display the relevant columns from customer_prescription table -->
                                    <td>P' . $orderPresObject->prescriptionID . '</td>
                                    <td>' . $orderPresObject->invoiceID . '</td>
                                    <td>' . $orderPresObject->customerID . '</td>
                                    <td>' . $orderPresObject->date . '</td>
                                    <td>
                                        <form action="'.URLROOT.'/deliveryPersons/locate" method="POST">
                                            <input type="hidden" name="customerID" value="' . $orderPresObject->customerID . '">
                                            <input type="hidden" name="address" value="' . $orderPresObject->address . '">
                                            <input type="hidden" name="city" value="' . $orderPresObject->city . '">
                                            <input type="submit" id="location" value="' . $orderPresObject->address . " " . $orderPresObject->city . '">
                                        </form>
                                    </td>
                                    <td class="vm">
                                        <form id="confirmationForm" action="'.URLROOT.'/deliveryPersons/accept_pendingOrder" method="POST">
                                            <input type="hidden" name="prescriptionID" value="' . $orderPresObject->prescriptionID . '">
                                            <input type="hidden" name="customerID" value="' . $orderPresObject->customerID . '">
                                            <input type="hidden" name="invoiceID" value="' . $orderObject->invoiceID . '">
                                            <input type="hidden" name="date" value="' . $orderObject->date . '">
                                            <button id="submitBtn" class="viewMore" type="submit">Accept</button>
                                        </form>
                                    </td>
                                </tr>
                                ';
                            }

                        
                        ?>
                
                    </tbody>
                    <tbody id="details" class="search-data"></tbody>
                                      
                    
            </table>

          
                
            </div>
        </div>
    </div>
    <div class="confirmation-popup" id="confirmationPopup">
        <div class="confirmation-popup-content">
            <h2>Confirm Action</h2>
            <p>Are you sure you want to proceed?</p>
            <button id="cancelBtn">Cancel</button>
            <button id="confirmBtn">Confirm</button>
        </div>
        
    </div>                      
        
       
    </main>

    

    
<script src="<?php echo URLROOT;?>/public/js/deliveryPersons/search_pendingOrders.js"></script>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        var submitBtns = document.querySelectorAll('.viewMore');
        var confirmationPopup = document.getElementById('confirmationPopup');
        var confirmBtn = document.getElementById('confirmBtn');
        var cancelBtn = document.getElementById('cancelBtn');
        var currentForm = null;
        
        // Attach event listeners to all submit buttons
        submitBtns.forEach(function (btn) {
            btn.addEventListener('click', function (event) {
                event.preventDefault();
                currentForm = btn.closest('form');
                confirmationPopup.style.display = 'block';
            });
        });
        
        // Handle confirm button click
        confirmBtn.addEventListener('click', function () {
            if (currentForm) {
                currentForm.submit(); // Submit the form
                currentForm = null;
            }
            confirmationPopup.style.display = 'none';
        });
        
        // Handle cancel button click
        cancelBtn.addEventListener('click', function () {
            confirmationPopup.style.display = 'none';
        });
    });
</script>

    


<?php require APPROOT . '/views/inc/footer.php'; ?>

