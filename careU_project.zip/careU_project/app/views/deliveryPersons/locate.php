<?php require APPROOT . '/views/deliveryPersons/deliveryPerson_header2.php'; ?>

<link rel="stylesheet" type="text/css" href="<?php echo URLROOT; ?>/public/css/deliveryPersons/locate.css">


<main class="content" >

<div id="blur" class="container">

    <div class="body-left-view-vm">
        
        
        <h3 class="viewer-name-t">Customer Details:</h3>
        
        <div class="container4">
        <hr>
                
                    <div class="row">
                    <div class="col-25">
                        <label for="name">First Name:</label>
                    </div>
                    <div class="col-75">
                    <input type="text" id="fname" name="fName" value="<?php echo $data['user_details']->fName; ?>" readonly><br>
                        
                    <br>
                    </div>
                    </div>

                    <div class="row">
                    <div class="col-25">
                        <label for="name">Last Name:</label>
                    </div>
                    <div class="col-75">
                    <input type="text" id="lname" name="lName" value="<?php echo $data['user_details']->lName; ?>" readonly><br>
                        
                    <br>
                    </div>
                    </div>

                    <div class="row">
                    <div class="col-25">
                        <label for="telNo">Contact Number:</label>
                    </div>
                    <div class="col-75">
                        <input type="tel" id="telNo" name="mobile" value="<?php echo $data['user_details']->mobile; ?>" placeholder="07Xxxxxxxx" readonly><br>
                        <br>
                    </div>
                    </div>


                    <div class="row">
                    <div class="col-25">
                        <label for="sa">Street Address:</label>
                    </div>
                    <div class="col-75">
                        <input type="text" id="sa" name="address" value="<?php echo $data['user_details']->address; ?>" readonly><br>
                        <br>
                    </div>
                    </div>

                    <div class="row">
                    <div class="col-25">
                        <label for="city">City:</label>
                    </div>
                    <div class="col-75">
                        <input type="text" id="city" name="city" value="<?php echo $data['user_details']->city; ?>" readonly><br>
                        <br>
                    </div>
                    </div>

                    <div class="row">
                    <div class="col-25">
                        <label for="distance">Distance:</label>
                    </div>
                    <div class="col-75">
                        <input type="text" id="distance" name="distance" readonly><br>
                        <br>
                    </div>
                    </div>

                    <div class="row">
                    <div class="col-25">
                        <label for="duration">Duration:</label>
                    </div>
                        <div class="col-75">
                        <input type="text" id="duration" name="duration" readonly><br>
                        <br>
                    </div>
                    </div>




        </div>
                
                
    </div>

    <div class="body-right-view-vm">
    <h3 class="viewer-name-tt">Customer Location:</h3>
    <br>
  
        <div class="container5">

        <div id="map"></div>



        
            
            <input type="text" id="origin" value="University of Colombo School of Computing (UCSC), Reid Avenue, Colombo" required hidden>
        
            <input type="text" id="destination" value="<?php echo $data['user_details']->address." ".$data['user_details']->city; ?>" required hidden>

        

        <!-- <h4 id="distance"></h4>
        <h4 id="duration"></h4> -->
            


        </div>

    
        <a href="#" onclick="goBack()" class="goback1"><span>Back</span></a>


    </div>
                    
    <script>
        function goBack() {
        window.history.back();
}
    </script>

        




      
    
</div>
    

</main>






<script src="<?php echo URLROOT; ?>/public/js/deliveryPersons/map_location.js"></script>
<script async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAuawB84ojWUPczseHsvUXperl0uuUO--A&callback=initMap"></script>





<?php require APPROOT . '/views/inc/footer.php'; ?>