<?php 
// session_start();

    class Customers extends Controller{

        //Create varibale to connect to DB
        private $CustomerModel;

        //Assigned 'Customer' model file
        public function __construct()
        {
            $this->CustomerModel = $this->model('Customer');
        }

        public function home()
        {
            $this->CustomerModel = $this->model('Customer');
            $data ="";
            $this->view('customers/home', $data);
        }

        public function about()
        {
            $this->CustomerModel = $this->model('Customer');
            $data ="";
            $this->view('customers/about', $data);
        }

     


        public function edit_information()
        {
            $this->CustomerModel = $this->model('Customer');
            // Set $uid to current user's ID if not provided
            // if (is_null($uid) && isset($_SESSION['user_ID'])) {
                $uid = $_SESSION['user_ID'];
            // }

            // Check if form is submitted
            if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                    // Sanitize user input
                    $_POST = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING);

                    // Get user's current record
                    // $row = $this->CustomerModel->findUserByID($uid);

                    // Update user's record with new information
                    // $row['email'] = trim($_POST['email']);
                    // $row['mobile'] = trim($_POST['mobile']);
                    // $row['address'] = trim($_POST['address']);
                    // $row['city'] = trim($_POST['city']);

                    $email = trim($_POST['email']);
                    $mobile = trim($_POST['mobile']);
                    $address = trim($_POST['address']);
                    $city = trim($_POST['city']);
// print_r($email,$mobile,$address,$city);die();
                    // Save updated record to database
                    $this->CustomerModel->updateUser($email,$mobile,$address,$city);

                    // Redirect to account page with success message
                    header('Location: ' . URLROOT . '/customers/myaccount/');
                    exit;
            }
            
            $row = $this->CustomerModel->findUserByID($uid);

            $data=[
                'user' => $row
            ];            
            
            $this->view('customers/edit_information', $data);
        }

        public function change_password()
        {
            $this->CustomerModel = $this->model('Customer');
                $data ="";
            $this->view('customers/change_password', $data);
        }

        public function feedback()
        {
            $this->CustomerModel = $this->model('Customer');
            $data ="";
            $this->view('customers/feedback', $data);
        }

        public function myaccount($uid = null)
        {
            $this->CustomerModel = $this->model('Customer');
            // Set $uid to current user's ID if not provided
            if (is_null($uid) && isset($_SESSION['user_ID'])) {
                $uid = $_SESSION['user_ID'];
            }
            $row = $this->CustomerModel->findUserByID($uid);

            $data=[
                'user' => $row
            ];

            $this->view('customers/myaccount', $data);
        }

        public function cancelorder($id)
        {
            $data = [];
            $res = $this->CustomerModel->cancelorder($id);

            // if($res){
            //     $this->view('customers/cart', $data);
            // }

            redirect("Customers/order_details");
            // header('Location: ' . URLROOT . '/customers/cart/');
            exit;
        }

        public function deletecart($id)
        {
            $data = [];
            $res = $this->CustomerModel->deletecart($id);

            // if($res){
            //     $this->view('customers/cart', $data);
            // }

            redirect("Customers/cart");
            // header('Location: ' . URLROOT . '/customers/cart/');
            exit;
            
        }

        public function updatecart($id)
        {
            //  print_r($_POST['quantity']);die();
            $quan = $_POST['quantity'];
            $data = [];

            $res = $this->CustomerModel->updatecart($id,$quan);
            // print_r($_POST['quantity']);die();

            if ($res) {
                // $this->view('customers/cart', $data);
                redirect("Customers/cart");
            }
            
        }



        
        public function sum(){
            $this->CustomerModel = $this->model('Customer');
            $total = $this->CustomerModel->sum();
            $data['total'] = $total;
            // $this->view('customers/cart', $data);
        }




        public function cart()
        {          
            $this->CustomerModel = $this->model('Customer');

            // Delete item from cart if delete button is clicked

            $medicine = $this->CustomerModel->showcart();
            // print_r($medicine);die();
            $sub_total = $this->CustomerModel->cart_sum();

            // if ($quantity <= $medicine[0]->quantity) {
            //     $new_quantity = $medicine[0]->quantity - $quantity;
            //     $this->CustomerModel->updatecart($medicineID, $new_quantity);
            // } else {
            //     echo "Sorry, the quantity ordered is not available.";
            // }

            $data=[
                'medicine'=>$medicine,
                'sub_total'=>$sub_total
            ];
            
            // print_r($row);die();
            $this->view('customers/cart', $data);

            
        }


        public function payhereprocess(){
            $this->CustomerModel = $this->model('Customer');

            $data='';
            $this->view('customers/payhereprocess', $data);

        }

        public function order_details()
        {          
            $this->CustomerModel = $this->model('Customer');
            // $uid = $_SESSION['user_ID'];
            

            $medicine = $this->CustomerModel->showorder();
            // print_r($medicine);die();
       
            $data=[
                'medicine'=>$medicine,
                // 'sub_total'=>$sub_total
            ];
            
            // print_r($row);die();
            $this->view('customers/order_details', $data);
   
        }

        public function cancel_order()
        {          
            $this->CustomerModel = $this->model('Customer');
            // $uid = $_SESSION['user_ID'];
            

            $medicine = $this->CustomerModel->showorder();
            // print_r($medicine);die();
       
            $data=[
                'medicine'=>$medicine,
                // 'sub_total'=>$sub_total
            ];
            
            // print_r($row);die();
            $this->view('customers/cancel_order', $data);
   
        }


        public function cart_finish(){
            $this->CustomerModel = $this->model('Customer');
            $this->CustomerModel->deletecartall($cartID);

            $data='';
            redirect("customers/home");

        }


        public function prescription_upload()
        {
            $this->CustomerModel = $this->model('Customer');
            if (isset($_POST["submit"]) && !empty($_FILES["file"]["name"]))     {
                //retrieve file title
                $message = $_POST["message"];

                //upload directory path
                $uploads_dir = 'C:\xampp\htdocs\careU_project\public\img\prescription';

                $pname = basename($_FILES["file"]["name"]);
                // print_r($pname);die();  
                // $target_file = $uploads_dir . $filename;
        
                //file name with a random number so that similar dont get replaced
                $pname = rand(1000,10000)."-".$_FILES["file"]["name"];
        
                //temporary file name to store file
                $tname = $_FILES["file"]["tmp_name"];
        
                $date=date('Y-m-d H:i:s');

                $cid=$_SESSION['user_ID'];

                
        
                // get the file type
                $file_type = strtolower(pathinfo($_FILES["file"]["name"], PATHINFO_EXTENSION));
        
                // check if the file is an image
                if ($file_type != "jpg" && $file_type != "jpeg" && $file_type != "png") {
                    echo "<script>
                        alert('Error: Only JPG, JPEG, and PNG files are allowed');
                        </script>";
                    exit;
                }
            
                //TO move the uploaded file to specific location
                move_uploaded_file($tname, $uploads_dir.'/'.$pname);


                $r=$this->CustomerModel->upload_prescription_db($cid,$pname,$message,$date);
                $this->view('customers/home', $data);

                if($r=="true"){
                    echo "<script>
                         alert('Successfully Added');
                         </script>";
                }else{
                    echo "Error";
                }
                
            }
            $this->view('customers/prescription_upload');
        }

        public function order()
        {
          $this->CustomerModel = $this->model('Customer');

        // Create multiple arrays to hold different sets of data
        $Medicine = [
            'title' => 'Medicine',
            'items' => $this->CustomerModel->Medicine()
        ];

        $Personal_Care = [
            'title' => 'Personal Care',
            'items' => $this->CustomerModel->Personal_Care()
        ];

        $Medical_Equipments = [
            'title' => 'Medical Devices',
            'items' => $this->CustomerModel->Medical_Devices()
        ];

        $data = [$Medicine, $Personal_Care, $Medical_Equipments]; // Combine all data arrays into a single array

        $this->view('customers/order', $data);
        }


        
        public function medicine(){
            $this->CustomerModel = $this->model('Customer');
            $item = $this->CustomerModel->Medicine();
            $data=$item;
            
            $this->view('Customers/medicine', $data);
        }

        public function personal_care(){
            $this->CustomerModel = $this->model('Customer');
            $items = $this->CustomerModel->Personal_Care();
            $data=$items;
            $this->view('Customers/personal_care', $data);
        }

        public function medical_devices(){
            $this->CustomerModel = $this->model('Customer');
            $items = $this->CustomerModel->Medical_Devices();
            $data=$items;
            $this->view('Customers/medical_devices', $data);
        }


        public function upload_prescription_image(){
            $this->CustomerModel = $this->model('Customer');
            if (isset($_POST["submit"]) && !empty($_FILES["file"]["name"]))     {
                //retrieve file title
                $message = $_POST["message"];

                //upload directory path
                $uploads_dir = 'C:\xampp\htdocs\careU_project\public\img\prescription';

                $pname = basename($_FILES["file"]["name"]);
                // print_r($pname);die();  
                // $target_file = $uploads_dir . $filename;
        
                //file name with a random number so that similar dont get replaced
                $pname = rand(1000,10000)."-".$_FILES["file"]["name"];
        
                //temporary file name to store file
                $tname = $_FILES["file"]["tmp_name"];
        
                $date=date('Y-m-d H:i:s');

                $cid=$_SESSION['user_ID'];

                $data='';
        
                // get the file type
                $file_type = strtolower(pathinfo($_FILES["file"]["name"], PATHINFO_EXTENSION));
        
                // check if the file is an image
                if ($file_type != "jpg" && $file_type != "jpeg" && $file_type != "png") {
                    echo "<script>
                        alert('Error: Only JPG, JPEG, and PNG files are allowed');
                        </script>";
                    exit;
                }
            
                //TO move the uploaded file to specific location
                move_uploaded_file($tname, $uploads_dir.'/'.$pname);



                $id=$this->CustomerModel->getlastID();
                $r=$this->CustomerModel->upload_prescription_db($cid,$pname,$message,$date,$id);
                $this->view('customers/home', $data);

                if($r=="true"){
                    echo "<script>
                         alert('Successfully Added');
                         </script>";
                }else{
                    echo "Error";
                }
                
            }
            $this->view('customers/home', $data);

        }


        public function feedback_upload(){
            $this->CustomerModel = $this->model('Customer');
            if (isset($_POST["submit"]))     {
                $date=date('Y-m-d H:i:s');
                $message = $_POST["message"];
                $cid = $_SESSION['user_ID'];

                $r=$this->CustomerModel->feedback_upload($date,$cid,$message);


                $this->view('customers/home');
                echo "<script>
                      alert('Feedback Successfully Added');
                      </script>";
                
            }
        
        }

        public function order_upload(){
            $this->CustomerModel = $this->model('Customer');
            if (isset($_POST["addCart"])) {
                $cid = $_SESSION['user_ID'];
                $medicineID = $_POST["medicineID"];
                $date = date('Y-m-d H:i:s');

            $return=$this->CustomerModel->order_upload($cid,$medicineID,$date);

            $data='';
            
            // $this->view('customers/cart', $data);
            if($return)
                redirect('Customers/cart');
            }
            else{
                die();
            }
        }

         public function change_pw()
        {
            $this->CustomerModel = $this->model('Customer');
            $data ="";
            $this->view('customers/change_password', $data);
        }

        public function update_pw()
        {
            $this->CustomerModel = $this->model('Customer');
            $data ="";
            //print_r($_POST);die();
            $cur_pw = $_POST['cur_pw']; 
            $res = $this->CustomerModel->getuserdetails($_SESSION['email']);
            if (password_verify($cur_pw,$res[0]->password)) {
                if ($_POST['new_pw'] == $_POST['con_pw'] ) {
                    $hashed = password_hash($_POST['new_pw'], PASSWORD_DEFAULT);
                    $res = $this->CustomerModel->updatePassword($_SESSION['email'],$hashed);
                    if ($res) {
                        header('Location: ./myaccount');
                    }
                }
                else {
                    $_SESSION['error2'] = "Passwords Not Match";
                    $this->view('customer/change_password', $data);
                    exit();
                }
            }
            else {
                $_SESSION['error1'] = "Incorrect Password";
                $this->view('customer/change_password', $data);
                exit();
            }
            
        }


}