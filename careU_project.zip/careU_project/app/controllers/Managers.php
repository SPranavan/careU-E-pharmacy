<?php 
    class Managers extends Controller{

        //Create variable to connect to DB
        private $userModel;

        //Assigned 'User' model file
        public function __construct(){
            $this->userModel = $this->model('User');
        }

        public function index(){
            if (!isset($_SESSION['login'])) {
                redirect('users/login');
            }
            $this->userModel=$this->model('User');
            
            $data='';
            $this->view('managers/dashboard',$data);
        }
        
        public function dashboard(){
            if (!isset($_SESSION['login'])) {
                redirect('users/login');
            }
            $this->ManagerModel=$this->model('Manager');

            $feedback_count=$this->ManagerModel-> get_feedback_count();
            $available_deliveryguy_count=$this->ManagerModel-> get_deliveryguy_count();
            $pending_count=$this->ManagerModel-> get_pending_count();
            $cancelled_count=$this->ManagerModel-> get_cancelled_count();
            $completed_count=$this->ManagerModel-> get_completed_count();

            $sales_array = $this->ManagerModel->updateSalesReport();                  //calculate the sales_report table according to orders 

            $data=[
                'feedback_count'=>$feedback_count,
                'deliverypersons_count'=>$available_deliveryguy_count,
                'pending_count'=>$pending_count,
                'cancelled_count'=>$cancelled_count,
                'completed_count'=>$completed_count,
                'monthly_sales'=>$sales_array
            ];

            $this->view('managers/dashboard',$data);
        }

        //view

        public function Initiated_orders(){
            if (!isset($_SESSION['login'])) {
                redirect('users/login');
            }
            $this->ManagerModel=$this->model('Manager');
            $initiated_orders = $this->ManagerModel-> getInitiatedOrders();
            $data=$initiated_orders;
            $this->view('managers/initiated_orders',$data);
        }

        public function Completed_orders(){
            if (!isset($_SESSION['login'])) {
                redirect('users/login');
            }
            $this->ManagerModel=$this->model('Manager');
            $initiated_orders = $this->ManagerModel-> getCompletedOrders();
            $data=$initiated_orders;
            $this->view('managers/completed_orders',$data);
        }
        
        public function Cancelled_orders(){
            if (!isset($_SESSION['login'])) {
                redirect('users/login');
            }
            $this->ManagerModel=$this->model('Manager');
            $cancelled_orders = $this->ManagerModel-> getCancelledOrders();
            $data=$cancelled_orders;
            $this->view('managers/cancelled_orders',$data);
        }

        public function Refunded_orders(){
            if (!isset($_SESSION['login'])) {
                redirect('users/login');
            }
            $this->ManagerModel=$this->model('Manager');
            $refunded_orders = $this->ManagerModel-> getRefundedOrders();
            $data=$refunded_orders;
            $this->view('managers/refunded_orders',$data);
        }

        public function Processing_orders(){
            if (!isset($_SESSION['login'])) {
                redirect('users/login');
            }
            $this->ManagerModel=$this->model('Manager');
            $processing_orders = $this->ManagerModel-> getProcessingOrders();
            $data=$processing_orders;
            $this->view('managers/processing_orders',$data);
        }




        public function refund_order($id){                   //$id is order id 
            if (!isset($_SESSION['login'])) {
                redirect('users/login');
            }
            $this->ManagerModel=$this->model('Manager');

            //payment gateway processing happen
            // $unpaid_to_paid = $this->ManagerModel-> unpaid_to_paid($id);
            
            $data='';
            if($unpaid_to_paid){
                $this->view('managers/cancelled_orders',$data);
            }
            else{
                $this->view('managers/cancelled_orders',$data);
            }
        }



        public function refund($id){
            if (!isset($_SESSION['login'])) {
                redirect('users/login');
            }
            $this->ManagerModel=$this->model('Manager');
            $order = $this->ManagerModel-> getOrderByID($id);
            $customer_name = $this->ManagerModel-> get_customer_name_by_order_id($id);
            $customer_phone = $this->ManagerModel-> get_customer_phone_by_order_id($id);
            
            $data = [
                'order'=>$order,
                'name'=>$customer_name,
                'phone'=>$customer_phone
            ];

            $this->view('managers/refund_order',$data);
        }
        


        public function Pass_order($id){
            if (!isset($_SESSION['login'])) {
                redirect('users/login');
            }
            $this->ManagerModel=$this->model('Manager');
            $delivery_persons = $this->ManagerModel-> getDeliveryPersons();     //fetch delivery person into table
            $delivery_persons_individual_table = $this->ManagerModel-> getDeliveryPersonsFromIndividualTable();

            $data=[
                'delivery_persons'=>$delivery_persons,
                'delivery_persons_individual'=>$delivery_persons_individual_table,
                'order_id'=>$id
                ];

            $pending_to_processing = $this->ManagerModel-> pending_to_processing($id);  //change order status
            
            $this->view('managers/pass_order',$data);
        }

        // public function Pass_order(){       //temporary view for checking css above is the original
        //     $this->ManagerModel=$this->model('Manager');
        //     $data='';
        //     $this->view('managers/pass_order',$data);  
        // }
        
        
        
        
        public function Pass_order_accept($order_id,$deliveryperson_id){
            if (!isset($_SESSION['login'])) {
                redirect('users/login');
            }

            $this->ManagerModel=$this->model('Manager');

            //send the order to delivery person ************************

            // $this->view('managers/processing_orders',$data);

            $available_to_unavailable = $this->ManagerModel-> available_to_unavailable($deliveryperson_id);  //change the availability status of delivery person
            
            $assign_deliveryperson_order = $this->ManagerModel-> assign_deliveryperson_order($deliveryperson_id,$order_id);  //assign a delivery person to order, change the delivery_status to not delivered 

            $processing_orders = $this->ManagerModel-> getProcessingOrders();
            $data=$processing_orders;

            if($available_to_unavailable){
                $this->view('managers/processing_orders',$data);
            }
            else{
                $this->view('managers/pass_order_orders',$data);
            }
        }






        public function order_reject($id){
            if (!isset($_SESSION['login'])) {
                redirect('users/login');
            }

            $this->ManagerModel=$this->model('Manager');
            $initiated_to_cancelled = $this->ManagerModel-> initiated_to_cancelled($id);
            
            $cancelled_orders = $this->ManagerModel-> getCancelledOrders();
            $data=$cancelled_orders;

            if($initiated_to_cancelled){
                $this->view('managers/cancelled_orders',$data);
            }
            else{
                $this->view('managers/initiated_orders',$data);
            }
        }



        public function remind_order($order_id,$deliveryperson_id){
            if (!isset($_SESSION['login'])) {
                redirect('users/login');
            }

            $this->ManagerModel=$this->model('Manager');
            //send_email to delivery person about order is pending

            $email_address=$this->ManagerModel->get_email_by_id($deliveryperson_id);
            $delivery_person_name=$this->ManagerModel->get_deliveryperson_name_by_id($deliveryperson_id);

            $customer_name=$this->ManagerModel->get_customer_name_by_order_id($order_id);
            $delivery_address=$this->ManagerModel->get_delivery_address_by_order_id($order_id);
            
            PHP_mailer_email_reminder($order_id,$email_address,$delivery_person_name,$customer_name,$delivery_address);

            $processing_orders = $this->ManagerModel-> getProcessingOrders();
            $data=$processing_orders;

            // echo "
            //         <script>
            //             alert('Reminder e-mail sent successfully');
            //         </script>
            //     "; 

            echo '<head>
                <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@10.16.6/dist/sweetalert2.min.css">
                </head>';
            echo '<body>
                <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10.16.6/dist/sweetalert2.min.js"></script>
                </body>';

            echo "<script>
                        Swal.fire({
                            title: 'Reminder e-mail sent successfully!',
                            text: 'Delivery reminder e-mail has been sent to $delivery_person_name',
                            timer: 4000,
                            confirmButtonColor: '#3085d6',
                            confirmButtonText: 'OK',
                            backdrop: `
                                rgba(0,0,100,0.1)
                                url('/images/nyan-cat.gif')
                                left top
                                no-repeat
                            `
                        });
                </script>";

            $this->view('managers/processing_orders', $data);       //clear URL after this *************
        }


        
        
        public function Feedback(){
            if (!isset($_SESSION['login'])) {
                redirect('users/login');
            }
            $this->ManagerModel=$this->model('Manager');
            $feedback = $this->ManagerModel-> getFeedback();
            $data=$feedback;

            $this->view('managers/feedback',$data);
        }
        

        //sort feedback
        public function sort_feedback(){
            if (!isset($_SESSION['login'])) {
                redirect('users/login');
            }
            if(isset($_POST["submit"])){
                $str=$_POST["sort"];
                $this->ManagerModel = $this->model('Manager');
                if($str=="date_added") {
                    $feedback = $this->ManagerModel->sort_feedback_model();
                }else{
                    $feedback = $this->ManagerModel-> getFeedback();
                }
                $data =$feedback;
    
                $this->view('managers/feedback', $data);
            }
        }



        


        public function Feedback_details($id){
            if (!isset($_SESSION['login'])) {
                redirect('users/login');
            }
            $this->ManagerModel=$this->model('Manager');
            $feedback = $this->ManagerModel->getFeedbackByID($id);
            $name= $this->ManagerModel-> get_customer_name_from_feedback($id);
            
            $data =[
                'feedback'=>$feedback,
                'name'=>$name
            ];
            $this->view('managers/feedback_details',$data);
        }
    

        public function delete_feedback($id){
            if (!isset($_SESSION['login'])) {
                redirect('users/login');
            }
            $this->ManagerModel=$this->model('Manager');
            $database_query = $this->ManagerModel->deletefeedback($id);

            if($database_query){
                redirect("Managers/Feedback");
            }
            else{
                redirect("Managers/Feedback");
                // die("something went wrong");
            }
        }


        public function feedback_response($customer_id){
            if (!isset($_SESSION['login'])) {
                redirect('users/login');
            }
            $feedback_type = trim(filter_input(INPUT_POST, 'feedback_type', FILTER_SANITIZE_STRING));

            $this->ManagerModel=$this->model('Manager');
            
            $email_address=$this->ManagerModel->get_customer_email_by_id($customer_id);
            $customer_name=$this->ManagerModel->get_customer_name_by_id($customer_id);
            
            PHP_mailer_email_feedback_reponse($email_address,$customer_name,$feedback_type);

            // echo "
            //         <script>
            //             alert('Feedback Response e-mail sent successfully');
            //         </script>
            //     "; 


            echo '<head>
                <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@10.16.6/dist/sweetalert2.min.css">
                </head>';
            echo '<body>
                <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10.16.6/dist/sweetalert2.min.js"></script>
                </body>';

            echo "<script>
                        Swal.fire({
                            title: 'Feedback Response e-mail sent successfully!',
                            text: 'Feedback Response e-mail has been sent to $customer_name',
                            timer: 4000,
                            confirmButtonColor: '#3085d6',
                            confirmButtonText: 'OK',
                            backdrop: `
                                rgba(0,0,100,0.1)
                                url('/images/nyan-cat.gif')
                                left top
                                no-repeat
                            `
                        });
                </script>";


            $feedback = $this->ManagerModel-> getFeedback();
            $data=$feedback;

            $this->view('managers/feedback',$data);
            
        }
        


        public function payhereprocess(){
            if (!isset($_SESSION['login'])) {
                redirect('users/login');
            }
            $this->managerModel=$this->model('Manager');
            $data=''; 
            
            $this->view('managers/payhereprocess',$data);
        }



        public function refund_completed_order($order_id){
            if (!isset($_SESSION['login'])) {
                redirect('users/login');
            }
            $this->managerModel=$this->model('Manager');

            $cancelled_to_refunded = $this->managerModel-> cancelled_to_refunded($order_id);   //after refund change the status  (new status add refund_status in database)

            $refunded_orders = $this->managerModel-> getRefundedOrders();
            $data=$refunded_orders;

            $this->view('managers/refunded_orders',$data);

        }




        public function Report(){
            if (!isset($_SESSION['login'])) {
                redirect('users/login');
            }
            $this->managerModel=$this->model('Manager');

            $sales_array = $this->managerModel->updateSalesReport();                  //calculate the sales_report table according to orders 
            $sales_category_array = $this->managerModel->updateSalesCategory();       //calculate the sales_category table according to orders 
            $sales_location_array = $this->managerModel->updateSalesLocation();       //calculate the sales_location table according to orders 
            
            
            // $sales = $this->managerModel->getSalesReport();                     //get entries of sales_report table
            // $sales_category = $this->managerModel->getSalesCategory();          //get entries of sales_category table 
            // $sales_location = $this->managerModel->getSalesLocation();          //get entries of sales_location

            $data =array(
                'sales'=>$sales_array,
                'sales_category'=>$sales_category_array,
                'sales_location'=>$sales_location_array
            );
            
            $this->view('managers/report',$data);
        }
    

        

/*
        public function low_stock_reminder(){
            // $this->managerModel = $this->model('Manager');
            $count_lowstock = $this->managerModel->get_count_low_stock();
            $emails = $this->managerModel->get_all_storekeeper_emails();
            $ids = $this->managerModel->get_ids_low_stock();
      
            PHP_mailer_zero_medicine($count_lowstock,$emails,$ids);
      
            // $heartmeds = $this->managerModel-> getHeartMeds();
            // $data =$heartmeds;
            // $this->view('storeKeepers/view_medicine_heart', $data);
          }
      
      
      
          public function expired_medicine_reminder(){
            // $this->managerModel = $this->model('Manager');
            $count_expired = $this->managerModel->get_count_expired();
            $emails = $this->managerModel->get_all_storekeeper_emails();
            $ids = $this->managerModel->get_ids_expired();
      
      
            PHP_mailer_expired_medicine($count_expired,$emails,$ids);
      
            // $heartmeds = $this->managerModel-> getHeartMeds();
            // $data =$heartmeds;
            // $this->view('storeKeepers/view_medicine_heart', $data);
          }
*/



          //account page
          public function account()
          {
            if (!isset($_SESSION['login'])) {
                redirect('users/login');
            }
              $this->ManagerModel = $this->model('Manager');
              $email = $_SESSION['email'];
              $userdetails = $this->ManagerModel->getuserdetails($email);
              $data =$userdetails;
              // print_r($data);die();
              $this->view('managers/account', $data);
          }

          public function change_pw()
          {
            if (!isset($_SESSION['login'])) {
                redirect('users/login');
            }
              $this->ManagerModel = $this->model('Manager');
              $data ="";
              $this->view('managers/change_pw', $data);
          }
  
          public function update_pw()
          {
            if (!isset($_SESSION['login'])) {
                redirect('users/login');
            }
              $this->ManagerModel = $this->model('Manager');
              $data ="";
              //print_r($_POST);die();
              $cur_pw = $_POST['cur_pw']; 
              $res = $this->ManagerModel->getuserdetails($_SESSION['email']);
              if (password_verify($cur_pw,$res[0]->password)) {
                  if ($_POST['new_pw'] == $_POST['con_pw'] ) {
                      $hashed = password_hash($_POST['new_pw'], PASSWORD_DEFAULT);
                      $res = $this->ManagerModel->updatePassword($_SESSION['email'],$hashed);
                      if ($res) {
                          header('Location: ./account');
                      }
                  }
                  else {
                      $_SESSION['error2'] = "Passwords Not Match";
                      $this->view('managers/change_pw', $data);
                      exit();
                  }
              }
              else {
                  $_SESSION['error1'] = "Incorrect Password";
                  $this->view('managers/change_pw', $data);
                  exit();
              }
              // print_r($res[0]->password);die();
              // $data ="";
              // $this->view('managers/change_pw', $data);
          }


        



          public function updateImg()
          {
            if (!isset($_SESSION['login'])) {
                redirect('users/login');
            }
                    // print_r($_FILES);die();
                    $this->ManagerModel = $this->model('Manager');
                    $data ='';
        
                    $target_dir = "C:/xampp/htdocs/careU_project/public/img/user-pics/";
                    $filename = basename($_FILES["fileToUpload"]["name"]);
                    $target_file = $target_dir . $filename;
                    
                    $uploadOk = 1;
                    $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
            
                    
                    // Check if image file is a actual image or fake image
                    if (isset($_POST["submit"])) {
                        $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
                        if ($check !== false) {
                            echo "File is an image - " . $check["mime"] . ".";
                            $uploadOk = 1;
                        } else {
                            echo "File is not an image.";
                            $uploadOk = 0;
                        }
                    }
            
                    // Check if file already exists
                    if (file_exists($target_file)) {
                        echo "Sorry, file already exists.";
                        $uploadOk = 0;
                    }
            
                    // Check file size
                    if ($_FILES["fileToUpload"]["size"] > 500000) {
                        echo "Sorry, your file is too large.";
                        $uploadOk = 0;
                    }
            
                    // Allow certain file formats
                    if (
                        $imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif"
                    ) {
                        echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
                        $uploadOk = 0;
                    }
            
                    // Check if $uploadOk is set to 0 by an error
                    if ($uploadOk == 0) {
                        echo "Sorry, your file was not uploaded.";
                        // if everything is ok, try to upload file
                    } else {
                        if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
                            echo "The file " . htmlspecialchars(basename($_FILES["fileToUpload"]["name"])) . " has been uploaded.";
                        } else {
                            echo "Sorry, there was an error uploading your file.";
                        }
                    }
            
                    $result = $this->ManagerModel->updateProfilePic($filename,$_SESSION['email']);
                    if ($result) {
                        $_SESSION['profile'] = $filename;
                        redirect('Managers/account');
                    }          
          }
         
          
        // public function createUserSession($user){
        //     $_SESSION['user_id']=$user->ID;
        //     $_SESSION['user_email']=$user->email;
        //     $_SESSION['user_name']=$user->first_name;
        //     $_SESSION['login'] =1;

        //     // redirect('pages/dashboard');                //it will redirect to index method in pages controller

        //     die('login successful');
        // }

        // public function logout(){
        //     unset($_SESSION['user_id']);
        //     unset($_SESSION['user_email']);
        //     unset($_SESSION['user_name']);
        //     session_destroy();
        //     redirect('users/login');
        // }
        
    }

