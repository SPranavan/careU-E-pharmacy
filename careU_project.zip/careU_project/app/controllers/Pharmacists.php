<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

//Load Composer's autoloader
require '../app/vendor/autoload.php';

    /*
        *TASKS:
            ~ Login & Reg
    */ 

    class pharmacists extends Controller{

        //Create varibale to connect to DB
        private $PharmacistModel;

        //Assigned 'Pharmacist' model file
        public function __construct()
        {
            $this->PharmacistModel = $this->model('Pharmacist');
        }

        public function index()
        {
            // print_r($_SESSION['email']);die();
            if (!isset($_SESSION['login'])) {
                redirect('/users/login');
            }
            $this->PharmacistModel = $this->model('Pharmacist');
            $count_heart = $this->PharmacistModel->getCount_Heart();
            $count_diabetes=$this->PharmacistModel->getCount_diabetes();
            $count_infection=$this->PharmacistModel->getCount_infection();
            $count_gastro=$this->PharmacistModel->getCount_gastro();
            $count_muscle=$this->PharmacistModel->getCount_muscle();
            $count_customer=$this->PharmacistModel->getCount_customer();
            $email = $_SESSION['email'];
            $pharmacist_id = $this ->PharmacistModel->get_pharmacistID($email);
            $_SESSION['pharmacist_id'] = $pharmacist_id[0]->user_ID;

            $completed_ord_days = $this->PharmacistModel->getDailyCompletedorders($_SESSION['pharmacist_id']);
            $completed_pres_days = $this->PharmacistModel->getDailyCompletedprescription($_SESSION['pharmacist_id']);
            // print_r($completed_ord_days);die();
            $cur_date = date('y-m-d');
            $count_expired=$this->PharmacistModel->getexpiredate($cur_date);
            $view_expired=$this->PharmacistModel->view_expiredate($cur_date);

            $data =array($count_heart,$count_diabetes,$count_infection,$count_gastro,$count_muscle,$count_customer,$count_expired,$view_expired,$completed_ord_days,$completed_pres_days);
            // print_r($data);die();
            $this->view('pharmacist/dashboard', $data);
        }
         public function home_page(){
            $this->PharmacistModel = $this->model('Pharmacist');
            $data = '';
            $this->view('pharmacist/home_page',$data);
         }

        public function accepted_orders()
        {
            if (!isset($_SESSION['login'])) {
                redirect('/users/login');
            }
            $this->PharmacistModel = $this->model('Pharmacist');
            $accepted_ord = $this-> PharmacistModel->accepted_order();
            $data =$accepted_ord;
            $this->view('pharmacist/accepted_orders', $data);
        }

        public function accepted_prescription()
        {
            if (!isset($_SESSION['login'])) {
                redirect('/users/login');
            }
            $this->PharmacistModel = $this->model('Pharmacist');
            $accepted_pres = $this->PharmacistModel->accepted_prescription();
            $data =$accepted_pres;
            $this->view('pharmacist/accepted_prescription', $data);
        }

        // public function available_prescription()
        // {
        //     $this->PharmacistModel = $this->model('Pharmacist');
        //     $data ="";
        //     $this->view('pharmacist/available_prescription', $data);
        // }

        

        public function completed_orders()
        {
            if (!isset($_SESSION['login'])) {
                redirect('/users/login');
            }
            $this->PharmacistModel = $this->model('Pharmacist');
            $completed_ord = $this->PharmacistModel->completed_orders();
            $data =$completed_ord;
            $this->view('pharmacist/completed_orders', $data);
        }
        // public function dashboard()
        // {
        //     $this->PharmacistModel = $this->model('Pharmacist');
        //     $data ="";
        //     $this->view('pharmacist/dashboard', $data);
        // }

        public function completed_prescription()
        {
            if (!isset($_SESSION['login'])) {
                redirect('/users/login');
            }
            $this->PharmacistModel = $this->model('Pharmacist');
            $completed_pres = $this->PharmacistModel->completed_prescription();
            $data =$completed_pres;
            $this->view('pharmacist/completed_prescription', $data);
        }

        // public function create_new_prescription()
        // {
        //     $this->PharmacistModel = $this->model('Pharmacist');
        //     $data ="";
        //     $this->view('pharmacist/create_new_prescription', $data);
        // }

        // public function created_prescription()
        // {
        //     $this->PharmacistModel = $this->model('Pharmacist');
        //     $data ="";
        //     $this->view('pharmacist/created_prescription', $data);
        // }

        public function new_order()
        {
            if (!isset($_SESSION['login'])) {
                redirect('/users/login');
            }
            
            $this->PharmacistModel = $this->model('Pharmacist');
            $n_order = $this->PharmacistModel->new_order();
            $data =$n_order;
            $this->view('pharmacist/new_order', $data);
        }

        public function accept_order($id) {

            // print_r($_SESSION['pharmacist_id']);die();
            $this->PharmacistModel = $this->model('Pharmacist');
            $res = $this->PharmacistModel->accept_order($id,$_SESSION['pharmacist_id']);
            $customer = $this->PharmacistModel->getCustomername($id);

            $mail = new PHPMailer(true);

            try {
                //Server settings
                $mail->isSMTP();                                            
                $mail->Host       = 'smtp.gmail.com';                       
                $mail->SMTPAuth   = true;                                   
                $mail->Username   = 'careU.meds@gmail.com';                     
                $mail->Password   = 'rqoisanoxkfcgbjz';                           
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;            
                $mail->Port       = 465;                                    
        
                //Recipients
                $mail->setFrom('careU.meds@gmail.com');
                $mail->addAddress($customer[0]->email);     //Add a recipient
                
                // Set the email message
                $mail->isHTML(true);
                $mail->Subject = "Order Details - Order #".$customer[0]->orderID;
        
                $mail->Body = "<h2>Order Details - Order #".$customer[0]->orderID."</h2><br><br>"
                            ."<p>Dear ".$customer[0]->fName.",</p><br>"
                            ."<p>We are pleased to inform you that your order has been accepted and is now being processed by our pharmacy team. We appreciate your trust in our services and are committed to providing you with the best possible care.</p>"
                            
                            ."<p>Thank you for choosing our pharmacy for your healthcare needs. We look forward to serving you and helping you to maintain optimal health.</p><br>"
                           
                            ."<p>Best regards,<br>"
                            ."<p>careU E-Pharmacy</p>"
                            ."<p>care.meds@gmail.com</p>";
        
        
                // Send the email
                $mail->send();
                header('Location: /careU_project/pharmacists/accepted_prescription');
        
            } catch (Exception $e) {
                echo "Email could not be sent. Mailer Error: {$mail->ErrorInfo}";
            }

            if ($res) {
                header('Location: /careU_project/pharmacists/accepted_orders');
            }


        }

        public function reject_order($id) {
            $this->PharmacistModel = $this->model('Pharmacist');
            $res = $this->PharmacistModel->reject_order($id);
            $customer = $this->PharmacistModel->getCustomername($id);

            $mail = new PHPMailer(true);

            try {
                //Server settings
                $mail->isSMTP();                                            
                $mail->Host       = 'smtp.gmail.com';                       
                $mail->SMTPAuth   = true;                                   
                $mail->Username   = 'careU.meds@gmail.com';                     
                $mail->Password   = 'rqoisanoxkfcgbjz';                           
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;            
                $mail->Port       = 465;                                    
        
                //Recipients
                $mail->setFrom('careU.meds@gmail.com');
                $mail->addAddress($customer[0]->email);     //Add a recipient   
                
                // Set the email message
                $mail->isHTML(true);
                $mail->Subject = "Order Details - Order #".$customer[0]->orderID;
        
                $mail->Body = "<h2>Invoice Details - Order #".$customer[0]->orderID."</h2><br><br>"
                ."<p>Dear ".$customer[0]->fName." ,</p><br>"
                ."<p>We regret to inform you that due to an unavoidable circumstance, we are unable to provide you with the medicine that you have requested. As pharmacists, it is our responsibility to ensure that all medications are dispensed safely and in accordance with legal and ethical guidelines.</p>"
                ."<p>Unfortunately, in this situation, there is an issue that is preventing us from being able to provide you with the medication you need. This may be due to a variety of reasons, such as an unexpected shortage of the medication, an error in the prescription, or concerns about potential interactions with other medications you are taking.</p><br>"
                ."<p>Thank you for your understanding and patience in this matter.</p><br>"
                ."<p>Sincerely,<br>"
                ."<p>careU E-Pharmacy</p>"
                ."<p>care.meds@gmail.com</p>";
        
        
                // Send the email
                $mail->send();
                header('Location: /careU_project/pharmacists/accepted_prescription');
        
            } catch (Exception $e) {
                echo "Email could not be sent. Mailer Error: {$mail->ErrorInfo}";
            }


            if ($res) {
                header('Location: /careU_project/pharmacists/new_order');
            }
        }

        public function packed_ord($id) {
            $this->PharmacistModel = $this->model('Pharmacist');
            $res = $this->PharmacistModel->packed_ord($id);

            if ($res) {
                header('Location: /careU_project/pharmacists/accepted_orders');
            }
        }

        public function unpacked_ord($id) {
            $this->PharmacistModel = $this->model('Pharmacist');
            $res = $this->PharmacistModel->unpacked_ord($id);

            if ($res) {
                header('Location: /careU_project/pharmacists/accepted_orders');
            }
        }

        public function packed_done_ord($id) {
            $this->PharmacistModel = $this->model('Pharmacist');
            $res = $this->PharmacistModel->completed_ord($id);

            if ($res) {
                header('Location: /careU_project/pharmacists/completed_orders');
            }
        }

        public function available_prescription()
        {
            if (!isset($_SESSION['login'])) {
                redirect('/users/login');
            }
            $this->PharmacistModel = $this->model('Pharmacist');
            $avail_pres = $this->PharmacistModel->available_prescription();
            $med_types = $this->PharmacistModel->getMedicineType();
            $invid = 11;
            $test = "medicine";
            // $res = $this->PharmacistModel->getMedicineType2($test);
            // print_r($res[0]->medicine_type2);die();

            $data =array($avail_pres,$med_types);
            $this->view('pharmacist/available_prescription', $data);
        }

        public function dropdown_search(){
            $this->PharmacistModel = $this->model('Pharmacist');
            $res = $this->PharmacistModel->getMedicineType2($_POST['dd1']);
            $countdata = count($res);
            echo '<option value="NULL" selected hidden disabled>Select an option</option>';
            for ($i=0; $i < $countdata; $i++) { 
                echo '<option value="'.$res[$i]->medicine_type2 .'">'.$res[$i]->medicine_type2 .'</option>';
            }
            
        }

        public function dropdown_search2(){
            $this->PharmacistModel = $this->model('Pharmacist');
            $res = $this->PharmacistModel->getMedicineName($_POST['dd2']);

            $countdata = count($res);
            echo '<option value="NULL" selected hidden disabled>Select an option</option>';
            for ($i=0; $i < $countdata; $i++) { 
                echo '<option value="'.$res[$i]->name .'">'.$res[$i]->name .'</option>';
            }
            
        }

        public function dropdown_search3(){
            $this->PharmacistModel = $this->model('Pharmacist');
            $res = $this->PharmacistModel->getQuantity($_POST['dd3']);
            
            echo $res[0]->quantity;
            
        }

        public function add_medicine_invoice()
        {
            $this->PharmacistModel = $this->model('Pharmacist');
            if (isset($_POST['drop1']) && isset($_POST['drop2']) && isset($_POST['drop3']) && isset($_POST['quan'])){
                $medobj = $this->PharmacistModel->getMedId($_POST['drop3']);
                $medid = $medobj[0]->medicineID;
                $res = $this->PharmacistModel->checkInvoiceNull($_POST['pid']);
                if ($res[0]->invoiceID == NULL) {
                    $cur_date = date('y-m-d');
                    $res1 = $this->PharmacistModel->addInvoice($cur_date);
                    if ($res1) {
                        $invoiceID = $this->PharmacistModel->getInvoiceNo($cur_date);
                        $invid= $invoiceID[0]->invoiceID;
                        $res3 = $this->PharmacistModel->updateInvid($invid,$_POST['pid']);
                        $res2 = $this->PharmacistModel->addmed($invid,$medid,$_POST['quan']);
                        if ($res2) {
                            $output = $this->PharmacistModel->getAllmed($invid);
                            echo '
                            <tr>
                                <th>Medicine</th>
                                <th>Quantity</th>
                            </tr> ';
                                
                            foreach ($output as $row) {
                                echo '
                                <tr>
                                <td>'.$row->name.'</td>
                                <td>'.$row->quantity.'</td>
                                </tr> ';
                            }
                        }
                    }
                }
                else {
                    $res = $this->PharmacistModel->checkInvoiceNull($_POST['pid']);
                    $invid = $res[0]->invoiceID;
                    $checkmed = $this->PharmacistModel->checkMed($invid,$medid);
                    if (empty($checkmed)) {
                        $res2 = $this->PharmacistModel->addmed($invid,$medid,$_POST['quan']);
                        if ($res2) {
                            $output = $this->PharmacistModel->getAllmed($invid);
                            echo '
                            <tr>
                                <th>Medicine</th>
                                <th>Quantity</th>
                            </tr> ';
                                
                            foreach ($output as $row) {
                                echo '
                                <tr>
                                <td>'.$row->name.'</td>
                                <td>'.$row->quantity.'</td>
                                </tr> ';
                            }
                        }
                    } else {
                        $newquan = $_POST['quan'] + $checkmed[0]->quantity;
                        $res2 = $this->PharmacistModel->updatemed($invid,$medid,$newquan);
                        if ($res2) {
                            $output = $this->PharmacistModel->getAllmed($invid);
                            echo '
                            <tr>
                                <th>Medicine</th>
                                <th>Quantity</th>
                            </tr> ';
                                
                            foreach ($output as $row) {
                                echo '
                                <tr>
                                <td>'.$row->name.'</td>
                                <td>'.$row->quantity.'</td>
                                </tr> ';
                            }
                        }
                    }
                    
                    

                }
            
                
            

            }
        }

        public function accept_prescription($id) {

            // $filepath = 'C:\xampp\htdocs\careU_project\/public/img/prescription/'.$_GET['img'];

            
       
            // Process download
            // if (file_exists($filepath)) {
            // header('Content-Description: File Transfer');
            // header('Content-Type: application/octet-stream');
            // header('Content-Disposition: attachment; filename="' . basename($filepath) . '"');
            // header('Expires: 0');
            // header('Cache-Control: must-revalidate');
            // header('Pragma: public');
            // header('Content-Length: ' . filesize($filepath));
            // flush(); // Flush system output buffer
            // readfile($filepath);
            
            
            $this->PharmacistModel = $this->model('Pharmacist');
            $res = $this->PharmacistModel->accept_presc($id,$_SESSION['pharmacist_id']);
            $customer = $this->PharmacistModel->getCustomerDetails($id);
            $amount = $this->PharmacistModel->get_amount($id);
            // print_r($amount);die();
            


            $mail = new PHPMailer(true);

            try {
                //Server settings
                $mail->isSMTP();                                            
                $mail->Host       = 'smtp.gmail.com';                       
                $mail->SMTPAuth   = true;                                   
                $mail->Username   = 'careU.meds@gmail.com';                     
                $mail->Password   = 'rqoisanoxkfcgbjz';                           
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;            
                $mail->Port       = 465;                                    
        
                //Recipients
                $mail->setFrom('careU.meds@gmail.com');
                $mail->addAddress($customer[0]->email);     //Add a recipient
                
                // Set the email message
                $mail->isHTML(true);
                $mail->Subject = "Invoice Details - Order #".$customer[0]->orderID;
        
                $mail->Body = "<h2>Invoice Details - Order #".$customer[0]->orderID."</h2><br><br>"
                            ."<p>Dear Customer,</p><br>"
                            ."<p>Thank you for your recent order with careU E-Pharmacy. Please find your invoice details below:</p>"
                            ."<ul>"
                            ."<li>Order ID: ".$customer[0]->orderID."</li>"
                            ."<li>Order Date: ".$customer[0]->date."</li>"
                            ."<li>Total Amount:".$amount[0]->sub_total.
                             "LKR</li>"
                            ."</ul>"
                            ."<p>Please make sure to review the invoice and contact us if you have any questions or concerns.</p><br>"
                            ."<p>Thank you for your business and we look forward to serving you again soon.</p><br>"
                            ."<p>Best regards,<br>"
                            ."<p>careU E-Pharmacy</p>"
                            ."<p>care.meds@gmail.com</p>";
        
        
                // Send the email
                $mail->send();
                header('Location: /careU_project/pharmacists/accepted_prescription');
        
            } catch (Exception $e) {
                echo "Email could not be sent. Mailer Error: {$mail->ErrorInfo}";
            }

        
            
            
           
            
            
            
        }

        public function reject_prescription($id) {
            $this->PharmacistModel = $this->model('Pharmacist');
            // $res = $this->PharmacistModel->reject_presc($id);

            $res = $this->PharmacistModel->reject_presc($id,$_SESSION['pharmacist_id']);
            $customer = $this->PharmacistModel->getCustomerDetails($id);
            $amount = $this->PharmacistModel->get_amount($id);
            //  print_r($customer);die();
            


            $mail = new PHPMailer(true);

            try {
                //Server settings
                $mail->isSMTP();                                            
                $mail->Host       = 'smtp.gmail.com';                       
                $mail->SMTPAuth   = true;                                   
                $mail->Username   = 'careU.meds@gmail.com';                     
                $mail->Password   = 'rqoisanoxkfcgbjz';                           
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;            
                $mail->Port       = 465;                                    
        
                //Recipients
                $mail->setFrom('careU.meds@gmail.com');
                $mail->addAddress($customer[0]->email);     //Add a recipient
                
                // Set the email message
                $mail->isHTML(true);
                $mail->Subject = "Invoice Details - Order #".$customer[0]->orderID;
        
                $mail->Body = "<h2>Invoice Details - Order #".$customer[0]->orderID."</h2><br><br>"
                            ."<p>Dear ".$customer[0]->fName." ,</p><br>"
                            ."<p>We regret to inform you that due to an unavoidable circumstance, we are unable to provide you with the medicine that you have requested. As pharmacists, it is our responsibility to ensure that all medications are dispensed safely and in accordance with legal and ethical guidelines.</p>"
                            ."<p>Unfortunately, in this situation, there is an issue that is preventing us from being able to provide you with the medication you need. This may be due to a variety of reasons, such as an unexpected shortage of the medication, an error in the prescription, or concerns about potential interactions with other medications you are taking.</p><br>"
                            ."<p>Thank you for your understanding and patience in this matter.</p><br>"
                            ."<p>Sincerely,<br>"
                            ."<p>careU E-Pharmacy</p>"
                            ."<p>care.meds@gmail.com</p>";
        
        
                // Send the email
                $mail->send();
                header('Location: /careU_project/pharmacists/accepted_prescription');
        
            } catch (Exception $e) {
                echo "Email could not be sent. Mailer Error: {$mail->ErrorInfo}";
            }

            if ($res) {
                header('Location: /careU_project/pharmacists/available_prescription');
            }
        }

        public function packed_presc($id) {
            $this->PharmacistModel = $this->model('Pharmacist');
            $res = $this->PharmacistModel->packed($id);

            if ($res) {
                header('Location: /careU_project/pharmacists/accepted_prescription');
            }
        }

        public function un_packed_presc($id) {
            $this->PharmacistModel = $this->model('Pharmacist');
            $res = $this->PharmacistModel->unpacked($id);

            if ($res) {
                header('Location: /careU_project/pharmacists/accepted_prescription');
            }
        }

        public function packed_done($id) {
            $this->PharmacistModel = $this->model('Pharmacist');
            $res = $this->PharmacistModel->completed($id);

            if ($res) {
                header('Location: /careU_project/pharmacists/completed_prescription');
            }
        }

        public function product_medicine_heart()
        {
            if (!isset($_SESSION['login'])) {
                redirect('/users/login');
            }
            $this->PharmacistModel = $this->model('Pharmacist');
            $heartmeds = $this->PharmacistModel-> getHeartMeds();
            $data =$heartmeds;
            $this->view('pharmacist/product_medicine_heart', $data);
        }

        public function product_medicine_diabetes()
        {
            if (!isset($_SESSION['login'])) {
                redirect('/users/login');
            }
            $this->PharmacistModel = $this->model('Pharmacist');
            $diabetesmeds = $this -> PharmacistModel ->getdiabetesMeds();
            $data =$diabetesmeds;
            $this->view('pharmacist/product_medicine_diabetes', $data);
        }

        public function product_medicine_gastro()
        {
            if (!isset($_SESSION['login'])) {
                redirect('/users/login');
            }
            $this->PharmacistModel = $this->model('Pharmacist');
            $gastromeds = $this->PharmacistModel->getgastroMeds();
            $data =$gastromeds;
            $this->view('pharmacist/product_medicine_gastro', $data);
        }

        public function product_medicine_infection()
        {
            if (!isset($_SESSION['login'])) {
                redirect('/users/login');
            }
            $this->PharmacistModel = $this->model('Pharmacist');
            $infectionmeds = $this->PharmacistModel ->getinfectionMeds();
            $data =$infectionmeds;
            $this->view('pharmacist/product_medicine_infection', $data);
        }

        public function product_medicine_muscle()
        {
            if (!isset($_SESSION['login'])) {
                redirect('/users/login');
            }
            $this->PharmacistModel = $this->model('Pharmacist');
            $musclemeds=$this->PharmacistModel->getmuscleMeds();
            $data =$musclemeds;
            $this->view('pharmacist/product_medicine_muscle', $data);
        }

        // public function view_a_prescription()
        // {
        //     $this->PharmacistModel = $this->model('Pharmacist');
        //     $data ="";
        //     $this->view('pharmacist/view_a_prescription', $data);
        // }

        public function delete($id){
            $result = $this->PharmacistModel->deletePost($id);
            if($result){
                $this->view('pharmacist/completed_orders');
            }
            else{
                echo "Error deleting post";
            }

        }

        public function product_pc_nourishment()
        {
            if (!isset($_SESSION['login'])) {
                redirect('/users/login');
            }
            $this->PharmacistModel = $this->model('Pharmacist');
            $noruish_pc = $this->PharmacistModel->getnourishments();
            $data =$noruish_pc;
            $this->view('pharmacist/product_pc_nourishments', $data);
        }

        public function product_pc_accessories()
        {
            if (!isset($_SESSION['login'])) {
                redirect('/users/login');
            }
            $this->PharmacistModel = $this->model('Pharmacist');
            $accessories_pc = $this->PharmacistModel->getaccessories();
            $data = $accessories_pc;
            $this->view('pharmacist/product_pc_accessories', $data);
        }

        public function product_pc_skincare()
        {
            if (!isset($_SESSION['login'])) {
                redirect('/users/login');
            }
            $this->PharmacistModel = $this->model('Pharmacist');
            $skincare_pc = $this->PharmacistModel->getskincare();
            $data =$skincare_pc;
            $this->view('pharmacist/product_pc_skincare', $data);
        }

        public function product_pc_womenpc()
        {
            if (!isset($_SESSION['login'])) {
                redirect('/users/login');
            }
            $this->PharmacistModel = $this->model('Pharmacist');
            $womencare_pc = $this->PharmacistModel->women_personalcare();
            $data =$womencare_pc;
            $this->view('pharmacist/product_pc_womenpc', $data);
        }

        public function product_pc_oralcare()
        {
            if (!isset($_SESSION['login'])) {
                redirect('/users/login');
            }
            $this->PharmacistModel = $this->model('Pharmacist');
            $oralcare = $this->PharmacistModel->oralcare();
            $data =$oralcare;
            $this->view('pharmacist/product_pc_oralcare', $data);
        }

        public function product_md_firstaid()
        {
            if (!isset($_SESSION['login'])) {
                redirect('/users/login');
            }
            $this->PharmacistModel = $this->model('Pharmacist');
            $firstaid = $this->PharmacistModel->firstaid();
            $data =$firstaid;
            $this->view('pharmacist/product_md_firstaid', $data);
        }

        public function product_md_healthdevice()
        {
            if (!isset($_SESSION['login'])) {
                redirect('/users/login');
            }
            $this->PharmacistModel = $this->model('Pharmacist');
            $health_device = $this->PharmacistModel->health_device();
            $data =$health_device;
            $this->view('pharmacist/product_md_healthdevice', $data);
        }

        public function product_md_support()
        {
            if (!isset($_SESSION['login'])) {
                redirect('/users/login');
            }
            $this->PharmacistModel = $this->model('Pharmacist');
            $support = $this->PharmacistModel->support();
            $data =$support;
            $this->view('pharmacist/product_md_support', $data);
        }

        public function account()
        {
            if (!isset($_SESSION['login'])) {
                redirect('/users/login');
            }
            $this->PharmacistModel = $this->model('Pharmacist');
            $email = $_SESSION['email'];
            $userdetails = $this->PharmacistModel->getuserdetails($email);
            $data =$userdetails;
            // print_r($data);die();
            $this->view('pharmacist/account', $data);
        }

        public function change_pw()
        {
            if (!isset($_SESSION['login'])) {
                redirect('/users/login');
            }
            $this->PharmacistModel = $this->model('Pharmacist');
            $data ="";
            $this->view('pharmacist/change_pw', $data);
        }

        public function update_pw()
        {
            if (!isset($_SESSION['login'])) {
                redirect('/users/login');
            }
            $this->PharmacistModel = $this->model('Pharmacist');
            $data ="";
            //print_r($_POST);die();
            $cur_pw = $_POST['cur_pw']; 
            $res = $this->PharmacistModel->getuserdetails($_SESSION['email']);
            // print_r($res[0]->password);die();
            if (password_verify($cur_pw,$res[0]->password)) {
                
                if ($_POST['new_pw'] == $_POST['con_pw'] ) {
                    $hashed = password_hash($_POST['new_pw'], PASSWORD_DEFAULT);
                    $res = $this->PharmacistModel->updatePassword($_SESSION['email'],$hashed);
                    if ($res) {
                        header('Location: ./account');
                    }
                }
                else {
                    $_SESSION['error2'] = "Passwords Not Match";
                    $this->view('pharmacist/change_pw', $data);
                    exit();
                }
            }
            else {
                $_SESSION['error1'] = "Incorrect Password";
                $this->view('pharmacist/change_pw', $data);
                exit();
            }
            // print_r($res[0]->password);die();
            // $data ="";
            // $this->view('pharmacist/change_pw', $data);
        }

        public function heart_search(){
            $this->PharmacistModel = $this->model('Pharmacist');
            $res = $this->PharmacistModel->search_heart($_POST['search']);
            $countdata = count($res);

            for ($i = 0; $i < $countdata; $i++) {
                echo '
                    <div class="box1">
                    <img src="' . URLROOT . '/public/img/pharmacist/panadol.jpg" alt="call">
                    <p>Item name :<span class="data"> ' . $res[$i]->name . ' </span> </p>
                        <p>Price :<span class="data"> ' . $res[$i]->price . '</span> </p>
                        <p>Stock :<span class="data"> ' . $res[$i]->quantity . '</span> </p>
                        <p>Quantity :<span class="data"> ' . $res[$i]->quantity_measurement . '</span> </p>
                    </div> ';
            };        
        }

        public function diabetes_search(){
            $this->PharmacistModel = $this->model('Pharmacist');
            $res = $this->PharmacistModel->search_diabetes($_POST['search']);
            $countdata = count($res);
            

            for ($i = 0; $i < $countdata; $i++) {
                echo '
                    <div class="box1">
                    <img src="' . URLROOT . '/public/img/pharmacist/panadol.jpg" alt="call">
                    <p>Item name :<span class="data"> ' . $res[$i]->name . ' </span> </p>
                        <p>Price :<span class="data"> ' . $res[$i]->price . '</span> </p>
                        <p>Stock :<span class="data"> ' . $res[$i]->quantity . '</span> </p>
                        <p>Quantity :<span class="data"> ' . $res[$i]->quantity_measurement . '</span> </p>
                    </div> ';
            };        
        }

        public function infection_search(){
            $this->PharmacistModel = $this->model('Pharmacist');
            $res = $this->PharmacistModel->search_infection($_POST['search']);
            $countdata = count($res);
            

            for ($i = 0; $i < $countdata; $i++) {
                echo '
                    <div class="box1">
                    <img src="' . URLROOT . '/public/img/pharmacist/panadol.jpg" alt="call">
                    <p>Item name :<span class="data"> ' . $res[$i]->name . ' </span> </p>
                        <p>Price :<span class="data"> ' . $res[$i]->price . '</span> </p>
                        <p>Stock :<span class="data"> ' . $res[$i]->quantity . '</span> </p>
                        <p>Quantity :<span class="data"> ' . $res[$i]->quantity_measurement . '</span> </p>
                    </div> ';
            };        
        }

        public function gastro_search(){
            $this->PharmacistModel = $this->model('Pharmacist');
            $res = $this->PharmacistModel->search_gastro($_POST['search']);
            $countdata = count($res);
            

            for ($i = 0; $i < $countdata; $i++) {
                echo '
                    <div class="box1">
                    <img src="' . URLROOT . '/public/img/pharmacist/panadol.jpg" alt="call">
                    <p>Item name :<span class="data"> ' . $res[$i]->name . ' </span> </p>
                        <p>Price :<span class="data"> ' . $res[$i]->price . '</span> </p>
                        <p>Stock :<span class="data"> ' . $res[$i]->quantity . '</span> </p>
                        <p>Quantity :<span class="data"> ' . $res[$i]->quantity_measurement . '</span> </p>
                    </div> ';
            };        
        }

        public function muscle_search(){
            $this->PharmacistModel = $this->model('Pharmacist');
            $res = $this->PharmacistModel->search_muscle($_POST['search']);
            $countdata = count($res);
            

            for ($i = 0; $i < $countdata; $i++) {
                echo '
                    <div class="box1">
                    <img src="' . URLROOT . '/public/img/pharmacist/panadol.jpg" alt="call">
                    <p>Item name :<span class="data"> ' . $res[$i]->name . ' </span> </p>
                        <p>Price :<span class="data"> ' . $res[$i]->price . '</span> </p>
                        <p>Stock :<span class="data"> ' . $res[$i]->quantity . '</span> </p>
                        <p>Quantity :<span class="data"> ' . $res[$i]->quantity_measurement . '</span> </p>
                    </div> ';
            };        
        }

        public function nourishment_search(){
            $this->PharmacistModel = $this->model('Pharmacist');
            $res = $this->PharmacistModel->search_nourishment($_POST['search']);
            $countdata = count($res);
            

            for ($i = 0; $i < $countdata; $i++) {
                echo '
                    <div class="box1">
                    <img src="' . URLROOT . '/public/img/pharmacist/panadol.jpg" alt="call">
                    <p>Item name :<span class="data"> ' . $res[$i]->name . ' </span> </p>
                        <p>Price :<span class="data"> ' . $res[$i]->price . '</span> </p>
                        <p>Stock :<span class="data"> ' . $res[$i]->quantity . '</span> </p>
                        <p>Quantity :<span class="data"> ' . $res[$i]->quantity_measurement . '</span> </p>
                    </div> ';
            };        
        }

        public function accessories_search(){
            $this->PharmacistModel = $this->model('Pharmacist');
            $res = $this->PharmacistModel->search_accessories($_POST['search']);
            $countdata = count($res);
            

            for ($i = 0; $i < $countdata; $i++) {
                echo '
                    <div class="box1">
                    <img src="' . URLROOT . '/public/img/pharmacist/panadol.jpg" alt="call">
                    <p>Item name :<span class="data"> ' . $res[$i]->name . ' </span> </p>
                        <p>Price :<span class="data"> ' . $res[$i]->price . '</span> </p>
                        <p>Stock :<span class="data"> ' . $res[$i]->quantity . '</span> </p>
                        <p>Quantity :<span class="data"> ' . $res[$i]->quantity_measurement . '</span> </p>
                    </div> ';
            };        
        }

        public function skincare_search(){
            $this->PharmacistModel = $this->model('Pharmacist');
            $res = $this->PharmacistModel->search_skincare($_POST['search']);
            $countdata = count($res);
            

            for ($i = 0; $i < $countdata; $i++) {
                echo '
                    <div class="box1">
                    <img src="' . URLROOT . '/public/img/pharmacist/panadol.jpg" alt="call">
                    <p>Item name :<span class="data"> ' . $res[$i]->name . ' </span> </p>
                        <p>Price :<span class="data"> ' . $res[$i]->price . '</span> </p>
                        <p>Stock :<span class="data"> ' . $res[$i]->quantity . '</span> </p>
                        <p>Quantity :<span class="data"> ' . $res[$i]->quantity_measurement . '</span> </p>
                    </div> ';
            };        
        }

        public function womenpc_search(){
            $this->PharmacistModel = $this->model('Pharmacist');
            $res = $this->PharmacistModel->search_womenpc($_POST['search']);
            $countdata = count($res);
            

            for ($i = 0; $i < $countdata; $i++) {
                echo '
                    <div class="box1">
                    <img src="' . URLROOT . '/public/img/pharmacist/panadol.jpg" alt="call">
                    <p>Item name :<span class="data"> ' . $res[$i]->name . ' </span> </p>
                        <p>Price :<span class="data"> ' . $res[$i]->price . '</span> </p>
                        <p>Stock :<span class="data"> ' . $res[$i]->quantity . '</span> </p>
                        <p>Quantity :<span class="data"> ' . $res[$i]->quantity_measurement . '</span> </p>
                    </div> ';
            };        
        }

        public function oralcare_search(){
            $this->PharmacistModel = $this->model('Pharmacist');
            $res = $this->PharmacistModel->search_oralcare($_POST['search']);
            $countdata = count($res);
            

            for ($i = 0; $i < $countdata; $i++) {
                echo '
                    <div class="box1">
                    <img src="' . URLROOT . '/public/img/pharmacist/panadol.jpg" alt="call">
                    <p>Item name :<span class="data"> ' . $res[$i]->name . ' </span> </p>
                        <p>Price :<span class="data"> ' . $res[$i]->price . '</span> </p>
                        <p>Stock :<span class="data"> ' . $res[$i]->quantity . '</span> </p>
                        <p>Quantity :<span class="data"> ' . $res[$i]->quantity_measurement . '</span> </p>
                    </div> ';
            };        
        }

        public function firstaid_search(){
            $this->PharmacistModel = $this->model('Pharmacist');
            $res = $this->PharmacistModel->search_firstaid($_POST['search']);
            $countdata = count($res);
            

            for ($i = 0; $i < $countdata; $i++) {
                echo '
                    <div class="box1">
                    <img src="' . URLROOT . '/public/img/pharmacist/panadol.jpg" alt="call">
                    <p>Item name :<span class="data"> ' . $res[$i]->name . ' </span> </p>
                        <p>Price :<span class="data"> ' . $res[$i]->price . '</span> </p>
                        <p>Stock :<span class="data"> ' . $res[$i]->quantity . '</span> </p>
                        <p>Quantity :<span class="data"> ' . $res[$i]->quantity_measurement . '</span> </p>
                    </div> ';
            };        
        }

        public function healthdevice_search(){
            $this->PharmacistModel = $this->model('Pharmacist');
            $res = $this->PharmacistModel->search_healthdevice($_POST['search']);
            $countdata = count($res);
            

            for ($i = 0; $i < $countdata; $i++) {
                echo '
                    <div class="box1">
                    <img src="' . URLROOT . '/public/img/pharmacist/panadol.jpg" alt="call">
                    <p>Item name :<span class="data"> ' . $res[$i]->name . ' </span> </p>
                        <p>Price :<span class="data"> ' . $res[$i]->price . '</span> </p>
                        <p>Stock :<span class="data"> ' . $res[$i]->quantity . '</span> </p>
                        <p>Quantity :<span class="data"> ' . $res[$i]->quantity_measurement . '</span> </p>
                    </div> ';
            };        
        }

        public function support_search(){
            $this->PharmacistModel = $this->model('Pharmacist');
            $res = $this->PharmacistModel->search_support($_POST['search']);
            $countdata = count($res);
            

            for ($i = 0; $i < $countdata; $i++) {
                echo '
                    <div class="box1">
                    <img src="' . URLROOT . '/public/img/pharmacist/panadol.jpg" alt="call">
                    <p>Item name :<span class="data"> ' . $res[$i]->name . ' </span> </p>
                        <p>Price :<span class="data"> ' . $res[$i]->price . '</span> </p>
                        <p>Stock :<span class="data"> ' . $res[$i]->quantity . '</span> </p>
                        <p>Quantity :<span class="data"> ' . $res[$i]->quantity_measurement . '</span> </p>
                    </div> ';
            };        
        }


        //Pharmacist's login authentication
        public function login(){

          if($_SERVER['REQUEST_METHOD'] == 'POST'){

              

              //Fetch data from request form
              $data = [
                  'email' => trim($_POST['email']),
                  'password' => trim($_POST['password']),
                  
                  'email_err' => '',
                  'password_err' => ''

              ];

              //Validate email and password
              if(empty($data['email'])){
                  $data['email_err'] =  " *please enter email";
              }
              else{

                  //Check Pharmacist/email
                  if($this->PharmacistModel->findPharmacistByEmail($data['email'])){
                  //Pharmacist found

                  }
                  
                  else{
                      $data['email_err'] = " *Pharmacist not found";
                  }
              }

              //Valid Password
              if(empty($data['password'])){
                  $data['password_err'] = " *please enter password";
              }
              

              // IF ERRORS FREE, THEN ACCORDING TO Pharmacist ROLE NEED TO CREATE SEASSION AND LAND IN TO HIS/HER OWNS PAGE
              if(empty($data['email_err']) && empty($data['password_err'])){

                  //Authentication Pharmacist's email & password
                  $loggedInPharmacist = $this->PharmacistModel->login($data['email'], $data['password']);

                  if($loggedInPharmacist){
                      $this->createPharmacistSession($loggedInPharmacist);
                  }
                  else{
                      $data['password_err'] = " *incorrect password";
                      $this->view('Pharmacists/login', $data);
                  }
              }
              else{
                  $this->view('Pharmacists/login', $data);
              }


          }
          else{

              //If request is not POST then this scope will be execute

              $data = [

                  'email' => '',
                  'password' => '',

                  'email_err' => '',
                  'password_err' => ''

              ];
              $this->view('Pharmacists/login', $data);
          }

      }

     


        public function register(){
            // Check for POST
            if($_SERVER['REQUEST_METHOD'] == 'POST'){
              // Process form
        
              // Sanitize POST data
              $_POST = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING);
      
              // Init data
              $data =[
                'fName' => trim($_POST['fName']),
                'lName' => trim($_POST['lName']),
                'mobile' => trim($_POST['mobile']),
                'email' => trim($_POST['email']),
                'address' => trim($_POST['address']),
                'city' => trim($_POST['city']),
                'password' => trim($_POST['password']),
                'confirm_password' => trim($_POST['confirm_password']),
      
                'fName_err' => '',
                'lName_err' => '',
                'mobile_err' => '',
                'email_err' => '',
                'address_err' => '',
                'city_err' => '',
                'password_err' => '',
                'confirm_password_err' => ''
              ];
      
              // Validate Email
              if(empty($data['email'])){
                $data['email_err'] = 'Please enter email';
              } else {
                // Check email
                if($this->PharmacistModel->findPharmacistByEmail($data['email'])){
                  $data['email_err'] = 'Email is already taken';
                }
              }
      
              if(empty($data['mobile'])){
                  $data['mobile_err'] = 'Pleae enter mobile number';
               } else {
                  // Check mobile
                  if($this->PharmacistModel->findPharmacistByMobile($data['mobile'])){
                    $data['mobile_err'] = 'mobile number is already taken';
                  }
              } 

              


      
              // Validate Name
              if(empty($data['fName'])){
                $data['fName_err'] = 'Please enter first name';
              }
      
              if(empty($data['lName'])){
                  $data['lName_err'] = 'Please enter last name';
              }
      
              if(empty($data['address'])){
                  $data['address_err'] = 'Please enter address';
              }
      
              if(empty($data['city'])){
                  $data['city_err'] = 'Please enter city';
              }
      
              // Validate Password
              if(empty($data['password'])){
                $data['password_err'] = 'Please enter password';
              } elseif(strlen($data['password']) < 6){
                $data['password_err'] = 'Password must be at least 6 characters';
              }
      
              // Validate Confirm Password
              if(empty($data['confirm_password'])){
                $data['confirm_password_err'] = 'Please enter confirm password';
              } else {
                if($data['password'] != $data['confirm_password']){
                  $data['confirm_password_err'] = 'Passwords do not match';
                }
              }
      
              // Make sure errors are empty
              if(empty($data['email_err']) &&
                 empty($data['mobile_err']) && 
                 empty($data['fname_err']) && 
                 empty($data['lname_err']) &&
                 empty($data['address_err']) &&
                 empty($data['city_err']) &&
                 empty($data['password_err']) && empty($data['confirm_password_err'])){
                // Validated
                
                // Hash Password
                $data['password'] = password_hash($data['password'], PASSWORD_DEFAULT);
      
                // Register Pharmacist
                if($this->PharmacistModel->register($data)){
                  //flash('register_success', 'You are registered and can log in');
                  redirect('Pharmacists/login');
                } else {
                  die('Something went wrong');
                }
      
              } else {
                // Load view with errors
                $this->view('Pharmacists/register', $data);
              }
      
            } else {
              // Init data
              $data =[
                'fName' => '',
                'lName' => '',
                'mobile' => '',
                'email' => '',
                'address' => '',
                'city' => '',
                'password' => '',
                'confirm_password' => '',
      
                'fName_err' => '',
                'lName_err' => '',
                'mobile_err' => '',
                'email_err' => '',
                'address_err' => '',
                'city_err' => '',
                'password_err' => '',
                'confirm_password_err' => ''
              ];
      
              // Load view
              $this->view('Pharmacists/register', $data);

              
            }
          }


          //Create Session
          public function createPharmacistSession($Pharmacist){

            //Store session data
            $_SESSION['Pharmacist_fName'] = $Pharmacist->fName;
            $_SESSION['Pharmacist_lName'] = $Pharmacist->lName;
            $_SESSION['Pharmacist_role'] = $Pharmacist->role;
            $_SESSION['profile_pic'] = $Pharmacist->user_img;
            $_SESSION['login'] =1;

            //redirect to the Pharmacist's homepage
            die("logged successfully");
            //redirect('admin/home');

          }

          public function updateImg()
        {
            // print_r($_FILES);die();
            $this->PharmacistModel = $this->model('Pharmacist');
            $data ='';

            $target_dir = "C:/xampp/htdocs/careU_project/public/img/user-pics/";
        $filename = basename($_FILES["fileToUpload"]["name"]);
        $target_file = $target_dir . $filename;
        
        $uploadOk = 1;
        $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

        
        // Check if image file is a actual image or fake image
        if (isset($_POST["submit"])) {
            $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
            if ($check !== false) {
                echo "File is an image - " . $check["mime"] . ".";
                $uploadOk = 1;
            } else {
                echo "File is not an image.";
                $uploadOk = 0;
            }
        }

        // Check if file already exists
        if (file_exists($target_file)) {
            echo "Sorry, file already exists.";
            $uploadOk = 0;
        }

        // Check file size
        if ($_FILES["fileToUpload"]["size"] > 500000) {
            echo "Sorry, your file is too large.";
            $uploadOk = 0;
        }

        // Allow certain file formats
        if (
            $imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif"
        ) {
            echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
            $uploadOk = 0;
        }

        // Check if $uploadOk is set to 0 by an error
        if ($uploadOk == 0) {
            echo "Sorry, your file was not uploaded.";
            // if everything is ok, try to upload file
        } else {
            if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
                echo "The file " . htmlspecialchars(basename($_FILES["fileToUpload"]["name"])) . " has been uploaded.";
            } else {
                echo "Sorry, there was an error uploading your file.";
            }
        }

        $result = $this->PharmacistModel->updateProfilePic($filename,$_SESSION['email']);
        if ($result) {
            $_SESSION['profile'] = $filename;
            redirect('pharmacists/account');
        }

        
        }



        
       
        
    }

