
<?php

// dependencies for phpmailer
use PHPMailer\PHPMailer\PHPMailer;

    class admins extends Controller{

        private $adminModel;

        public function __construct()
        {
            $this->adminModel = $this->model('Admin');
        }

        //Controller for admin's dashboard
        public function index() {
          if (!isset($_SESSION['login'])) {
              redirect('/users/login');
          }
      
          $this->adminModel = $this->model('Admin');
          
          // Retrieve user counts
          $count_customer = $this->adminModel->getCount_customer();
          $count_manager = $this->adminModel->getCount_manager();
          $count_pharmacist = $this->adminModel->getCount_pharmacist();
          $count_storekeeper = $this->adminModel->getCount_storekeeper();
          $count_deliveryperson = $this->adminModel->getCount_deliveryperson();
          
          // Retrieve total user counts
          $count_customerTot = $this->adminModel->getCount_customerTot();
          $count_managerTot = $this->adminModel->getCount_managerTot();
          $count_pharmacistTot = $this->adminModel->getCount_pharmacistTot();
          $count_storekeeperTot = $this->adminModel->getCount_storekeeperTot();
          $count_deliverypersonTot = $this->adminModel->getCount_deliverypersonTot();
          
          // Retrieve deactivated user counts
          $count_customerDe = $this->adminModel->getCount_customerDe();
          $count_managerDe = $this->adminModel->getCount_managerDe();
          $count_pharmacistDe = $this->adminModel->getCount_pharmacistDe();
          $count_storekeeperDe = $this->adminModel->getCount_storekeeperDe();
          $count_deliverypersonDe = $this->adminModel->getCount_deliverypersonDe();
          
          // Retrieve user registration dates
          $users = $this->adminModel->getRegDates();

          $activeUsersCount = $this->adminModel->getActiveUsersCount();

          // Get the current date
          $currentDate = date('F d, Y');
  
        
          
          
          $data = [
              'count_customer' => $count_customer,
              'count_manager' => $count_manager,
              'count_pharmacist' => $count_pharmacist,
              'count_storekeeper' => $count_storekeeper,
              'count_deliveryperson' => $count_deliveryperson,
              
              'count_customerTot' => $count_customerTot,
              'count_managerTot' => $count_managerTot,
              'count_pharmacistTot' => $count_pharmacistTot,
              'count_storekeeperTot' => $count_storekeeperTot,
              'count_deliverypersonTot' => $count_deliverypersonTot,
              
              'count_customerDe' => $count_customerDe,
              'count_managerDe' => $count_managerDe,
              'count_pharmacistDe' => $count_pharmacistDe,
              'count_storekeeperDe' => $count_storekeeperDe,
              'count_deliverypersonDe' => $count_deliverypersonDe,
              
              'users' => $users,

              'activeUsersCount' => $activeUsersCount,
              'currentDate' => $currentDate
          ];
          
          

          $this->view('admins/admin_dashboard', $data);
      }
      

        
        /* Controller for view manager details */
        public function view_manager()
        {
            
            $ManagerDetails = $this->adminModel->view_manager();
            $data = [
              'manager_details' => $ManagerDetails
            ];

            $this->view('admins/view_manager', $data);
            
        }

        public function delete_manager()
        {
          $ManagerDetails = $this->adminModel->delete_manager();
          $data = [
            'manager_details' => $ManagerDetails
          ];

     
          $this->view('admins/delete_manager', $data);
            
        }

        public function view_pharmacist()
        {
            
            $PharmacistDetails = $this->adminModel->view_pharmacist();
            $data = [
              'pharmacist_details' => $PharmacistDetails
            ];

            $this->view('admins/view_pharmacist', $data);
        }

        public function delete_pharmacist()
        {
            $PharmacistDetails = $this->adminModel->delete_pharmacist();
            $data = [
              'pharmacist_details' => $PharmacistDetails
            ];
            $this->view('admins/delete_pharmacist', $data);
        }

        public function view_storekeeper()
        {
          $StoreKeepertDetails = $this->adminModel->view_storekeeper();
          $data = [
            'storekeeper_details' => $StoreKeepertDetails
          ];

          $this->view('admins/view_storekeeper', $data);
        }

        public function delete_storekeeper()
        {
            $StoreKeepertDetails = $this->adminModel->delete_storekeeper();
            $data = [
              'storekeeper_details' => $StoreKeepertDetails
            ];
            $this->view('admins/delete_storekeeper', $data);
        }

        public function view_deliveryperson()
        {
          $DeliveryPerson = $this->adminModel->view_deliveryperson();
          $data = [
            'deliveryperson_details' => $DeliveryPerson
          ];

          $this->view('admins/view_deliveryperson', $data);
        }

        public function delete_deliveryperson()
        {
            $DeliveryPerson = $this->adminModel->delete_deliveryperson();
            $data = [
              'deliveryperson_details' => $DeliveryPerson
            ];
            $this->view('admins/delete_deliveryperson', $data);
        }

        public function view_customer()
        {

          $Customer = $this->adminModel->view_customer();
          $data = [
            'customer_details' => $Customer
          ];

          $this->view('admins/view_customer', $data);
            
        }

       

        public function delete_customer()
        {
          $Customer = $this->adminModel->delete_customer();
          $data = [
            'customer_details' => $Customer
          ];
          $this->view('admins/delete_customer', $data);
        }
        
        
        //For view more details of users
        public function view_more(){
                 
          if($_SERVER['REQUEST_METHOD'] == 'POST'){
            $data = [
              'user_ID' => strval(trim($_POST['user_ID'])),
              'user_details' => '',
              'age' => '',
              'userRole' => ''
            ];
  
          $data['user_details'] = $UserDetail = $this->adminModel->findUserByUserID($data['user_ID']);
          $data['age'] = $userAge = $this->adminModel->calculateAge($data['user_ID']);
          $data['userRole'] = $userRole = $this->adminModel->findRole($data['user_ID']);
  
  
          $data = [
            'user_details' => $UserDetail,
            'age' => $userAge,
            'userRole' => $userRole
          ];
  
          $this->view('admins/view_more', $data);

          }else{
              die("Error occurred!");
          }  
        }


        public function DectivationEmail($userName1,$userName2, $userEmail,$review){

        $mail = new PHPMailer(true);

        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = 'true';
        $mail->Username = 'careu.meds@gmail.com';
        $mail->Password = 'rqoisanoxkfcgbjz
        ';
        $mail->SMTPSecure = 'ssl';
        $mail->Port = 465;

        $mail->setFrom('careu.meds@gmail.com');
        $mail->addAddress($userEmail);

        $mail->isHTML(true);

        $mail->Subject = 'Account Deactivated';
        $mail->Body = '            
                <html>
                <head>
                <title>Your account deactivated '. SITENAME .'</title>
                <style>
                    body {
                    font-family: Arial, sans-serif;
                    font-size: 14px;
                    }
                    h1 {
                    font-size: 18px;
                    color: #444;
                    margin-bottom: 20px;
                    }
                    ul {
                    list-style-type: none;
                    padding: 0;
                    margin: 0;
                    }
                    li {
                    margin-bottom: 10px;
                    }
                </style>
                </head>
                <body>
                <h1>Your account in '.SITENAME.' deactivated successfully.</h1>
                
                <p>Dear '. $userName1 .' '. $userName2 .',</p>
                <p>Your account in '.SITENAME.' deactivated successfully.</p>
                <p><b>Reason to deactivation: </b><i>'.$review.'.</i></p>
                <p>If you have any concerns please feel free to contact careU support team careu.meds@gmail.com .</p>
                <p>Thank you for your support.</p>
                <br>
                
                <p>Best regards,<br>The '.SITENAME.' Team</p>
                </body>
                </html>'
            ;
        
        $mail->send();

      }

      public function ActivationEmail($userName1,$userName2, $userEmail,$review){

        $mail = new PHPMailer(true);

        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = 'true';
        $mail->Username = 'careu.meds@gmail.com';
        $mail->Password = 'rqoisanoxkfcgbjz
        ';
        $mail->SMTPSecure = 'ssl';
        $mail->Port = 465;

        $mail->setFrom('careu.meds@gmail.com');
        $mail->addAddress($userEmail);

        $mail->isHTML(true);

        $mail->Subject = 'Account Activated';
        $mail->Body = '            
                <html>
                <head>
                <title>Your account activated '. SITENAME .'</title>
                <style>
                    body {
                    font-family: Arial, sans-serif;
                    font-size: 14px;
                    }
                    h1 {
                    font-size: 18px;
                    color: #444;
                    margin-bottom: 20px;
                    }
                    ul {
                    list-style-type: none;
                    padding: 0;
                    margin: 0;
                    }
                    li {
                    margin-bottom: 10px;
                    }
                </style>
                </head>
                <body>
                <h1>Your account in '.SITENAME.' activated successfully.</h1>
                
                <p>Dear '. $userName1 .' '. $userName2 .',</p>
                <p>Your account in '.SITENAME.' activated successfully.</p>
                <p><b>Reason to activation: </b><i>'.$review.'.</i></p>
                <p>If you have any concerns please feel free to contact careU support team careu.meds@gmail.com .</p>
                <p>Thank you for your support.</p>
                <br>
                
                <p>Best regards,<br>The '.SITENAME.' Team.</p>
                </body>
                </html>'
            ;
        
        $mail->send();

      }


        public function user_account_status(){

          if($_SERVER['REQUEST_METHOD'] == 'POST'){

            $data = [
              'user_ID' => strval(trim($_POST['user_ID'])),
              'popupTextarea' => strval(trim($_POST['popupTextarea'])),
              'user_details' => ''
              
            ];

            $data['user_details'] = $UserDetail = $this->adminModel->findUserByUserID($data['user_ID']);

           

            if ($data['user_details']->active_status == 'Active') {
              $this->adminModel->delete_user_account($data['user_ID']);
              $this->DectivationEmail($data['user_details']->fName, $data['user_details']->lName,$data['user_details']->email, $data['popupTextarea']);
              $flashMessage = 'User account Deactivated!';

              redirect('admins/view_' . $UserDetail->user_role . '?flashMessage=' . urlencode($flashMessage));
            }
          

            elseif($data['user_details']->active_status == 'Deactivated'){
              $this->adminModel->activate_acc($data['user_ID']);
              $this->ActivationEmail($data['user_details']->fName, $data['user_details']->lName,$data['user_details']->email, $data['popupTextarea']);

              $flashMessage = 'User account Activated!';

              redirect('admins/delete_' . $UserDetail->user_role . '?flashMessage=' . urlencode($flashMessage));
            }
            
            $data = [
              'user_details' => $UserDetail
               
            ];
           
          }else{
              die("Error occurred!");
          }  

         }

public function change_password(){

    $this->adminModel = $this->model('Admin');
    $data ="";

    $this->view('admins/change_password', $data);

}

public function change_password_action()
{
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $data = [
            'currentPassword' => trim($_POST['cur_pw']),
            'newPassword' => trim($_POST['new_pw']),
            'confirmPassword' => trim($_POST['con_pw']),
            'cur_pw_err' => '',
            'con_pw_err' => '',
        ];

        $user_ID = $_SESSION['user_ID'];

        $UserDetails = $this->adminModel->findUserByUserID($user_ID);

        if ($UserDetails) {
            $userHashedValue = $UserDetails->password;
            if (password_verify(strval($data['currentPassword']), strval($userHashedValue))) {
                // Current password is validated
            } else {
                $data['cur_pw_err'] = "*Invalid password";
            }
        } else {
            die("Something went wrong!!!");
        }

        if (strval($data["newPassword"]) != strval($data["confirmPassword"])) {
          $data["con_pw_err"] = "*Passwords do not match";
        } 
        elseif (strlen($data['newPassword']) < 8) {
          $data['con_pw_err'] = 'Password must be at least 8 characters';
        }
        elseif (!preg_match('/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z\d]+$/', $data['newPassword'])) {
          $data["con_pw_err"] = "*Password should only contain at least one lowercase letter, one uppercase letter, and one number";
        }
        

        // Check if there are no errors
        if (empty($data['cur_pw_err']) && empty($data['con_pw_err'])) {
            // Allow changing the password
            if ($this->adminModel->change_password($data)) {
                if ($_SESSION['password_changed'] == false) {
                    $_SESSION['password_changed'] = true;

                    $this->view('admins/change_password');

                    // Send email to the user
                    $userName = $_SESSION['user_fName'];
                    $userEmail = $_SESSION['user_email'];

                    $this->PasswordChangedEmail($userName, $userEmail);

                    echo "<script>
                        Swal.fire({
                            position: 'center',
                            icon: 'success',
                            title: 'Password changed successfully!',
                            showConfirmButton: false,
                            timer: 2000,
                            customClass: {
                                container: 'custom-swal-container',
                                title: 'custom-swal-title',
                            }
                        });
                    </script>";
                } else {
                    redirect('users/login');
                }
            } else {
                die();
            }
        } else {
            // Load the view with errors
            $this->view('admins/change_password', $data);
        }
    } else {
        // If the request is not a POST request, then load the form
        $data = [
            'fName' => '',
            'lName' => '',
            'email' => '',
        ];

        // Load the view
        $this->view('admins/change_password', $data);
    }
}


public function change_profileImg(){

  $this->adminModel = $this->model('Admin');
  $data ="";

  $this->view('admins/change_profileImg', $data);

}    


public function PasswordChangedEmail($userName, $userEmail){

  $mail = new PHPMailer(true);

  $mail->isSMTP();
  $mail->Host = 'smtp.gmail.com';
  $mail->SMTPAuth = 'true';
  $mail->Username = 'careu.meds@gmail.com';
  $mail->Password = 'rqoisanoxkfcgbjz
  ';
  $mail->SMTPSecure = 'ssl';
  $mail->Port = 465;

  $mail->setFrom('careu.meds@gmail.com');
  $mail->addAddress($userEmail);

  $mail->isHTML(true);

  $mail->Subject = 'Security Alert';
  $mail->Body = '            
          <html>
          <head>
          <title>Your password was changed '. SITENAME .'</title>
          <style>
              body {
              font-family: Arial, sans-serif;
              font-size: 14px;
              }
              h1 {
              font-size: 18px;
              color: #444;
              margin-bottom: 20px;
              }
              ul {
              list-style-type: none;
              padding: 0;
              margin: 0;
              }
              li {
              margin-bottom: 10px;
              }
          </style>
          </head>
          <body>
          <h1>Password Changed for '.SITENAME.' account</h1>
          <br>
          <p>Dear '. $userName .',</p>
          <p>The password for your '.SITENAME.' account '. $userEmail .' was changed. If you did not change it, you should recover your account.</a>.</p>
          <p>If you did change your password, you can ignore this message.</p>
          <br>
          
          <p>Best regards,<br>The '.SITENAME.' Team</p>
          </body>
          </html>'
      ;
  
  $mail->send();

}


public function UpdateProfilePicture(){
    if(isset($_POST["submit"])){
      $img_name = $_FILES['image1']['name'];
      $img_size = $_FILES['image1']['size'];
      $tmp_name = $_FILES['image1']['tmp_name'];
      $error = $_FILES['image1']['error'];

      if($error === 0){
          if($img_size > 12500000){
              // $data['image1_err'] = "Sorry, your first image is too large.";
              // $this->landToErrorPage();
              die();
          }
          else{
              $img_ex = pathinfo($img_name, PATHINFO_EXTENSION); //Extension type of image(jpg,png)
              $img_ex_lc = strtolower($img_ex);

              $allowed_exs = array("jpg", "jpeg", "png"); 

              if(in_array($img_ex_lc, $allowed_exs)){

                  $new_img_name = uniqid("IMG-", true).'.'.$img_ex_lc;
                  $img_upload_path = dirname(APPROOT).'/public/img/user-pics/'.$new_img_name;
                  move_uploaded_file($tmp_name, $img_upload_path);
                  // $data['image1'] = $new_img_name;

                  //Insert into database
                  if($this->adminModel->UploadProfilePicture($new_img_name)){
                      $_SESSION['profile'] = $new_img_name;
                      $this->view('admins/my_account');
                  }
                  else{
                      die('Something went wrong');
                  }
              }
              else{
                  // $data['image1_err'] = "You can't upload files of this type";
                  // $this->landToErrorPage();
                  die();
              }
          }
      }
      else{
          // $data['image1_err'] = "Unknown error occurred!";
          // $this->landToErrorPage();
          die();
      }
  }else{
      // $data['image1_err'] = 'Please upload atleast one image';
 // $this->landToErrorPage();
      die();
  }
  
}



         


public function search_manager() {
    $result = $this->adminModel->search_manager($_POST['search']);
          
    $output = '';

    if($result>0){
        foreach($result as $row) {
          $output .= '                          
                       <tr class="dataset1">
                         <td>' .$row->user_ID. '</td>
                         <td>' .$row->fName." ".$row->lName. '</td>
                         <td>' .$row->mobile. '</td>
                         <td>' .$row->email. '</td>
                         <td class="vm">
                            <form action="'.URLROOT.'/admins/view_more" method="POST">
                                <input type="hidden" name="user_ID" value="' .$row->user_ID.'">
                                <button class="viewMore" type="submit"><img src="'.URLROOT.'/public/img/admins/eye.png" alt="view more" style="width:30px;height:20px;"></button>
                             </form>
                          </td>
                        </tr>
                          ';
              }
          }

          else{
            $output .= '
            <tr><td colspan="5">No results found</td></tr>';
          }
        
          echo $output;
        }


        public function search_pharmacist() {
          $result = $this->adminModel->search_pharmacist($_POST['search']);
          
          $output = '';

          if($result>0){
            foreach($result as $row) {
              $output .= '                          
                          <tr class="dataset1">
                              <td>' .$row->user_ID. '</td>
                              <td>' .$row->fName." ".$row->lName. '</td>
                              <td>' .$row->mobile. '</td>
                              <td>' .$row->email. '</td>
                              <td class="vm">
                                  <form action="'.URLROOT.'/admins/view_more" method="POST">
                                      <input type="hidden" name="user_ID" value="' .$row->user_ID.'">
                                      <button class="viewMore" type="submit"><img src="'.URLROOT.'/public/img/admins/eye.png" alt="view more" style="width:30px;height:20px;"></button>
                                  </form>
                              </td>
                          </tr>
                          ';
              }
          }

          else{
            $output .= '
            <tr><td colspan="5">No results found</td></tr>';
          }
        
          echo $output;
        }


        public function search_storekeeper() {
          $result = $this->adminModel->search_storekeeper($_POST['search']);
          
          $output = '';

          if($result>0){
            foreach($result as $row) {
              $output .= '                          
                          <tr class="dataset1">
                              <td>' .$row->user_ID. '</td>
                              <td>' .$row->fName." ".$row->lName. '</td>
                              <td>' .$row->mobile. '</td>
                              <td>' .$row->email. '</td>
                              <td class="vm">
                                  <form action="'.URLROOT.'/admins/view_more" method="POST">
                                      <input type="hidden" name="user_ID" value="' .$row->user_ID.'">
                                      <button class="viewMore" type="submit"><img src="'.URLROOT.'/public/img/admins/eye.png" alt="view more" style="width:30px;height:20px;"></button>
                                  </form>
                              </td>
                          </tr>
                          ';
              }
          }

          else{
            $output .= '
            <tr><td colspan="5">No results found</td></tr>';
          }
        
          echo $output;
        }


        public function search_deliveryperson() {
          $result = $this->adminModel->search_deliveryperson($_POST['search']);
          
          $output = '';

          if($result>0){
            foreach($result as $row) {
              $output .= '                          
                          <tr class="dataset1">
                              <td>' .$row->user_ID. '</td>
                              <td>' .$row->fName." ".$row->lName. '</td>
                              <td>' .$row->mobile. '</td>
                              <td>' .$row->email. '</td>
                              <td class="vm">
                                  <form action="'.URLROOT.'/admins/view_more" method="POST">
                                      <input type="hidden" name="user_ID" value="' .$row->user_ID.'">
                                      <button class="viewMore" type="submit"><img src="'.URLROOT.'/public/img/admins/eye.png" alt="view more" style="width:30px;height:20px;"></button>
                                  </form>
                              </td>
                          </tr>
                          ';
              }
          }

          else{
            $output .= '
            <tr><td colspan="5">No results found</td></tr>';
          }
        
          echo $output;
        }


        public function search_customer() {
          $result = $this->adminModel->search_customer($_POST['search']);
          
          $output = '';

          if($result>0){
            foreach($result as $row) {
              $output .= '                          
                          <tr class="dataset1">
                              <td>' .$row->user_ID. '</td>
                              <td>' .$row->fName." ".$row->lName. '</td>
                              <td>' .$row->mobile. '</td>
                              <td>' .$row->email. '</td>
                              <td class="vm">
                                  <form action="'.URLROOT.'/admins/view_more" method="POST">
                                      <input type="hidden" name="user_ID" value="' .$row->user_ID.'">
                                      <button class="viewMore" type="submit"><img src="'.URLROOT.'/public/img/admins/eye.png" alt="view more" style="width:30px;height:20px;"></button>
                                  </form>
                              </td>
                          </tr>
                          ';
              }
          }

          else{
            $output .= '
            <tr><td colspan="5">No results found</td></tr>';
          }
        
          echo $output;
        }


        public function my_account(){
          

           $this->view('admins/my_account');
       }



       public function UserAddEmail($userfName,$userlName,$userEmail){

        $mail = new PHPMailer(true);
      
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = 'true';
        $mail->Username = 'careu.meds@gmail.com';
        $mail->Password = 'rqoisanoxkfcgbjz';
        $mail->SMTPSecure = 'ssl';
        $mail->Port = 465;
      
        $mail->setFrom('careu.meds@gmail.com');
        $mail->addAddress($userEmail);
      
        $mail->isHTML(true);
      
        $mail->Subject = 'Welcome to careU Pharmacy.';
        $mail->Body = '            
                <html>
                <head>
                <title>Welcome to careU Pharmacy!</title>
                <style>
                    body {
                    font-family: Arial, sans-serif;
                    font-size: 14px;
                    }
                    h1 {
                    font-size: 18px;
                    color: #444;
                    margin-bottom: 20px;
                    }
                    ul {
                    list-style-type: none;
                    padding: 0;
                    margin: 0;
                    }
                    li {
                    margin-bottom: 10px;
                    }
                </style>
                </head>
                <body>
                <p>Dear ' . $userfName . '' ." ". '' . $userlName . ',</p>
                <p>Greetings!</p>
                <p>We are pleased to inform you that your acount has been created successfully.</p>
                <p>Your account has been activated and you can access to our platform by logging in with the following credentials:</p>
                <ul>
                  <li><b>Email:</b> ' . $userEmail . '</li>
                  <li><b>Password:</b> <i>Password you set when creating account</i></li>
                </ul>
                <p>Please note that for security purposes, we strongly advise you to change your password after your first login.</p>
                <p>If you have any questions or need assistance, please don\'t hesitate to contact us.</p>
                <p>Best regards,<br>
                careU Pharmacy</p>
              </body>
              </html>
              '
              ;

              $mail->send();
       
      
      }


        

        
        private function getLastUserID_manager($lastUserID)
        {    

            if($lastUserID == " ")
             {
                 $user_ID = "M00001";
             }
             else
             {
                 $user_ID = substr($lastUserID, 5);
                 $user_ID = intval($user_ID);
                 $user_ID = "M0000" . ($user_ID+1);

            
             }
          
           
    
            return $user_ID;
        }

        


        public function add_manager(){
 


            // Check for POST
            if($_SERVER['REQUEST_METHOD'] == 'POST'){
              // Process form
        
              // Sanitize POST data
              $_POST = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING);

              // Get the latest user ID
              $lastUserID = $this->model('Admin')->getLastUserID_manager();

              // Generate the new user ID
              $user_ID = $this->getLastUserID_manager($lastUserID);

              // Save the new user to the database
              //$this->model('User')->register($user_ID);
      
              // Init data
              $data =[
                'user_ID' => $user_ID,
                'fName' => trim($_POST['fName']),
                'lName' => trim($_POST['lName']),
                'birthDate' => trim($_POST['birthDate']),
                'mobile' => trim($_POST['mobile']),
                'email' => trim($_POST['email']),
                'address' => trim($_POST['address']),
                'city' => trim($_POST['city']),
                'password' => trim($_POST['password']),
                'confirm_password' => trim($_POST['confirm_password']),
                'user_role' => 'manager',
                'joinedDate' => date('Y-m-d H:i:s'),
                'active_status' => 'Active',
      
                'fName_err' => '',
                'lName_err' => '',
                'birthDate_err' => '',
                'mobile_err' => '',
                'email_err' => '',
                'address_err' => '',
                'city_err' => '',
                'password_err' => '',
                'confirm_password_err' => ''
              ];
      
              // Validate Email
              if(empty($data['email'])){
                $data['email_err'] = 'Please enter your email address';
              } else {
                // Check email
                if($this->adminModel->findUserByEmail($data['email'])){
                  $data['email_err'] = 'This email is already taken';
                }
              }
      
              if(empty($data['mobile'])){
                  $data['mobile_err'] = 'Please enter your mobile number';
               } 
              elseif(strlen($data['mobile']) !== 10){
                $data['mobile_err'] = 'Please enter a valid mobile number';
              } 
               
              else {
                  // Check mobile
                  if($this->adminModel->findUserByMobile($data['mobile'])){
                    $data['mobile_err'] = 'This mobile number is already taken';
                  }
              } 

              


      
              // Validate Name
              if(empty($data['fName'])){
                $data['fName_err'] = 'Please enter your first name';
              }
      
              if(empty($data['lName'])){
                  $data['lName_err'] = 'Please enter your last name';
              }

              if(empty($data['birthDate'])){
                $data['birthDate_err'] = 'Please enter your birth date';
              } else {
                // Convert the birth date to a DateTime object
                $birthDate = new DateTime($data['birthDate']);
            
                // Get the current date
                $currentDate = new DateTime();
            
                // Calculate the difference between the current date and the birth date
                $age = $currentDate->diff($birthDate)->y;
            
                // Check if the age is less than 16
                if($age < 16){
                    $data['birthDate_err'] = 'Must be at least 16 years old to register';
                }
              }
      
              if(empty($data['address'])){
                  $data['address_err'] = 'Please enter your address';
              }
      
              if(empty($data['city'])){
                  $data['city_err'] = 'Please enter city';
              }
      
              // Validate Password
              if(empty($data['password'])){
                $data['password_err'] = 'Please enter a password';
              } elseif(strlen($data['password']) < 8){
                  $data['password_err'] = 'Password must be at least 8 characters';
              } elseif(!preg_match('/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z\d]+$/', $data['password'])){
                  $data['password_err'] = 'Password should contain: <br>-At least one lowercase letter <br>-At least one uppercase letter <br>-At least one number';
              }
      
              // Validate Confirm Password
              if(empty($data['confirm_password'])){
                $data['confirm_password_err'] = 'Please enter confirm password';
              } else {
                if($data['password'] != $data['confirm_password']){
                  $data['confirm_password_err'] = 'Passwords do not match';
                }
              }
      
              // Make sure errors are empty
              if(empty($data['email_err']) &&
                 empty($data['mobile_err']) && 
                 empty($data['fname_err']) && 
                 empty($data['lname_err']) &&
                 empty($data['birthDate_err']) &&
                 empty($data['address_err']) &&
                 empty($data['city_err']) &&
                 empty($data['password_err']) && empty($data['confirm_password_err'])){
                // Validated
                
                // Hash Password
                $data['password'] = password_hash($data['password'], PASSWORD_DEFAULT);
      
                // Register User
                if($this->adminModel->add_manager($data)){
                  //flash('register_success', 'You are registered and can log in');
                  
                  $this->UserAddEmail($data['fName'],$data['lName'],$data['email']);
                  $flashMessage = 'User account created Successfully!';
                  redirect('admins/add_manager?flashMessage=' . urlencode($flashMessage));
                } else {
                  die('Something went wrong');
                }
      
              } else {
                // Load view with errors
                $this->view('admins/add_manager', $data);
              }
      
            } else {
              // Init data
              $data =[
                'user_ID'=>'',
                'fName' => '',
                'lName' => '',
                'birthDate' => '',
                'mobile' => '',
                'email' => '',
                'address' => '',
                'city' => '',
                'password' => '',
                'confirm_password' => '',
                'user_role' => '',
                'joinedDate' => '',
                'active_status' => '',
      
                'fName_err' => '',
                'lName_err' => '',
                'birthDate_err' => '',
                'mobile_err' => '',
                'email_err' => '',
                'address_err' => '',
                'city_err' => '',
                'password_err' => '',
                'confirm_password_err' => ''
              ];
      
              // Load view
              $this->view('admins/add_manager', $data);

              
            }
          }



          private function getLastUserID_pharmacist($lastUserID)
          {    

            if($lastUserID == " ")
             {
                 $user_ID = "P00001";
             }
             else
             {
                 $user_ID = substr($lastUserID, 5);
                 $user_ID = intval($user_ID);
                 $user_ID = "P0000" . ($user_ID+1);

            
             }
          
           
    
            return $user_ID;
          }


        public function add_pharmacist(){
 


            // Check for POST
            if($_SERVER['REQUEST_METHOD'] == 'POST'){
              // Process form
        
              // Sanitize POST data
              $_POST = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING);

              // Get the latest user ID
              $lastUserID = $this->model('Admin')->getLastUserID_pharmacist();

              // Generate the new user ID
              $user_ID = $this->getLastUserID_pharmacist($lastUserID);

              // Save the new user to the database
              //$this->model('User')->register($user_ID);
      
              // Init data
              $data =[
                'user_ID' => $user_ID,
                'fName' => trim($_POST['fName']),
                'lName' => trim($_POST['lName']),
                'birthDate' => trim($_POST['birthDate']),
                'mobile' => trim($_POST['mobile']),
                'email' => trim($_POST['email']),
                'address' => trim($_POST['address']),
                'city' => trim($_POST['city']),
                'password' => trim($_POST['password']),
                'confirm_password' => trim($_POST['confirm_password']),
                'user_role' => 'pharmacist',
                'joinedDate' => date('Y-m-d H:i:s'),
                'active_status' => 'Active',                
      
                'fName_err' => '',
                'lName_err' => '',
                'birthDate_err' => '',
                'mobile_err' => '',
                'email_err' => '',
                'address_err' => '',
                'city_err' => '',
                'password_err' => '',
                'confirm_password_err' => ''
              ];
      
              // Validate Email
              if(empty($data['email'])){
                $data['email_err'] = 'Please enter your email address';
              } else {
                // Check email
                if($this->adminModel->findUserByEmail($data['email'])){
                  $data['email_err'] = 'This email is already taken';
                }
              }
      
              if(empty($data['mobile'])){
                  $data['mobile_err'] = 'Please enter your mobile number';
               } 
              elseif(strlen($data['mobile']) !== 10){
                $data['mobile_err'] = 'Please enter a valid mobile number';
              } 
               
              else {
                  // Check mobile
                  if($this->adminModel->findUserByMobile($data['mobile'])){
                    $data['mobile_err'] = 'This mobile number is already taken';
                  }
              } 

              


      
              // Validate Name
              if(empty($data['fName'])){
                $data['fName_err'] = 'Please enter your first name';
              }
      
              if(empty($data['lName'])){
                  $data['lName_err'] = 'Please enter your last name';
              }

              if(empty($data['birthDate'])){
                $data['birthDate_err'] = 'Please enter your birth date';
              } else {
                // Convert the birth date to a DateTime object
                $birthDate = new DateTime($data['birthDate']);
            
                // Get the current date
                $currentDate = new DateTime();
            
                // Calculate the difference between the current date and the birth date
                $age = $currentDate->diff($birthDate)->y;
            
                // Check if the age is less than 16
                if($age < 16){
                    $data['birthDate_err'] = 'Must be at least 16 years old to register';
                }
              }
      
              if(empty($data['address'])){
                  $data['address_err'] = 'Please enter your address';
              }
      
              if(empty($data['city'])){
                  $data['city_err'] = 'Please enter city';
              }
      
              // Validate Password
              if(empty($data['password'])){
                $data['password_err'] = 'Please enter a password';
              } elseif(strlen($data['password']) < 8){
                  $data['password_err'] = 'Password must be at least 8 characters';
              } elseif(!preg_match('/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z\d]+$/', $data['password'])){
                  $data['password_err'] = 'Password should contain: <br>-At least one lowercase letter <br>-At least one uppercase letter <br>-At least one number';
              }
      
              // Validate Confirm Password
              if(empty($data['confirm_password'])){
                $data['confirm_password_err'] = 'Please enter confirm password';
              } else {
                if($data['password'] != $data['confirm_password']){
                  $data['confirm_password_err'] = 'Passwords do not match';
                }
              }
      
              // Make sure errors are empty
              if(empty($data['email_err']) &&
                 empty($data['mobile_err']) && 
                 empty($data['fname_err']) && 
                 empty($data['lname_err']) &&
                 empty($data['birthDate_err']) &&
                 empty($data['address_err']) &&
                 empty($data['city_err']) &&
                 empty($data['password_err']) && empty($data['confirm_password_err'])){
                // Validated
                
                // Hash Password
                $data['password'] = password_hash($data['password'], PASSWORD_DEFAULT);
      
                // Register User
                if($this->adminModel->add_pharmacist($data)){
                  //flash('register_success', 'You are registered and can log in');
                  $this->UserAddEmail($data['fName'],$data['lName'],$data['email']);
                  $flashMessage = 'User account created Successfully!';
                  redirect('admins/add_pharmacist?flashMessage=' . urlencode($flashMessage));
                } else {
                  die('Something went wrong');
                }
      
              } else {
                // Load view with errors
                $this->view('admins/add_pharmacist', $data);
              }
      
            } else {
              // Init data
              $data =[
                'user_ID'=>'',
                'fName' => '',
                'lName' => '',
                'birthDate' => '',
                'mobile' => '',
                'email' => '',
                'address' => '',
                'city' => '',
                'password' => '',
                'confirm_password' => '',
                'user_role' => '',
                'joinedDate' => '',
                'active_status' => '',
      
                'fName_err' => '',
                'lName_err' => '',
                'birthDate_err' => '',
                'mobile_err' => '',
                'email_err' => '',
                'address_err' => '',
                'city_err' => '',
                'password_err' => '',
                'confirm_password_err' => ''
              ];
      
              // Load view
              $this->view('admins/add_pharmacist', $data);

              
            }
          }

          private function getLastUserID_storekeeper($lastUserID)
          {    

            if($lastUserID == " ")
             {
                 $user_ID = "S00001";
             }
             else
             {
                 $user_ID = substr($lastUserID, 5);
                 $user_ID = intval($user_ID);
                 $user_ID = "S0000" . ($user_ID+1);

            
             }
          
           
    
            return $user_ID;
          }


        public function add_storekeeper(){
 


            // Check for POST
            if($_SERVER['REQUEST_METHOD'] == 'POST'){
              // Process form
        
              // Sanitize POST data
              $_POST = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING);

              // Get the latest user ID
              $lastUserID = $this->model('Admin')->getLastUserID_storekeeper();

              // Generate the new user ID
              $user_ID = $this->getLastUserID_storekeeper($lastUserID);

              // Save the new user to the database
              //$this->model('User')->register($user_ID);
      
              // Init data
              $data =[
                'user_ID' => $user_ID,
                'fName' => trim($_POST['fName']),
                'lName' => trim($_POST['lName']),
                'birthDate' => trim($_POST['birthDate']),
                'mobile' => trim($_POST['mobile']),
                'email' => trim($_POST['email']),
                'address' => trim($_POST['address']),
                'city' => trim($_POST['city']),
                'password' => trim($_POST['password']),
                'confirm_password' => trim($_POST['confirm_password']),
                'user_role' => 'storekeeper',
                'joinedDate' => date('Y-m-d H:i:s'),
                'active_status' => 'Active',
      
                'fName_err' => '',
                'lName_err' => '',
                'birthDate_err' => '',
                'mobile_err' => '',
                'email_err' => '',
                'address_err' => '',
                'city_err' => '',
                'password_err' => '',
                'confirm_password_err' => ''
              ];
      
              // Validate Email
              if(empty($data['email'])){
                $data['email_err'] = 'Please enter your email address';
              } else {
                // Check email
                if($this->adminModel->findUserByEmail($data['email'])){
                  $data['email_err'] = 'This email is already taken';
                }
              }
      
              if(empty($data['mobile'])){
                  $data['mobile_err'] = 'Please enter your mobile number';
               } 
              elseif(strlen($data['mobile']) !== 10){
                $data['mobile_err'] = 'Please enter a valid mobile number';
              } 
               
              else {
                  // Check mobile
                  if($this->adminModel->findUserByMobile($data['mobile'])){
                    $data['mobile_err'] = 'This mobile number is already taken';
                  }
              } 

              


      
              // Validate Name
              if(empty($data['fName'])){
                $data['fName_err'] = 'Please enter your first name';
              }
      
              if(empty($data['lName'])){
                  $data['lName_err'] = 'Please enter your last name';
              }

              if(empty($data['birthDate'])){
                $data['birthDate_err'] = 'Please enter your birth date';
              } else {
                // Convert the birth date to a DateTime object
                $birthDate = new DateTime($data['birthDate']);
            
                // Get the current date
                $currentDate = new DateTime();
            
                // Calculate the difference between the current date and the birth date
                $age = $currentDate->diff($birthDate)->y;
            
                // Check if the age is less than 16
                if($age < 16){
                    $data['birthDate_err'] = 'Must be at least 16 years old to register';
                }
              }
      
              if(empty($data['address'])){
                  $data['address_err'] = 'Please enter your address';
              }
      
              if(empty($data['city'])){
                  $data['city_err'] = 'Please enter city';
              }
      
             // Validate Password
             if(empty($data['password'])){
              $data['password_err'] = 'Please enter a password';
            } elseif(strlen($data['password']) < 8){
                $data['password_err'] = 'Password must be at least 8 characters';
            } elseif(!preg_match('/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z\d]+$/', $data['password'])){
                $data['password_err'] = 'Password should contain: <br>-At least one lowercase letter <br>-At least one uppercase letter <br>-At least one number';
            }
      
              // Validate Confirm Password
              if(empty($data['confirm_password'])){
                $data['confirm_password_err'] = 'Please enter confirm password';
              } else {
                if($data['password'] != $data['confirm_password']){
                  $data['confirm_password_err'] = 'Passwords do not match';
                }
              }
      
              // Make sure errors are empty
              if(empty($data['email_err']) &&
                 empty($data['mobile_err']) && 
                 empty($data['fname_err']) && 
                 empty($data['lname_err']) &&
                 empty($data['birthDate_err']) &&
                 empty($data['address_err']) &&
                 empty($data['city_err']) &&
                 empty($data['password_err']) && empty($data['confirm_password_err'])){
                // Validated
                
                // Hash Password
                $data['password'] = password_hash($data['password'], PASSWORD_DEFAULT);
      
                // Register User
                if($this->adminModel->add_storekeeper($data)){
                  //flash('register_success', 'You are registered and can log in');
                  $this->UserAddEmail($data['fName'],$data['lName'],$data['email']);
                  $flashMessage = 'User account created Successfully!';
                  redirect('admins/add_storekeeper?flashMessage=' . urlencode($flashMessage));
                } else {
                  die('Something went wrong');
                }
      
              } else {
                // Load view with errors
                $this->view('admins/add_storekeeper', $data);
              }
      
            } else {
              // Init data
              $data =[
                'user_ID'=>'',
                'fName' => '',
                'lName' => '',
                'birthDate' => '',
                'mobile' => '',
                'email' => '',
                'address' => '',
                'city' => '',
                'password' => '',
                'confirm_password' => '',
                'user_role' => '',
                'joinedDate' => '',
                'active_status' => '',
      
                'fName_err' => '',
                'lName_err' => '',
                'birthDate_err' => '',
                'mobile_err' => '',
                'email_err' => '',
                'address_err' => '',
                'city_err' => '',
                'password_err' => '',
                'confirm_password_err' => ''
              ];
      
              // Load view
              $this->view('admins/add_storekeeper', $data);

              
            }
          }



          private function getLastUserID_deliveryperson($lastUserID)
          {    

            if($lastUserID == " ")
             {
                 $user_ID = "D00001";
             }
             else
             {
                 $user_ID = substr($lastUserID, 5);
                 $user_ID = intval($user_ID);
                 $user_ID = "D0000" . ($user_ID+1);

            
             }
          
           
    
            return $user_ID;
          }


        public function add_deliveryperson(){
 


            // Check for POST
            if($_SERVER['REQUEST_METHOD'] == 'POST'){
              // Process form
        
              // Sanitize POST data
              $_POST = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING);

              // Get the latest user ID
              $lastUserID = $this->model('Admin')->getLastUserID_deliveryperson();

              // Generate the new user ID
              $user_ID = $this->getLastUserID_deliveryperson($lastUserID);

              // Save the new user to the database
              //$this->model('User')->register($user_ID);
      
              // Init data
              $data =[
                'user_ID' => $user_ID,
                'fName' => trim($_POST['fName']),
                'lName' => trim($_POST['lName']),
                'birthDate' => trim($_POST['birthDate']),
                'mobile' => trim($_POST['mobile']),
                'email' => trim($_POST['email']),
                'address' => trim($_POST['address']),
                'city' => trim($_POST['city']),
                'password' => trim($_POST['password']),
                'confirm_password' => trim($_POST['confirm_password']),
                'user_role' => 'deliveryperson',
                'joinedDate' => date('Y-m-d H:i:s'),
                'active_status' => 'Active',
      
                'fName_err' => '',
                'lName_err' => '',
                'birthDate_err' => '',
                'mobile_err' => '',
                'email_err' => '',
                'address_err' => '',
                'city_err' => '',
                'password_err' => '',
                'confirm_password_err' => ''
              ];
      
              // Validate Email
              if(empty($data['email'])){
                $data['email_err'] = 'Please enter your email address';
              } else {
                // Check email
                if($this->adminModel->findUserByEmail($data['email'])){
                  $data['email_err'] = 'This email is already taken';
                }
              }
      
              if(empty($data['mobile'])){
                  $data['mobile_err'] = 'Please enter your mobile number';
               } 
              elseif(strlen($data['mobile']) !== 10){
                $data['mobile_err'] = 'Please enter a valid mobile number';
              } 
               
              else {
                  // Check mobile
                  if($this->adminModel->findUserByMobile($data['mobile'])){
                    $data['mobile_err'] = 'This mobile number is already taken';
                  }
              } 

              


      
              // Validate Name
              if(empty($data['fName'])){
                $data['fName_err'] = 'Please enter your first name';
              }
      
              if(empty($data['lName'])){
                  $data['lName_err'] = 'Please enter your last name';
              }

              if(empty($data['birthDate'])){
                $data['birthDate_err'] = 'Please enter your birth date';
              } else {
                // Convert the birth date to a DateTime object
                $birthDate = new DateTime($data['birthDate']);
            
                // Get the current date
                $currentDate = new DateTime();
            
                // Calculate the difference between the current date and the birth date
                $age = $currentDate->diff($birthDate)->y;
            
                // Check if the age is less than 16
                if($age < 16){
                    $data['birthDate_err'] = 'Must be at least 16 years old to register';
                }
              }
      
              if(empty($data['address'])){
                  $data['address_err'] = 'Please enter your address';
              }
      
              if(empty($data['city'])){
                  $data['city_err'] = 'Please enter city';
              }
      
              // Validate Password
              if(empty($data['password'])){
                $data['password_err'] = 'Please enter password';
              } elseif(strlen($data['password']) < 6){
                $data['password_err'] = 'Password must be at least 6 characters';
              }
      
              // Validate Password
              if(empty($data['password'])){
                $data['password_err'] = 'Please enter a password';
              } elseif(strlen($data['password']) < 8){
                  $data['password_err'] = 'Password must be at least 8 characters';
              } elseif(!preg_match('/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z\d]+$/', $data['password'])){
                  $data['password_err'] = 'Password should contain: <br>-At least one lowercase letter <br>-At least one uppercase letter <br>-At least one number';
              }
      
              // Make sure errors are empty
              if(empty($data['email_err']) &&
                 empty($data['mobile_err']) && 
                 empty($data['fname_err']) && 
                 empty($data['lname_err']) &&
                 empty($data['birthDate_err']) &&
                 empty($data['address_err']) &&
                 empty($data['city_err']) &&
                 empty($data['password_err']) && empty($data['confirm_password_err'])){
                // Validated
                
                // Hash Password
                $data['password'] = password_hash($data['password'], PASSWORD_DEFAULT);
      
                // Register User
                if($this->adminModel->add_deliveryperson($data)){
                  //flash('register_success', 'You are registered and can log in');
                  $this->UserAddEmail($data['fName'],$data['lName'],$data['email']);
                  $flashMessage = 'User account created Successfully!';
                  redirect('admins/add_deliveryperson?flashMessage=' . urlencode($flashMessage));
                } else {
                  die('Something went wrong');
                }
      
              } else {
                // Load view with errors
                $this->view('admins/add_deliveryperson', $data);
              }
      
            } else {
              // Init data
              $data =[
                'user_ID'=>'',
                'fName' => '',
                'lName' => '',
                'birthDate' => '',
                'mobile' => '',
                'email' => '',
                'address' => '',
                'city' => '',
                'password' => '',
                'confirm_password' => '',
                'user_role' => '',
                'joinedDate' => '',
                'active_status' => '',
      
                'fName_err' => '',
                'lName_err' => '',
                'birthDate_err' => '',
                'mobile_err' => '',
                'email_err' => '',
                'address_err' => '',
                'city_err' => '',
                'password_err' => '',
                'confirm_password_err' => ''
              ];
      
              // Load view
              $this->view('admins/add_deliveryperson', $data);

              
            }
          }

         








    }