<head>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@10.16.6/dist/sweetalert2.min.css">
</head>
<body>
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10.16.6/dist/sweetalert2.min.js"></script>
</body>

<?php 
    class Storekeepers extends Controller{

        //Create variable to connect to DB
        private $userModel;

        //Assigned 'User' model file
        public function __construct(){
            $this->userModel = $this->model('User');
        }
        
        public function index(){
            if (!isset($_SESSION['login'])) {
                redirect('users/login');
            }
            $this->userModel=$this->model('User');
            $data='';
            $this->view('storeKeepers/dashboard',$data);
        }


//-------------------------------------------------NEED TO MERGE--------------------------------------------------------------------
        public function dashboard(){
          if (!isset($_SESSION['login'])) {
              redirect('users/login');
          }
          $this->StorekeeperModel=$this->model('Storekeeper');

          $lowstock_count=$this->StorekeeperModel-> get_lowstock_count();
          $expired_count=$this->StorekeeperModel-> get_expired_count();
          $medicine_count=$this->StorekeeperModel-> get_medicine_count();
          $personalcare_count=$this->StorekeeperModel-> get_personalcare_count();
          $medicaldevices_count=$this->StorekeeperModel-> get_medicaldevices_count();

          $total_meds_count=$this->StorekeeperModel-> get_all_meds_count();


          $quantity_array = $this->StorekeeperModel->updateQuantityReport();                  //calculate the sales_report table according to orders 


          $data=[
            'lowstock_count'=>$lowstock_count,
            'expired_count'=>$expired_count,
            'medicine_count'=>$medicine_count,
            'personalcare_count'=>$personalcare_count,
            'medicaldevices_count'=>$medicaldevices_count,
            'meds_count'=>$total_meds_count,
            'monthly_quantity'=>$quantity_array
        ];

          $this->view('storeKeepers/dashboard',$data);
       }

//---------------------------------------------------------------------------------------------------------------------------------



        // view 

        public function view_medicine_heart()
        {
          if (!isset($_SESSION['login'])) {
            redirect('users/login');
          }
            $this->StorekeeperModel = $this->model('Storekeeper');
            $heartmeds = $this->StorekeeperModel-> getHeartMeds();
            $data =$heartmeds;
            $this->view('storeKeepers/view_medicine_heart', $data);
        }

        public function view_medicine_diabetes()
        {
          if (!isset($_SESSION['login'])) {
            redirect('users/login');
          }
            $this->StorekeeperModel = $this->model('Storekeeper');
            $diabetesmeds = $this -> StorekeeperModel ->getdiabetesMeds();
            $data =$diabetesmeds;
            $this->view('storeKeepers/view_medicine_diabetes', $data);
        }

        public function view_medicine_gastro()
        {
          if (!isset($_SESSION['login'])) {
            redirect('users/login');
          }
            $this->StorekeeperModel = $this->model('Storekeeper');
            $gastromeds = $this->StorekeeperModel->getgastroMeds();
            $data =$gastromeds;
            $this->view('storeKeepers/view_medicine_gastro', $data);
        }

        public function view_medicine_infection()
        {
          if (!isset($_SESSION['login'])) {
            redirect('users/login');
          }
            $this->StorekeeperModel = $this->model('Storekeeper');
            $infectionmeds = $this->StorekeeperModel ->getinfectionMeds();
            $data =$infectionmeds;
            $this->view('storeKeepers/view_medicine_infection', $data);
        }

        public function view_medicine_muscle()
        {
          if (!isset($_SESSION['login'])) {
            redirect('users/login');
          }
            $this->StorekeeperModel = $this->model('Storekeeper');
            $musclemeds=$this->StorekeeperModel->getmuscleMeds();
            $data =$musclemeds;
            $this->view('storeKeepers/view_medicine_muscle', $data);
        }

        public function view_pc_nourishments()
        {
          if (!isset($_SESSION['login'])) {
            redirect('users/login');
          }
            $this->StorekeeperModel = $this->model('Storekeeper');
            $noruish_pc = $this->StorekeeperModel->getnourishments();
            $data =$noruish_pc;
            $this->view('storeKeepers/view_pc_nourishments', $data);
        }

        public function view_pc_accessories()
        {
          if (!isset($_SESSION['login'])) {
            redirect('users/login');
          }
            $this->StorekeeperModel = $this->model('Storekeeper');
            $accessories_pc = $this->StorekeeperModel->getaccessories();
            $data = $accessories_pc;
            $this->view('storeKeepers/view_pc_accessories', $data);
        }

        public function view_pc_skincare()
        {
          if (!isset($_SESSION['login'])) {
            redirect('users/login');
          }
            $this->StorekeeperModel = $this->model('Storekeeper');
            $skincare_pc = $this->StorekeeperModel->getskincare();
            $data =$skincare_pc;
            $this->view('storeKeepers/view_pc_skincare', $data);
        }

        public function view_pc_womenpc()
        {
          if (!isset($_SESSION['login'])) {
            redirect('users/login');
          }
            $this->StorekeeperModel = $this->model('Storekeeper');
            $womencare_pc = $this->StorekeeperModel->women_personalcare();
            $data =$womencare_pc;
            $this->view('storeKeepers/view_pc_womenpc', $data);
        }

        public function view_pc_oralcare()
        {
          if (!isset($_SESSION['login'])) {
            redirect('users/login');
          }
            $this->StorekeeperModel = $this->model('Storekeeper');
            $oralcare = $this->StorekeeperModel->oralcare();
            $data =$oralcare;
            $this->view('storeKeepers/view_pc_oralcare', $data);
        }

        public function view_md_firstaid()
        {
          if (!isset($_SESSION['login'])) {
            redirect('users/login');
          }
            $this->StorekeeperModel = $this->model('Storekeeper');
            $firstaid = $this->StorekeeperModel->firstaid();
            $data =$firstaid;
            $this->view('storeKeepers/view_md_firstaid', $data);
        }

        public function view_md_healthdevice()
        {
          if (!isset($_SESSION['login'])) {
            redirect('users/login');
          }
            $this->StorekeeperModel = $this->model('Storekeeper');
            $health_device = $this->StorekeeperModel->health_device();
            $data =$health_device;
            $this->view('storeKeepers/view_md_healthdevice', $data);
        }

        public function view_md_support()
        {
          if (!isset($_SESSION['login'])) {
            redirect('users/login');
         }
            $this->StorekeeperModel = $this->model('Storekeeper');
            $support = $this->StorekeeperModel->support();
            $data =$support;
            $this->view('storeKeepers/view_md_support', $data);
        }



        //delete


        public function delete_medicine_heart()
        {
          if (!isset($_SESSION['login'])) {
            redirect('users/login');
          }
            $this->StorekeeperModel = $this->model('Storekeeper');
            $heartmeds = $this->StorekeeperModel-> getHeartMeds();
            $data =$heartmeds;
            $this->view('storeKeepers/delete_medicine_heart', $data);
        }

        public function delete_medicine_diabetes()
        {
          if (!isset($_SESSION['login'])) {
            redirect('users/login');
          }
            $this->StorekeeperModel = $this->model('Storekeeper');
            $diabetesmeds = $this -> StorekeeperModel ->getdiabetesMeds();
            $data =$diabetesmeds;
            $this->view('storeKeepers/delete_medicine_diabetes', $data);
        }

        public function delete_medicine_gastro()
        {
          if (!isset($_SESSION['login'])) {
            redirect('users/login');
          }
            $this->StorekeeperModel = $this->model('Storekeeper');
            $gastromeds = $this->StorekeeperModel->getgastroMeds();
            $data =$gastromeds;
            $this->view('storeKeepers/delete_medicine_gastro', $data);
        }

        public function delete_medicine_infection()
        {
          if (!isset($_SESSION['login'])) {
            redirect('users/login');
          }
            $this->StorekeeperModel = $this->model('Storekeeper');
            $infectionmeds = $this->StorekeeperModel ->getinfectionMeds();
            $data =$infectionmeds;
            $this->view('storeKeepers/delete_medicine_infection', $data);
        }

        public function delete_medicine_muscle()
        {
          if (!isset($_SESSION['login'])) {
            redirect('users/login');
          }
            $this->StorekeeperModel = $this->model('Storekeeper');
            $musclemeds=$this->StorekeeperModel->getmuscleMeds();
            $data =$musclemeds;
            $this->view('storeKeepers/delete_medicine_muscle', $data);
        }

        public function delete_pc_nourishments()
        {
          if (!isset($_SESSION['login'])) {
            redirect('users/login');
          }
            $this->StorekeeperModel = $this->model('Storekeeper');
            $noruish_pc = $this->StorekeeperModel->getnourishments();
            $data =$noruish_pc;
            $this->view('storeKeepers/delete_pc_nourishments', $data);
        }

        public function delete_pc_accessories()
        {
          if (!isset($_SESSION['login'])) {
            redirect('users/login');
          }
            $this->StorekeeperModel = $this->model('Storekeeper');
            $accessories_pc = $this->StorekeeperModel->getaccessories();
            $data = $accessories_pc;
            $this->view('storeKeepers/delete_pc_accessories', $data);
        }

        public function delete_pc_skincare()
        {
          if (!isset($_SESSION['login'])) {
            redirect('users/login');
          }
            $this->StorekeeperModel = $this->model('Storekeeper');
            $skincare_pc = $this->StorekeeperModel->getskincare();
            $data =$skincare_pc;
            $this->view('storeKeepers/delete_pc_skincare', $data);
        }

        public function delete_pc_womenpc()
        {
          if (!isset($_SESSION['login'])) {
            redirect('users/login');
          }
            $this->StorekeeperModel = $this->model('Storekeeper');
            $womencare_pc = $this->StorekeeperModel->women_personalcare();
            $data =$womencare_pc;
            $this->view('storeKeepers/delete_pc_womenpc', $data);
        }

        public function delete_pc_oralcare()
        {
          if (!isset($_SESSION['login'])) {
            redirect('users/login');
          }
            $this->StorekeeperModel = $this->model('Storekeeper');
            $oralcare = $this->StorekeeperModel->oralcare();
            $data =$oralcare;
            $this->view('storeKeepers/delete_pc_oralcare', $data);
        }

        public function delete_md_firstaid()
        {
          if (!isset($_SESSION['login'])) {
            redirect('users/login');
          }
            $this->StorekeeperModel = $this->model('Storekeeper');
            $firstaid = $this->StorekeeperModel->firstaid();
            $data =$firstaid;
            $this->view('storeKeepers/delete_md_firstaid', $data);
        }

        public function delete_md_healthdevice()
        {
          if (!isset($_SESSION['login'])) {
            redirect('users/login');
          }
            $this->StorekeeperModel = $this->model('Storekeeper');
            $health_device = $this->StorekeeperModel->health_device();
            $data =$health_device;
            $this->view('storeKeepers/delete_md_healthdevice', $data);
        }

        public function delete_md_supports()
        {
          if (!isset($_SESSION['login'])) {
            redirect('users/login');
          }
            $this->StorekeeperModel = $this->model('Storekeeper');
            $support = $this->StorekeeperModel->support();
            $data =$support;
            $this->view('storeKeepers/delete_md_supports', $data);
        }



        //add

        public function Add_medicaldevices(){
          if (!isset($_SESSION['login'])) {
            redirect('users/login');
          }
            $this->StorekeeperModel = $this->model('Storekeeper');

            $meds = $this->StorekeeperModel-> getlastID();
            $data =$meds;

            $this->view('storeKeepers/add_medicaldevices',$data);
            
        }

        // public function Add_medicine(){
        //     $this->StorekeeperModel=$this->model('Storekeeper');
            
        //     $meds = $this->StorekeeperModel-> getlastID();
            
        //     $data = [
        //       'medicine_id' => $meds,
        //       'medicine_name'=>'',
        //       'quantity_mesurement'=>'',
        //       'date_of_expiry' => '',
        //       'total_items' =>'',
        //       'price' =>'',
        //       'image'=>''
        //     ];

        //     $this->view('storeKeepers/add_medicine',$data);
        // }


     
        public function Add_personalcare(){
          if (!isset($_SESSION['login'])) {
            redirect('users/login');
          }
            $this->StorekeeperModel=$this->model('Storekeeper');
            
            $meds = $this->StorekeeperModel-> getlastID();
            $data =$meds;

            $this->view('storeKeepers/add_personalcare',$data);
        }

        

        public function add_medicine_form(){
            if (!isset($_SESSION['login'])) {
              redirect('users/login');
            }
            if($_SERVER['REQUEST_METHOD'] == 'POST'){
              // Sanitize POST array
              $_POST = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING);

              $prescription = isset($_POST['prescription']) ? 1 : 0;
      
              //need to add avatar
              $data = [
                'service'=>trim($_POST['service']),
                'medicine_type'=>trim($_POST['medicine_type']),
                'medicine_id'=>trim($_POST['medicine_id']),
                'medicine_name'=>trim($_POST['medicine_name']),
                'quantity_mesurement'=>trim($_POST['quantity_mesurement']),
                'date_of_expiry' => trim($_POST['expiry_date']),
                'total_items' => trim($_POST['total_items']),
                'price' => trim($_POST['price']),
                'image'=>$_POST['avatar'],
                'prescription'=>$prescription,
                'medicine_id_err'=>'',
                'medicine_name_err'=>'',
                'date_of_expiry_err'=>'',
                'total_items_err'=>'',
                'price_err'=>''
              ];
              
              // Validate data
              if(empty($data['medicine_id'])){
                $data['medicine_id_err'] = "*Please enter medicine id";
              }
              if(empty($data['medicine_name'])){
                $data['medicine_name_err'] = "*Please enter medicine name";
              }
              if(empty($data['date_of_expiry'])){
                $data['date_of_expiry_err'] = "*Please enter expiry date";
              }
              if(strtotime($data['date_of_expiry']) < strtotime(date('Y-m-d'))){
                $data['date_of_expiry_err'] = "*Please enter valid expiry date";
              }
              if(empty($data['total_items'])){
                $data['total_items_err'] = "*Please enter quantity";
              }
              if($data['total_items']<0 || $data['total_items']==0){
                $data['total_items_err'] = "*Please enter valid quantity";
              }
              if(empty($data['price'])){
                $data['price_err'] = "*Please enter price";
              }
              if($data['price']<0 || $data['price']==0){
                $data['price_err'] = "*Please enter valid price";
              }
              
              // Make sure no errors
              if(empty($data['medicine_id_err']) && empty($data['medicine_name_err']) && empty($data['date_of_expiry_err']) && empty($data['total_items_err']) && empty($data['price_err'])){
                  // Validated
                  $this->StorekeeperModel = $this->model('Storekeeper');
                  $health_device = $this->StorekeeperModel->addmedicine($data);

                  if($health_device){
                    
                    echo "<script>
                          Swal.fire({
                              title: 'medicine added successfully!',
                              timer: 2000,
                              confirmButtonColor: '#3085d6',
                              backdrop: `
                                  rgba(0,0,100,0.1)
                                  url('/images/nyan-cat.gif')
                                  left top
                                  no-repeat
                                `
                          }).then(function() {
                            window.location.href = '" . URLROOT . "/Storekeepers/view_medicine_".$data['medicine_type']."';
                        });
                          </script>";

                    // redirect('storeKeepers/view_medicine_'.$data['medicine_type']);         // ridirect to added page only did for medcines other page names are complicated
                  } else {
                    die('something went wrong');
                  }
              } else {
                  // Load view with errors
                  $this->view('storeKeepers/add_medicine', $data);
              }
      
            } else {
                  $this->StorekeeperModel=$this->model('Storekeeper');
                  $meds = $this->StorekeeperModel-> getlastID();

                  $data = [
                    'service'=>'',
                    'medicine_type'=>'',
                    'medicine_id'=>$meds,
                    'medicine_name'=>'',
                    'quantity_mesurement'=>'',
                    'date_of_expiry' =>'',
                    'total_items' =>'',
                    'price' =>'',
                    'image'=>'',
                    'prescription'=>'',
                    'medicine_id_err'=>'',
                    'medicine_name_err'=>'',
                    'date_of_expiry_err'=>'',
                    'total_items_err'=>'',
                    'price_err'=>''
                  ];
                  
                  $this->view('storeKeepers/add_medicine', $data);
            }
        }
        
     


        public function add_medicaldevices_form(){
          if (!isset($_SESSION['login'])) {
            redirect('users/login');
          }
            if($_SERVER['REQUEST_METHOD'] == 'POST'){
              // Sanitize POST array
              $_POST = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING);
      
              $prescription = isset($_POST['prescription']) ? 1 : 0;

              $data = [
                'service'=>trim($_POST['service']),
                'medicine_type'=>trim($_POST['medicine_type']),
                'medicine_id'=>trim($_POST['medicine_id']),
                'medicine_name'=>trim($_POST['medicine_name']),
                'quantity_mesurement'=>trim($_POST['quantity_mesurement']),
                'date_of_expiry' => trim($_POST['expiry_date']),
                'total_items' => trim($_POST['total_items']),
                'price' => trim($_POST['price']),
                'image'=>$_POST['avatar'],
                'prescription'=>$prescription,
                'medicine_id_err'=>'',
                'medicine_name_err'=>'',
                'date_of_expiry_err'=>'',
                'total_items_err'=>'',
                'price_err'=>''
              ];
              
              // Validate data
              if(empty($data['medicine_id'])){
                $data['medicine_id_err'] = "*Please enter medicine id";
              }
              if(empty($data['medicine_name'])){
                $data['medicine_name_err'] = "*Please enter medicine name";
              }
              if(empty($data['date_of_expiry'])){
                $data['date_of_expiry_err'] = "*Please enter expiry date";
              }
              if(strtotime($data['date_of_expiry']) < strtotime(date('Y-m-d'))){
                $data['date_of_expiry_err'] = "*Please enter valid expiry date";
              }
              if(empty($data['total_items'])){
                $data['total_items_err'] = "*Please enter quantity";
              }
              if($data['total_items']<0 || $data['total_items']==0) {
                  $data['total_items_err'] = "*Please enter valid quantity";
              }
              if(empty($data['price'])){
                $data['price_err'] = "*Please enter price";
              }
              if($data['price']<0 || $data['price']==0){
                $data['price_err'] = "*Please enter valid price";
              }
              
              // Make sure no errors
              if(empty($data['medicine_id_err']) && empty($data['medicine_name_err']) && empty($data['date_of_expiry_err']) && empty($data['total_items_err']) && empty($data['price_err'])){
                // Validated
                $this->StorekeeperModel = $this->model('Storekeeper');
                $health_device = $this->StorekeeperModel->addmedicine($data);

                if($health_device){

                  echo "<script>
                            Swal.fire({
                                title: 'medical device added successfully!',
                                timer: 2000,
                                confirmButtonColor: '#3085d6',
                                backdrop: `
                                    rgba(0,0,100,0.1)
                                    url('/images/nyan-cat.gif')
                                    left top
                                    no-repeat
                                  `
                            }).then(function() {
                              window.location.href = '" . URLROOT . "/Storekeepers/view_md_".$data['medicine_type']."';
                          });
                      </script>";

                  // redirect('storeKeepers/view_md_firstaid');                
                } else {
                  die('something went wrong');
                }
              } else {
                // Load view with errors
                $this->view('storeKeepers/add_medicaldevices', $data);
              }
      
            } else {
              $this->StorekeeperModel=$this->model('Storekeeper');
              $meds = $this->StorekeeperModel-> getlastID();

              $data = [
                'service'=>'',
                'medicine_type'=>'',
                'medicine_id'=>$meds,
                'medicine_name'=>'',
                'quantity_mesurement'=>'',
                'date_of_expiry' =>'',
                'total_items' =>'',
                'price' =>'',
                'image'=>'',
                'prescription'=>'',
                'medicine_id_err'=>'',
                'medicine_name_err'=>'',
                'date_of_expiry_err'=>'',
                'total_items_err'=>'',
                'price_err'=>''
              ];
              
              $this->view('storeKeepers/add_medicaldevices', $data);
            }
          }
        


          public function add_personalcare_form(){
            if (!isset($_SESSION['login'])) {
              redirect('users/login');
            }
            if($_SERVER['REQUEST_METHOD'] == 'POST'){
              // Sanitize POST array
              $_POST = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING);

              $prescription = isset($_POST['prescription']) ? 1 : 0;
      
              $data = [
                'service'=>trim($_POST['service']),
                'medicine_type'=>trim($_POST['medicine_type']),
                'medicine_id'=>trim($_POST['medicine_id']),
                'medicine_name'=>trim($_POST['medicine_name']),
                'quantity_mesurement'=>trim($_POST['quantity_mesurement']),
                'date_of_expiry' => trim($_POST['expiry_date']),
                'total_items' => trim($_POST['total_items']),
                'price' => trim($_POST['price']),
                'image'=>$_POST['avatar'],
                'prescription'=>$prescription,
                'medicine_id_err'=>'',
                'medicine_name_err'=>'',
                'date_of_expiry_err'=>'',
                'total_items_err'=>'',
                'price_err'=>''
              ];
              
              // Validate data
              if(empty($data['medicine_id'])){
                $data['medicine_id_err'] = "*Please enter medicine id";
              }
              if(empty($data['medicine_name'])){
                $data['medicine_name_err'] = "*Please enter medicine name";
              }
              if(empty($data['date_of_expiry'])){
                $data['date_of_expiry_err'] = "*Please enter expiry date";
              }
              if(strtotime($data['date_of_expiry']) < strtotime(date('Y-m-d'))){
                $data['date_of_expiry_err'] = "*Please enter valid expiry date";
              }
              if(empty($data['total_items'])){
                $data['total_items_err'] = "*Please enter quantity";
              }
              if($data['total_items']<0 || $data['total_items']==0) {
                $data['total_items_err'] = "*Please enter valid quantity";
              }
              if(empty($data['price'])){
                $data['price_err'] = "*Please enter price";
              }
              if($data['price']<0 || $data['price']==0){
                $data['price_err'] = "*Please enter valid price";
              }
              
              // Make sure no errors
              if(empty($data['medicine_id_err']) && empty($data['medicine_name_err']) && empty($data['date_of_expiry_err']) && empty($data['total_items_err']) && empty($data['price_err'])){
                // Validated
                $this->StorekeeperModel = $this->model('Storekeeper');
                $health_device = $this->StorekeeperModel->addmedicine($data);



                if($health_device){

                  if($data['medicine_type']=="women personal care"){
                      echo "<script>
                              Swal.fire({
                                  title: 'personal care added successfully!',
                                  timer: 2000,
                                  confirmButtonColor: '#3085d6',
                                  backdrop: `
                                      rgba(0,0,100,0.1)
                                      url('/images/nyan-cat.gif')
                                      left top
                                      no-repeat
                                    `
                              }).then(function() {
                                window.location.href = '" . URLROOT . "/Storekeepers/view_pc_womenpc';
                            });
                        </script>";
                  }
                  else{
                    echo "<script>
                              Swal.fire({
                                  title: 'personal care added successfully!',
                                  timer: 2000,
                                  confirmButtonColor: '#3085d6',
                                  backdrop: `
                                      rgba(0,0,100,0.1)
                                      url('/images/nyan-cat.gif')
                                      left top
                                      no-repeat
                                    `
                              }).then(function() {
                                window.location.href = '" . URLROOT . "/Storekeepers/view_pc_".$data['medicine_type']."';
                            });
                        </script>";
                  }
                  // redirect('storeKeepers/view_pc_nourishments');                
                } else {
                  die('something went wrong');
                }
              } else {
                // Load view with errors
                $this->view('storeKeepers/add_personalcare', $data);
              }
      
            } else {
              $this->StorekeeperModel=$this->model('Storekeeper');
              $meds = $this->StorekeeperModel-> getlastID();

              $data = [
                'service'=>'',
                'medicine_type'=>'',
                'medicine_id'=>$meds,
                'medicine_name'=>'',
                'quantity_mesurement'=>'',
                'date_of_expiry' =>'',
                'total_items' =>'',
                'price' =>'',
                'image'=>'',
                'prescription'=>'',
                'medicine_id_err'=>'',
                'medicine_name_err'=>'',
                'date_of_expiry_err'=>'',
                'total_items_err'=>'',
                'price_err'=>''
              ];
              
              $this->view('storeKeepers/add_personalcare', $data);
            }
        }
        

      // public function view_medicine_Detail(){
      //     $this->StorekeeperModel=$this->model('Storekeeper');
          
      //     // $meds = $this->StorekeeperModel-> getPost_attributes();
      //     $data ='';

      //     $this->view('storeKeepers/view_medicine_Detail',$data);
      // }

      public function show_medicine($id){
        if (!isset($_SESSION['login'])) {
          redirect('users/login');
        }
        $this->StorekeeperModel = $this->model('Storekeeper');
        $medicine = $this->StorekeeperModel->getMedicineByID($id);

        $data =[
          'medicine'=>$medicine
        ];
        $this->view('storeKeepers/view_medicine_Detail', $data);
      }


      public function fetch_medicine($id)
      {
        if (!isset($_SESSION['login'])) {
          redirect('users/login');
        }
          $this->StorekeeperModel = $this->model('Storekeeper');
          $medicine = $this->StorekeeperModel->getMedicineByID($id);

          $data =[
            'medicine'=>$medicine,
            'price_negative_err'=>'',
            'quantity_negative_err'=>'',
            'date_negative_err'=>''
          ];

          if($data['medicine']->medicine_type1=="medicine"){
            $this->view('storeKeepers/edit_medicine_Detail', $data);
          }
          elseif($data['medicine']->medicine_type1=="medical devices"){
            $this->view('storeKeepers/edit_medicaldevices_Detail', $data);
          }
          elseif($data['medicine']->medicine_type1=="personal care"){
            $this->view('storeKeepers/edit_personalcare_Detail', $data);
          }
      }

      
      //edit

      public function edit_medicine_form($id){
        if (!isset($_SESSION['login'])) {
          redirect('users/login');
        }
        if($_SERVER['REQUEST_METHOD'] == 'POST'){
          // Sanitize POST array
          $_POST = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING);
  
          //need to add avatar
          $data = [
            'medicine_id'=>$id,
            'old_quantity' => trim($_POST['total_items_hidden']),
            'total_items' => trim($_POST['updated_quantity']),
            'medicine_radio' => trim($_POST['medicine_operation']),
            'price' => trim($_POST['updated_price']),
            'expiry_date' => trim($_POST['expiry_date']),
            'price_negative_err'=>'',
            'quantity_negative_err'=>'',
            'date_negative_err'=>''
          ];
             
          // Validate data
          if($data['price']<0){
            $data['price_negative_err'] = "*Please enter valid Price";
          }
          if($data['total_items']<0){
            $data['quantity_negative_err'] = "*Please enter valid Amount";
          }
          if(!empty($data['expiry_date']) && strtotime($data['expiry_date']) < strtotime(date('Y-m-d'))){
            $data['date_negative_err'] = "*Please enter valid expiry date";
          }
          if($data['medicine_radio']=='remove'){
              if($data['total_items']>$data['old_quantity']) {
                  $data['quantity_negative_err'] = "*Please enter valid amount";
              }
          }

          // Make sure no errors
          if(empty($data['price_negative_err']) && empty($data['quantity_negative_err']) && empty($data['date_negative_err'])){
            // Validated
            $this->StorekeeperModel = $this->model('Storekeeper');
            $database_query = $this->StorekeeperModel->editmedicine($data);

            if($database_query){
              echo "<script>
                        Swal.fire({
                            title: 'medicine updated successfully!',
                            timer: 2000,
                            confirmButtonColor: '#3085d6',
                            backdrop: `
                                rgba(0,0,100,0.1)
                                url('/images/nyan-cat.gif')
                                left top
                                no-repeat
                              `
                        }).then(function() {
                          window.location.href = '" . URLROOT . "/Storekeepers/delete_medicine_heart';
                      });
                  </script>";

              // redirect('storeKeepers/delete_medicine_heart');         
            } else {
              die('something went wrong');
            }
          } else {
            // Load view with errors
            $this->StorekeeperModel = $this->model('Storekeeper');
            $medicine = $this->StorekeeperModel->getMedicineByID($id);
  
            $data =[
              'medicine'=>$medicine,
              'price_negative_err'=>$data['price_negative_err'],
              'quantity_negative_err'=>$data['quantity_negative_err'],
              'date_negative_err'=>$data['date_negative_err']
            ];
            $this->view('storeKeepers/edit_medicine_Detail', $data);
            // redirect('storeKeepers/fetch_medicine/'.$data['medicine_id']);         
          }
  
        } else {
          $data = [
            'medicine_id'=>$id,
            'medicine_radio'=>'',
            'total_items' =>'',
            'price'=>'',
            'expiry_date'=>'',
            'price_negative_err'=>'',
            'quantity_negative_err'=>'',
            'date_negative_err'=>''
          ];
          
          $this->view('storeKeepers/fetch_medicine'.$data['medicine_id'], $data);
        }
    }


    public function edit_medicaldevices_form($id){
      if (!isset($_SESSION['login'])) {
        redirect('users/login');
      }
      if($_SERVER['REQUEST_METHOD'] == 'POST'){
        // Sanitize POST array
        $_POST = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING);

        //need to add avatar
        $data = [
          'medicine_id'=>$id,
          'old_quantity' => trim($_POST['total_items_hidden']),
          'total_items' => trim($_POST['updated_quantity']),
          'medicine_radio' => trim($_POST['medicine_operation']),
          'price' => trim($_POST['updated_price']),
          'expiry_date' => trim($_POST['expiry_date']),
          'price_negative_err'=>'',
          'quantity_negative_err'=>'',
          'date_negative_err'=>''
        ];

        // Validate data
        if($data['price']<0){
          $data['price_negative_err'] = "* Please enter valid Price";
        }
        if($data['total_items']<0){
          $data['quantity_negative_err'] = "* Please enter valid Amount";
        }
        if(!empty($data['expiry_date']) && strtotime($data['expiry_date']) < strtotime(date('Y-m-d'))){
          $data['date_negative_err'] = "*Please enter valid expiry date";
        }
        if($data['medicine_radio']=='remove'){
            if($data['total_items']>$data['old_quantity']) {
                $data['quantity_negative_err'] = "* Please enter valid amount";
            }
        }

        // Make sure no errors
        if(empty($data['price_negative_err']) && empty($data['quantity_negative_err']) && empty($data['date_negative_err'])){
          // Validated
          $this->StorekeeperModel = $this->model('Storekeeper');
          $database_query = $this->StorekeeperModel->editmedicine($data);

          if($database_query){
            echo "<script>
                      Swal.fire({
                          title: 'medical device updated successfully!',
                          timer: 2000,
                          confirmButtonColor: '#3085d6',
                          backdrop: `
                              rgba(0,0,100,0.1)
                              url('/images/nyan-cat.gif')
                              left top
                              no-repeat
                            `
                      }).then(function() {
                        window.location.href = '" . URLROOT . "/Storekeepers/delete_md_firstaid';
                    });
                </script>";

            // redirect('storeKeepers/delete_md_firstaid');         
          } else {
            die('something went wrong');
          }
        } else {
          // Load view with errors
          $this->StorekeeperModel = $this->model('Storekeeper');
          $medicine = $this->StorekeeperModel->getMedicineByID($id);

          $data =[
            'medicine'=>$medicine,
            'price_negative_err'=>$data['price_negative_err'],
            'quantity_negative_err'=>$data['quantity_negative_err'],
            'date_negative_err'=>$data['date_negative_err']
          ];
          $this->view('storeKeepers/edit_medicaldevices_Detail', $data);
          // redirect('storeKeepers/fetch_medicine/'.$data['medicine_id']);        
        }

      } else {
        $data = [
          'medicine_id'=>$id,
          'medicine_radio'=>'',
          'total_items' =>'',
          'price'=>'',
          'expiry_date'=>'',
          'price_negative_err'=>'',
          'quantity_negative_err'=>'',
          'date_negative_err'=>''
        ];
        
        $this->view('storeKeepers/fetch_medicine'.$data['medicine_id'], $data);
      }
  }


  public function edit_personalcare_form($id){
    if (!isset($_SESSION['login'])) {
      redirect('users/login');
    }
    if($_SERVER['REQUEST_METHOD'] == 'POST'){
      // Sanitize POST array
      $_POST = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING);

      //need to add avatar
      $data = [
        'medicine_id'=>$id,
        'old_quantity' => trim($_POST['total_items_hidden']),
        'total_items' => trim($_POST['updated_quantity']),
        'medicine_radio' => trim($_POST['medicine_operation']),
        'price' => trim($_POST['updated_price']),
        'expiry_date' => trim($_POST['expiry_date']),
        'price_negative_err'=>'',
        'quantity_negative_err'=>'',
        'date_negative_err'=>''
      ];

      // Validate data
      if($data['price']<0){
        $data['price_negative_err'] = "* Please enter valid Price";
      }
      if($data['total_items']<0){
        $data['quantity_negative_err'] = "* Please enter valid Amount";
      }
      if(!empty($data['expiry_date']) && strtotime($data['expiry_date']) < strtotime(date('Y-m-d'))){
        $data['date_negative_err'] = "*Please enter valid expiry date";
      }
      if($data['medicine_radio']=='remove'){
          if($data['total_items']>$data['old_quantity']) {
              $data['quantity_negative_err'] = "* Please enter valid amount";
          }
      }

      // Make sure no errors
      if(empty($data['price_negative_err']) && empty($data['quantity_negative_err']) && empty($data['date_negative_err'])){
        // Validated
        $this->StorekeeperModel = $this->model('Storekeeper');
        $database_query = $this->StorekeeperModel->editmedicine($data);

        if($database_query){
          redirect('storeKeepers/delete_pc_nourishments');         
        } else {
          die('something went wrong');
        }
      } else {
        // Load view with errors
        $this->StorekeeperModel = $this->model('Storekeeper');
        $medicine = $this->StorekeeperModel->getMedicineByID($id);

        $data =[
          'medicine'=>$medicine,
          'price_negative_err'=>$data['price_negative_err'],
          'quantity_negative_err'=>$data['quantity_negative_err'],
          'date_negative_err'=>$data['date_negative_err']
        ];
        $this->view('storeKeepers/edit_personalcare_Detail', $data);
        // redirect('storeKeepers/fetch_medicine/'.$data['medicine_id']);        
      }

    } else {
      $data = [
        'medicine_id'=>$id,
        'medicine_radio'=>'',
        'total_items' =>'',
        'price'=>'',
        'expiry_date'=>'',
        'price_negative_err'=>'',
        'quantity_negative_err'=>'',
        'date_negative_err'=>''
      ];
      
      $this->view('storeKeepers/fetch_medicine'.$data['medicine_id'], $data);
    }
}






    public function delete_medicine($id){
          if (!isset($_SESSION['login'])) {
            redirect('users/login');
          }
          $this->StorekeeperModel = $this->model('Storekeeper');
          $medicine_type_one=$this->StorekeeperModel->get_medicine_type_one_by_id($id);
          
          $count=$this->StorekeeperModel->check_bought_status($id);

          $invoice_id=$this->StorekeeperModel->get_invoice_id_by_mid($id);

          $ids_string = implode(',', $invoice_id);
          
          // $order_id=$this->StorekeeperModel->get_order_id_by_invoice_id($invoice_id);
          // $orders_string = implode(',', $order_id);


          if($count>0){
              echo "<script>
                              Swal.fire({
                                  title: 'medicine cannot be deleted',
                                  text: 'medicine is already bought by customer, order is in progress (invoice id(s) -". $ids_string .")',
                                  timer: 2000,
                                  confirmButtonColor: '#3085d6',
                                  backdrop: `
                                      rgba(0,0,100,0.1)
                                      url('/images/nyan-cat.gif')
                                      left top
                                      no-repeat
                                    `
                              }).then(function() {
                                window.location.href = '" . URLROOT . "/Storekeepers/view_medicine_heart';
                            });
                  </script>";
          }
          else{
              $database_query = $this->StorekeeperModel->deletemedicine($id);

              // $medicine_type_two=$this->StorekeeperModel->get_medicine_type_two_by_id($id);

              if($database_query) {
                  if($medicine_type_one=="medicine") {
                      echo "<script>
                                      Swal.fire({
                                          title: 'medicine deleted successfully!',
                                          timer: 2000,
                                          confirmButtonColor: '#3085d6',
                                          backdrop: `
                                              rgba(0,0,100,0.1)
                                              url('/images/nyan-cat.gif')
                                              left top
                                              no-repeat
                                            `
                                      }).then(function() {
                                        window.location.href = '" . URLROOT . "/Storekeepers/view_medicine_heart';
                                    });
                          </script>";

                  // redirect("storeKeepers/view_medicine_heart");
                  } elseif($medicine_type_one=="medical devices") {
                      echo "<script>
                                      Swal.fire({
                                          title: 'medicine device deleted successfully!',
                                          timer: 2000,
                                          confirmButtonColor: '#3085d6',
                                          backdrop: `
                                              rgba(0,0,100,0.1)
                                              url('/images/nyan-cat.gif')
                                              left top
                                              no-repeat
                                            `
                                      }).then(function() {
                                        window.location.href = '" . URLROOT . "/Storekeepers/view_md_firstaid';
                                    });
                          </script>";

                  // redirect("storeKeepers/view_medicine_heart");
                  } elseif($medicine_type_one=="personal care") {
                      echo "<script>
                                      Swal.fire({
                                          title: 'personal care deleted successfully!',
                                          timer: 2000,
                                          confirmButtonColor: '#3085d6',
                                          backdrop: `
                                              rgba(0,0,100,0.1)
                                              url('/images/nyan-cat.gif')
                                              left top
                                              no-repeat
                                            `
                                      }).then(function() {
                                        window.location.href = '" . URLROOT . "/Storekeepers/view_pc_nourishments';
                                    });
                          </script>";

                      // redirect("storeKeepers/view_medicine_heart");
                  }
              }
          }
    }
    





      //search

      //medical devices
      public function search_md_firstaid(){
          if (!isset($_SESSION['login'])) {
            redirect('users/login');
          }
          if(isset($_POST["submit"])){
              $str=$_POST["search"];
              $this->StorekeeperModel = $this->model('Storekeeper');
              $medicine = $this->StorekeeperModel->search_firstaid($str);
              $data =$medicine;

              $this->view('storeKeepers/view_md_firstaid', $data);
          }
      }

      public function search_md_healthdevice(){
        if (!isset($_SESSION['login'])) {
          redirect('users/login');
        }
        if(isset($_POST["submit"])){
            $str=$_POST["search"];
            $this->StorekeeperModel = $this->model('Storekeeper');
            $medicine = $this->StorekeeperModel->search_healthdevices($str);
            $data =$medicine;

            $this->view('storeKeepers/view_md_healthdevice', $data);
        }
    }

    public function search_md_support(){
      if (!isset($_SESSION['login'])) {
        redirect('users/login');
      }
      if(isset($_POST["submit"])){
          $str=$_POST["search"];
          $this->StorekeeperModel = $this->model('Storekeeper');
          $medicine = $this->StorekeeperModel->search_supports($str);
          $data =$medicine;

          $this->view('storeKeepers/view_md_support', $data);
      }
   }



    //personal care
    public function search_pc_nourishments(){
      if (!isset($_SESSION['login'])) {
        redirect('users/login');
      }
      if(isset($_POST["submit"])){
          $str=$_POST["search"];
          $this->StorekeeperModel = $this->model('Storekeeper');
          $medicine = $this->StorekeeperModel->search_nourishments($str);
          $data =$medicine;

          $this->view('storeKeepers/view_pc_nourishments', $data);
      }
    }

    public function search_pc_accessories(){
      if (!isset($_SESSION['login'])) {
        redirect('users/login');
      }
      if(isset($_POST["submit"])){
          $str=$_POST["search"];
          $this->StorekeeperModel = $this->model('Storekeeper');
          $medicine = $this->StorekeeperModel->search_accessories($str);
          $data =$medicine;

          $this->view('storeKeepers/view_pc_accessories', $data);
      }
    }

    public function search_pc_skincare(){
      if (!isset($_SESSION['login'])) {
        redirect('users/login');
      }
      if(isset($_POST["submit"])){
          $str=$_POST["search"];
          $this->StorekeeperModel = $this->model('Storekeeper');
          $medicine = $this->StorekeeperModel->search_skincare($str);
          $data =$medicine;

          $this->view('storeKeepers/view_pc_skincare', $data);
      }
    }

    public function search_pc_womenpc(){
      if (!isset($_SESSION['login'])) {
        redirect('users/login');
      }
      if(isset($_POST["submit"])){
          $str=$_POST["search"];
          $this->StorekeeperModel = $this->model('Storekeeper');
          $medicine = $this->StorekeeperModel->search_womenpc($str);
          $data =$medicine;

          $this->view('storeKeepers/view_pc_womenpc', $data);
      }
    }

    public function search_pc_oralcare(){
      if (!isset($_SESSION['login'])) {
        redirect('users/login');
      }
      if(isset($_POST["submit"])){
        $str=$_POST["search"];
        $this->StorekeeperModel = $this->model('Storekeeper');
        $medicine = $this->StorekeeperModel->search_oralcare($str);
        $data =$medicine;

        $this->view('storeKeepers/view_pc_oralcare', $data);
      }
    }



    //medicine
    public function search_medicine_heart(){
      if (!isset($_SESSION['login'])) {
        redirect('users/login');
      }
      if(isset($_POST["submit"])){
          $str=$_POST["search"];
          $this->StorekeeperModel = $this->model('Storekeeper');
          $medicine = $this->StorekeeperModel->search_heart($str);
          $data =$medicine;

          $this->view('storeKeepers/view_medicine_heart', $data);
      }
    }

    public function search_medicine_diabetes(){
      if (!isset($_SESSION['login'])) {
        redirect('users/login');
      }
      if(isset($_POST["submit"])){
          $str=$_POST["search"];
          $this->StorekeeperModel = $this->model('Storekeeper');
          $medicine = $this->StorekeeperModel->search_diabetes($str);
          $data =$medicine;

          $this->view('storeKeepers/view_medicine_diabetes', $data);
      }
    }

    public function search_medicine_infection(){
      if (!isset($_SESSION['login'])) {
        redirect('users/login');
      }
      if(isset($_POST["submit"])){
          $str=$_POST["search"];
          $this->StorekeeperModel = $this->model('Storekeeper');
          $medicine = $this->StorekeeperModel->search_infection($str);
          $data =$medicine;

          $this->view('storeKeepers/view_medicine_infection', $data);
      }
    }

    public function search_medicine_gastro(){
      if (!isset($_SESSION['login'])) {
        redirect('users/login');
      }
      if(isset($_POST["submit"])){
          $str=$_POST["search"];
          $this->StorekeeperModel = $this->model('Storekeeper');
          $medicine = $this->StorekeeperModel->search_gastro($str);
          $data =$medicine;

          $this->view('storeKeepers/view_medicine_gastro', $data);
      }
    }

    public function search_medicine_muscle(){
      if (!isset($_SESSION['login'])) {
        redirect('users/login');
      }
      if(isset($_POST["submit"])){
        $str=$_POST["search"];
        $this->StorekeeperModel = $this->model('Storekeeper');
        $medicine = $this->StorekeeperModel->search_muscle($str);
        $data =$medicine;

        $this->view('storeKeepers/view_medicine_muscle', $data);
      }
    }




      //sort

      //medical devices
      public function sort_md_firstaid(){
        if (!isset($_SESSION['login'])) {
          redirect('users/login');
        }
        if(isset($_POST["submit"])){
            $str=$_POST["sort"];
            $this->StorekeeperModel = $this->model('Storekeeper');
            if($str=="alphabetical") {
                $medicine = $this->StorekeeperModel->sort_alphebetical_firstaid();
            }
            else if($str=="expiry_date"){
                $medicine = $this->StorekeeperModel->sort_expiry_firstaid();
            }
            else if($str=="quantity"){
                $medicine = $this->StorekeeperModel->sort_quantity_firstaid();
            }
            $data =$medicine;

            $this->view('storeKeepers/delete_md_firstaid', $data);
        }
      }


      public function sort_md_healthdevice(){
        if (!isset($_SESSION['login'])) {
          redirect('users/login');
        }
        if(isset($_POST["submit"])){
            $str=$_POST["sort"];
            $this->StorekeeperModel = $this->model('Storekeeper');
            if($str=="alphabetical") {
                $medicine = $this->StorekeeperModel->sort_alphebetical_healthdevice();
            }
            else if($str=="expiry_date"){
                $medicine = $this->StorekeeperModel->sort_expiry_healthdevice();
            }
            else if($str=="quantity"){
                $medicine = $this->StorekeeperModel->sort_quantity_healthdevice();
            }
            $data =$medicine;

            $this->view('storeKeepers/delete_md_healthdevice', $data);
        }
      }

  
      public function sort_md_supports(){
        if (!isset($_SESSION['login'])) {
          redirect('users/login');
        }
        if(isset($_POST["submit"])){
            $str=$_POST["sort"];
            $this->StorekeeperModel = $this->model('Storekeeper');
            if($str=="alphabetical") {
                $medicine = $this->StorekeeperModel->sort_alphebetical_supports();
            }
            else if($str=="expiry_date"){
                $medicine = $this->StorekeeperModel->sort_expiry_supports();
            }
            else if($str=="quantity"){
                $medicine = $this->StorekeeperModel->sort_quantity_supports();
            }
            $data =$medicine;

            $this->view('storeKeepers/delete_md_supports', $data);
        }
      }



      //personal care
      public function sort_pc_nourishments(){
        if (!isset($_SESSION['login'])) {
          redirect('users/login');
        }
        if(isset($_POST["submit"])){
            $str=$_POST["sort"];
            $this->StorekeeperModel = $this->model('Storekeeper');
            if($str=="alphabetical") {
                $medicine = $this->StorekeeperModel->sort_alphebetical_nourishments();
            }
            else if($str=="expiry_date"){
                $medicine = $this->StorekeeperModel->sort_expiry_nourishments();
            }
            else if($str=="quantity"){
                $medicine = $this->StorekeeperModel->sort_quantity_nourishments();
            }
            $data =$medicine;

            $this->view('storeKeepers/delete_pc_nourishments', $data);
        }
      }

      public function sort_pc_accessories(){
        if (!isset($_SESSION['login'])) {
          redirect('users/login');
        }
        if(isset($_POST["submit"])){
            $str=$_POST["sort"];
            $this->StorekeeperModel = $this->model('Storekeeper');
            if($str=="alphabetical") {
                $medicine = $this->StorekeeperModel->sort_alphebetical_accessories();
            }
            else if($str=="expiry_date"){
                $medicine = $this->StorekeeperModel->sort_expiry_accessories();
            }
            else if($str=="quantity"){
                $medicine = $this->StorekeeperModel->sort_quantity_accessories();
            }
            $data =$medicine;

            $this->view('storeKeepers/delete_pc_accessories', $data);
        }
      }

      public function sort_pc_skincare(){
        if (!isset($_SESSION['login'])) {
          redirect('users/login');
        }
        if(isset($_POST["submit"])){
            $str=$_POST["sort"];
            $this->StorekeeperModel = $this->model('Storekeeper');
            if($str=="alphabetical") {
                $medicine = $this->StorekeeperModel->sort_alphebetical_skincare();
            }
            else if($str=="expiry_date"){
                $medicine = $this->StorekeeperModel->sort_expiry_skincare();
            }
            else if($str=="quantity"){
                $medicine = $this->StorekeeperModel->sort_quantity_skincare();
            }
            $data =$medicine;

            $this->view('storeKeepers/delete_pc_skincare', $data);
        }
      }

      public function sort_pc_womenpc(){
        if (!isset($_SESSION['login'])) {
          redirect('users/login');
        }
        if(isset($_POST["submit"])){
            $str=$_POST["sort"];
            $this->StorekeeperModel = $this->model('Storekeeper');
            if($str=="alphabetical") {
                $medicine = $this->StorekeeperModel->sort_alphebetical_womenpc();
            }
            else if($str=="expiry_date"){
                $medicine = $this->StorekeeperModel->sort_expiry_womenpc();
            }
            else if($str=="quantity"){
                $medicine = $this->StorekeeperModel->sort_quantity_womenpc();
            }
            $data =$medicine;

            $this->view('storeKeepers/delete_pc_womenpc', $data);
        }
      }

      public function sort_pc_oralcare(){
        if (!isset($_SESSION['login'])) {
          redirect('users/login');
        }
        if(isset($_POST["submit"])){
            $str=$_POST["sort"];
            $this->StorekeeperModel = $this->model('Storekeeper');
            if($str=="alphabetical") {
                $medicine = $this->StorekeeperModel->sort_alphebetical_oralcare();
            }
            else if($str=="expiry_date"){
                $medicine = $this->StorekeeperModel->sort_expiry_oralcare();
            }
            else if($str=="quantity"){
                $medicine = $this->StorekeeperModel->sort_quantity_oralcare();
            }
            $data =$medicine;

            $this->view('storeKeepers/delete_pc_oralcare', $data);
        }
      }


      //personal care
      public function sort_medicine_heart(){
        if (!isset($_SESSION['login'])) {
          redirect('users/login');
        }
        if(isset($_POST["submit"])){
            $str=$_POST["sort"];
            $this->StorekeeperModel = $this->model('Storekeeper');
            if($str=="alphabetical") {
                $medicine = $this->StorekeeperModel->sort_alphebetical_heart();
            }
            else if($str=="expiry_date"){
                $medicine = $this->StorekeeperModel->sort_expiry_heart();
            }
            else if($str=="quantity"){
                $medicine = $this->StorekeeperModel->sort_quantity_heart();
            }
            $data =$medicine;

            $this->view('storeKeepers/delete_medicine_heart', $data);
        }
      }

      public function sort_medicine_diabetes(){
        if (!isset($_SESSION['login'])) {
          redirect('users/login');
        }
        if(isset($_POST["submit"])){
            $str=$_POST["sort"];
            $this->StorekeeperModel = $this->model('Storekeeper');
            if($str=="alphabetical") {
                $medicine = $this->StorekeeperModel->sort_alphebetical_diabetes();
            }
            else if($str=="expiry_date"){
                $medicine = $this->StorekeeperModel->sort_expiry_diabetes();
            }
            else if($str=="quantity"){
                $medicine = $this->StorekeeperModel->sort_quantity_diabetes();
            }
            $data =$medicine;

            $this->view('storeKeepers/delete_medicine_diabetes', $data);
        }
      }

      public function sort_medicine_infection(){
        if (!isset($_SESSION['login'])) {
          redirect('users/login');
        }
        if(isset($_POST["submit"])){
            $str=$_POST["sort"];
            $this->StorekeeperModel = $this->model('Storekeeper');
            if($str=="alphabetical") {
                $medicine = $this->StorekeeperModel->sort_alphebetical_infection();
            }
            else if($str=="expiry_date"){
                $medicine = $this->StorekeeperModel->sort_expiry_infection();
            }
            else if($str=="quantity"){
                $medicine = $this->StorekeeperModel->sort_quantity_infection();
            }
            $data =$medicine;

            $this->view('storeKeepers/delete_medicine_infection', $data);
        }
      }

      public function sort_medicine_gastro(){
        if (!isset($_SESSION['login'])) {
          redirect('users/login');
        }
        if(isset($_POST["submit"])){
            $str=$_POST["sort"];
            $this->StorekeeperModel = $this->model('Storekeeper');
            if($str=="alphabetical") {
                $medicine = $this->StorekeeperModel->sort_alphebetical_gastro();
            }
            else if($str=="expiry_date"){
                $medicine = $this->StorekeeperModel->sort_expiry_gastro();
            }
            else if($str=="quantity"){
                $medicine = $this->StorekeeperModel->sort_quantity_gastro();
            }
            $data =$medicine;

            $this->view('storeKeepers/delete_medicine_gastro', $data);
        }
      }

      public function sort_medicine_muscle(){
        if (!isset($_SESSION['login'])) {
          redirect('users/login');
        }
        if(isset($_POST["submit"])){
            $str=$_POST["sort"];
            $this->StorekeeperModel = $this->model('Storekeeper');
            if($str=="alphabetical") {
                $medicine = $this->StorekeeperModel->sort_alphebetical_muscle();
            }
            else if($str=="expiry_date"){
                $medicine = $this->StorekeeperModel->sort_expiry_muscle();
            }
            else if($str=="quantity"){
                $medicine = $this->StorekeeperModel->sort_quantity_muscle();
            }
            $data =$medicine;

            $this->view('storeKeepers/delete_medicine_muscle', $data);
        }
      }

      


      //account page
      public function account()
      {
        if (!isset($_SESSION['login'])) {
          redirect('users/login');
        }
          $this->StorekeeperModel = $this->model('StoreKeeper');
          $email = $_SESSION['email'];
          $userdetails = $this->StorekeeperModel->getuserdetails($email);
          $data =$userdetails;
          // print_r($data);die();
          $this->view('storeKeepers/account', $data);
      }

      public function change_pw()
      {
        if (!isset($_SESSION['login'])) {
          redirect('users/login');
        }
          $this->StorekeeperModel = $this->model('Storekeeper');
          $data ="";
          $this->view('storeKeepers/change_pw', $data);
      }

      public function update_pw()
      {
        if (!isset($_SESSION['login'])) {
          redirect('users/login');
        }
          $this->StorekeeperModel = $this->model('Storekeeper');
          $data ="";
          //print_r($_POST);die();
          $cur_pw = $_POST['cur_pw']; 
          $res = $this->StorekeeperModel->getuserdetails($_SESSION['email']);
          if (password_verify($cur_pw,$res[0]->password)) {
              if ($_POST['new_pw'] == $_POST['con_pw'] ) {
                  $hashed = password_hash($_POST['new_pw'], PASSWORD_DEFAULT);
                  $res = $this->StorekeeperModel->updatePassword($_SESSION['email'],$hashed);
                  if ($res) {
                      header('Location: ./account');
                  }
              }
              else {
                  $_SESSION['error2'] = "Passwords Not Match";
                  $this->view('storeKeepers/change_pw', $data);
                  exit();
              }
          }
          else {
              $_SESSION['error1'] = "Incorrect Password";
              $this->view('storeKeepers/change_pw', $data);
              exit();
          }
          // print_r($res[0]->password);die();
          // $data ="";
          // $this->view('pharmacist/change_pw', $data);
      }






      public function updateImg()
      {
        if (!isset($_SESSION['login'])) {
          redirect('users/login');
        }
                // print_r($_FILES);die();
                $this->StorekeeperModel = $this->model('Storekeeper');
                $data ='';
    
                $target_dir = "C:/xampp/htdocs/careU_project/public/img/user-pics/";
                $filename = basename($_FILES["fileToUpload"]["name"]);
                $target_file = $target_dir . $filename;
                
                $uploadOk = 1;
                $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
        
                
                // Check if image file is a actual image or fake image
                if (isset($_POST["submit"])) {
                    $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
                    if ($check !== false) {
                        echo "File is an image - " . $check["mime"] . ".";
                        $uploadOk = 1;
                    } else {
                        echo "File is not an image.";
                        $uploadOk = 0;
                    }
                }
        
                // Check if file already exists
                if (file_exists($target_file)) {
                    echo "Sorry, file already exists.";
                    $uploadOk = 0;
                }
        
                // Check file size
                if ($_FILES["fileToUpload"]["size"] > 500000) {
                    echo "Sorry, your file is too large.";
                    $uploadOk = 0;
                }
        
                // Allow certain file formats
                if (
                    $imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif"
                ) {
                    echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
                    $uploadOk = 0;
                }
        
                // Check if $uploadOk is set to 0 by an error
                if ($uploadOk == 0) {
                    echo "Sorry, your file was not uploaded.";
                    // if everything is ok, try to upload file
                } else {
                    if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
                        echo "The file " . htmlspecialchars(basename($_FILES["fileToUpload"]["name"])) . " has been uploaded.";
                    } else {
                        echo "Sorry, there was an error uploading your file.";
                    }
                }
        
                $result = $this->StorekeeperModel->updateProfilePic($filename,$_SESSION['email']);
                if ($result) {
                    $_SESSION['profile'] = $filename;
                    redirect('StoreKeepers/account');
                }
        
      
      }











      public function low_stock_reminder(){
        if (!isset($_SESSION['login'])) {
          redirect('users/login');
        }
        $this->StorekeeperModel = $this->model('StoreKeeper');
        $count_lowstock = $this->StorekeeperModel->get_count_low_stock();
        $emails = $this->StorekeeperModel->get_all_storekeeper_emails();
        $ids = $this->StorekeeperModel->get_ids_low_stock();
  
        PHP_mailer_zero_medicine($count_lowstock,$emails,$ids);
  
        echo "<script>
                Swal.fire({
                    title: 'Low stock Reminder e-mail sent successfully!',
                    text: 'Low stock reminder e-mail has been sent to storekeepers.',
                    timer: 2000,
                    confirmButtonColor: '#3085d6',
                    confirmButtonText: 'OK',
                    backdrop: false
                }).then(function() {
                  window.location.href = '" . URLROOT . "/Storekeepers/dashboard';
              });
            </script>";

        // redirect("Storekeepers/dashboard");

        // $heartmeds = $this->managerModel-> getHeartMeds();
        // $data =$heartmeds;
        // $this->view('storeKeepers/view_medicine_heart', $data);
      }



  
  
      public function expired_medicine_reminder(){
        if (!isset($_SESSION['login'])) {
          redirect('users/login');
        }
        $this->StorekeeperModel = $this->model('StoreKeeper');
        $count_expired = $this->StorekeeperModel->get_count_expired();
        $emails = $this->StorekeeperModel->get_all_storekeeper_emails();
        $ids = $this->StorekeeperModel->get_ids_expired();
  
        PHP_mailer_expired_medicine($count_expired,$emails,$ids);
  
        echo "<script>
                Swal.fire({
                    title: 'Expired stock Reminder e-mail sent successfully!',
                    text: 'Expired stock reminder e-mail has been sent to storekeepers.',
                    timer: 2000,
                    confirmButtonColor: '#3085d6',
                    confirmButtonText: 'OK',
                    backdrop: false
                }).then(function() {
                  window.location.href = '" . URLROOT . "/Storekeepers/dashboard';
              });
            </script>";

        // redirect("Storekeepers/dashboard");

        // $heartmeds = $this->managerModel-> getHeartMeds();
        // $data =$heartmeds;
        // $this->view('storeKeepers/view_medicine_heart', $data);
      }








      // public function createUserSession($user){
      //     $_SESSION['user_id']=$user->ID;
      //     $_SESSION['user_email']=$user->email;
      //     $_SESSION['user_name']=$user->first_name;
          
      //     redirect('storeKeepers/dashboard');                //it will redirect to index method in pages controller
      // }
    
      // public function logout(){
      //     unset($_SESSION['user_id']);
      //     unset($_SESSION['user_email']);
      //     unset($_SESSION['user_name']);
      //     session_destroy();
      //     redirect('users/login');
      // }
        
    } 