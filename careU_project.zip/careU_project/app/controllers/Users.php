<?php 

  // dependencies for phpmailer
  use PHPMailer\PHPMailer\PHPMailer;

    class Users extends Controller{

        //Create varibale to connect to DB
        private $userModel;

        //Assigned 'User' model file
        public function __construct()
        {
            $this->userModel = $this->model('User');
            $this->PharmacistModel = $this->model('Pharmacist');
        }


        //User's login authentication
        public function login(){

          if($_SERVER['REQUEST_METHOD'] == 'POST'){            

              //Fetch data from request form
              $data = [
                  'email' => trim($_POST['email']),
                  'password' => trim($_POST['password']),
                  
                  'email_err' => '',
                  'password_err' => ''

              ];

              //Validate email and password
              if(empty($data['email'])){
                  $data['email_err'] =  " *please enter email";
              }
              else{
                  //Check user/email
                  if($this->userModel->findUserByEmailLogin($data['email'])){
                  //User found

                  }
                  else{
                      $data['email_err'] = " *User not found";
                  }
              }

              //Valid Password
              if(empty($data['password'])){
                  $data['password_err'] = " *please enter password";
              }
              

              // IF ERRORS FREE, THEN ACCORDING TO USER ROLE NEED TO CREATE SEASSION AND LAND IN TO HIS/HER OWNS PAGE
              if(empty($data['email_err']) && empty($data['password_err'])){

                  //Authentication user's email & password
                  $loggedInUser = $this->userModel->login($data['email'], $data['password']);

                  if($loggedInUser){
                      $this->createUserSession($loggedInUser);
                  }
                  else{
                      $data['password_err'] = " *incorrect password";
                      $this->view('users/login', $data);
                  }
              }
              else{
                  $this->view('users/login', $data);
              }

          }
          else{

              //If request is not POST then this scope will be execute

              $data = [

                  'email' => '',
                  'password' => '',

                  'email_err' => '',
                  'password_err' => ''

              ];
              $this->view('users/login', $data);
          }

      }

      public function UserAddEmail($userfName,$userlName,$userEmail){

        $mail = new PHPMailer(true);
      
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = 'true';
        $mail->Username = 'careu.meds@gmail.com';
        $mail->Password = 'rqoisanoxkfcgbjz';
        $mail->SMTPSecure = 'ssl';
        $mail->Port = 465;
      
        $mail->setFrom('careu.meds@gmail.com');
        $mail->addAddress($userEmail);
      
        $mail->isHTML(true);
      
        $mail->Subject = 'Welcome to careU Pharmacy.';
        $mail->Body = '            
                <html>
                <head>
                <title>Welcome to careU Pharmacy!</title>
                <style>
                    body {
                    font-family: Arial, sans-serif;
                    font-size: 14px;
                    }
                    h1 {
                    font-size: 18px;
                    color: #444;
                    margin-bottom: 20px;
                    }
                    ul {
                    list-style-type: none;
                    padding: 0;
                    margin: 0;
                    }
                    li {
                    margin-bottom: 10px;
                    }
                </style>
                </head>
                <body>
                <p>Hey ' . $userfName . '' ." ". '' . $userlName . ',</p>
                <p>Greetings!</p>
                <p>We are pleased to inform you that your acount has been created successfully.</p>
                <p>Your account has been activated and you can access to our platform by logging in with the following credentials:</p>
                <ul>
                  <li><b>Email:</b> ' . $userEmail . '</li>
                  <li><b>Password:</b> <i>Password you set when creating account</i></li>
                </ul>
                
                <p>If you have any questions or need assistance, please don\'t hesitate to contact us.</p>
                <p>Best regards,<br><br>
                careU Pharmacy</p>
              </body>
              </html>
              '
              ;

              $mail->send();
       
      
      }



        private function generateUserID($lastUserID)
        {    

            if($lastUserID == " ")
             {
                 $user_ID = "C00001";
             }
             else
             {
                 $user_ID = substr($lastUserID, 5);
                 $user_ID = intval($user_ID);
                 $user_ID = "C0000" . ($user_ID+1);

             }
          
           
    
            return $user_ID;
        }

     


        public function register(){

            // Check for POST
            if($_SERVER['REQUEST_METHOD'] == 'POST'){
              // Process form
        
              // Sanitize POST data
              $_POST = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING);

              // Get the latest user ID
              $lastUserID = $this->model('User')->getLastUserID();

              // Generate the new user ID
              $user_ID = $this->generateUserID($lastUserID);

              // Save the new user to the database
              //$this->model('User')->register($user_ID);
      
              // Init data
              $data =[
                'user_ID' => $user_ID,
                'fName' => trim($_POST['fName']),
                'lName' => trim($_POST['lName']),
                'birthDate' => trim($_POST['birthDate']),
                'mobile' => trim($_POST['mobile']),
                'email' => trim($_POST['email']),
                'address' => trim($_POST['address']),
                'city' => trim($_POST['city']),
                'password' => trim($_POST['password']),
                'confirm_password' => trim($_POST['confirm_password']),
                'user_role' => 'customer',
                'joinedDate' => date('Y-m-d H:i:s'),
                'active_status' => 'Active',
      
                'fName_err' => '',
                'lName_err' => '',
                'birthDate_err' => '',
                'mobile_err' => '',
                'email_err' => '',
                'address_err' => '',
                'city_err' => '',
                'password_err' => '',
                'confirm_password_err' => ''
              ];
      
              // Validate Email
              if(empty($data['email'])){
                $data['email_err'] = 'Please enter email';
              } else {
                // Check email
                if($this->userModel->findUserByEmail($data['email'])){
                  $data['email_err'] = 'Email is already taken';
                }
              }
      
              if(empty($data['mobile'])){
                $data['mobile_err'] = 'Please enter your mobile number';
              } 
              elseif(strlen($data['mobile']) !== 10){
                $data['mobile_err'] = 'Please enter a valid mobile number';
              } 
              
              else {
                  // Check mobile
                  if($this->userModel->findUserByMobile($data['mobile'])){
                    $data['mobile_err'] = 'This mobile number is already taken';
                  }
              } 

              


      
              // Validate Name
              if(empty($data['fName'])){
                $data['fName_err'] = 'Please enter first name';
              }
      
              if(empty($data['lName'])){
                  $data['lName_err'] = 'Please enter last name';
              }
              
              //Birthday Validation
              if(empty($data['birthDate'])){
                $data['birthDate_err'] = 'Please enter your birth date';
              } 
              else {
                // Convert the birth date to a DateTime object
                $birthDate = new DateTime($data['birthDate']);
            
                // Get the current date
                $currentDate = new DateTime();
            
                // Calculate the difference between the current date and the birth date
                $age = $currentDate->diff($birthDate)->y;
            
                // Check if the age is less than 13
                if($age < 13){
                    $data['birthDate_err'] = 'You must be at least 13 years old to register';
                }
              }
            
      
              if(empty($data['address'])){
                  $data['address_err'] = 'Please enter address';
              }
      
              if(empty($data['city'])){
                  $data['city_err'] = 'Please enter city';
              }
      
               // Validate Password
               if(empty($data['password'])){
                $data['password_err'] = 'Please enter a password';
                } elseif(strlen($data['password']) < 8){
                    $data['password_err'] = 'Password must be at least 8 characters';
                } elseif(!preg_match('/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z\d]+$/', $data['password'])){
                    $data['password_err'] = 'Password should only contain: <br>-At least one lowercase letter <br>-At least one uppercase letter <br>-At least one number';
                }
        
                // Validate Confirm Password
                if(empty($data['confirm_password'])){
                  $data['confirm_password_err'] = 'Please enter confirm password';
                } else {
                  if($data['password'] != $data['confirm_password']){
                    $data['confirm_password_err'] = 'Passwords do not match';
                  }
                }
      
              // Make sure errors are empty
              if(empty($data['email_err']) &&
                 empty($data['mobile_err']) && 
                 empty($data['fname_err']) && 
                 empty($data['lname_err']) &&
                 empty($data['birthDate_err']) &&
                 empty($data['address_err']) &&
                 empty($data['city_err']) &&
                 empty($data['password_err']) && empty($data['confirm_password_err'])){
                // Validated
                
                // Hash Password
                $data['password'] = password_hash($data['password'], PASSWORD_DEFAULT);
      
                // Register User
                if($this->userModel->register($data)){
                  //flash('register_success', 'You are registered and can log in');
                  $this->UserAddEmail($data['fName'],$data['lName'],$data['email']);
                  $flashMessage = 'Your account created Successfully!';
                  
                  redirect('users/login?flashMessage=' . urlencode($flashMessage));
                } else {
                  die('Something went wrong');
                }
              } else {
                // Load view with errors
                $this->view('users/register', $data);
              }
      
            } else {
              // Init data
              $data =[
                'user_ID'=>'',
                'fName' => '',
                'lName' => '',
                'birthDate' => '',
                'mobile' => '',
                'email' => '',
                'address' => '',
                'city' => '',
                'password' => '',
                'confirm_password' => '',
                'user_role' => '',
                'joinedDate' => '',
                'active_status' => '',
      
                'fName_err' => '',
                'lName_err' => '',
                'birthDate_err' => '',
                'mobile_err' => '',
                'email_err' => '',
                'address_err' => '',
                'city_err' => '',
                'password_err' => '',
                'confirm_password_err' => ''
              ];
      
              // Load view
              $this->view('users/register', $data);

              
            }
          }


          //Create Session
          public function createUserSession($user){
           
            //Store session data
            $_SESSION['user_ID'] = $user->user_ID;
            $_SESSION['profile'] = $user->user_img;

            $_SESSION['user_email'] = $user->email;
            $_SESSION['email'] = $user->email;

            $_SESSION['user_address'] = $user->address;
            $_SESSION['user_city'] = $user->city;

            $_SESSION['user_fName'] = $user->fName;
            $_SESSION['user_lName'] = $user->lName;
            $_SESSION['user_bDay'] = $user->birthDate;
            $_SESSION['user_mobile'] = $user->mobile;
            $_SESSION['user_role'] = $user->user_role;
            $_SESSION['user_status'] = $user->active_status;
            $_SESSION['registered_date'] = $user->joinedDate;
            $_SESSION['password_changed'] = false;
            // $_SESSION['reset_email'] = $user->email;
            $_SESSION['login']=1;
  
            if($_SESSION['user_role'] == "customer"){
              //header("Location: ".URLROOT."/HomePage");
              redirect('customers/home');
            }
            elseif($_SESSION['user_role'] == "admin"){
              //header("Location: ".URLROOT."/admin_dashboard");
              redirect('admins/admin_dashboard');
            }
            elseif($_SESSION['user_role'] == "pharmacist"){
              //header("Location: ".URLROOT."/admin_dashboard");
              redirect('pharmacists/dashboard');
            }
            elseif($_SESSION['user_role'] == "manager"){
              //header("Location: ".URLROOT."/admin_dashboard");
              redirect('managers/dashboard');
            }
            elseif($_SESSION['user_role'] == "storekeeper"){
              //header("Location: ".URLROOT."/admin_dashboard");
              redirect('storekeepers/dashboard');
            }
            elseif($_SESSION['user_role'] == "deliveryperson"){
              //header("Location: ".URLROOT."/admin_dashboard");
              redirect('deliveryPersons/deliveryPersons_dashboard');
            }

          }


          public function home_page(){
            $heartmeds = $this->userModel-> getMeds();
            $data =$heartmeds;
            $this->userModel = $this->model('User');
            $this->view('users/home_page',$data);
          }

          public function reset_password()
          {
              if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                  // Fetch data from request form
                  $data = [
                      'email' => trim($_POST['email']),
                      'email_err' => ''
                  ];

                  // Validate email
                  if (empty($data['email'])) {
                      $data['email_err'] = "* Please enter email";
                  } else {
                      // Check if user/email exists
                      
                      if ($this->userModel->findUserByEmail($data['email'])) {
                          // User found, send the password reset email
                          if ($this->userModel->sendPasswordResetEmail($data['email'])) {
                            
                            redirect('users/login?success=password-reset');
                            if (isset($_GET['success']) && $_GET['success'] === 'password-reset') {
                              echo '
                              <script>
                                  Swal.fire({
                                      position: "top-end",
                                      icon: "success",
                                      title: "Your work has been saved",
                                      showConfirmButton: false,
                                      timer: 1500
                                  });
                              </script>';
                            }
                          } else {
                              // Failed to send the email
                              // You can set an error message here and display it to the user
                              $data['email_err'] = "*Failed to send the email. Retry!";
                          }
                      } else {
                          $data['email_err'] = "*User not found";
                      }
                  }

                  $this->view('users/reset_password', $data);
              } else {
                  // If the request is not POST, load the view
                  $data = [
                      'email' => '',
                      'email_err' => ''
                  ];

                  $this->view('users/reset_password', $data);
              }
          }


          public function recover_password()
          {
              if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                  // Process the password reset form
          
                  // Fetch and sanitize form data
                  $data = [
                      'password' => trim($_POST['password']),
                      'confirm_password' => trim($_POST['confirm_password']),
                      'password_err' => '',
                      'confirm_password_err' => ''
                  ];
          
                  // Validate password
                  if (empty($data['password'])) {
                      $data['password_err'] = 'Please enter a new password.';
                  } elseif (strlen($data['password']) < 8) {
                      $data['password_err'] = 'Password must be at least 8 characters long.';
                  } elseif (!preg_match('/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z\d]+$/', $data['password'])) {
                      $data['password_err'] = 'Password should contain: <br>-At least one lowercase letter <br>-At least one uppercase letter <br>-At least one number';
                  }
          
                  // Validate confirm password
                  if (empty($data['confirm_password'])) {
                      $data['confirm_password_err'] = 'Please confirm the new password.';
                  } elseif ($data['password'] !== $data['confirm_password']) {
                      $data['confirm_password_err'] = 'Passwords do not match.';
                  }
          
                  // If there are no errors, update the user's password
                  if (empty($data['password_err']) && empty($data['confirm_password_err'])) {
                      // Get the email from the token or session (whichever method you're using)
                      $email = $_SESSION['reset_email'];
          
                      // Update the password in the database
                      $hashed_password = password_hash($data['password'], PASSWORD_DEFAULT);
                      $this->userModel->updatePasswordByEmail($email, $hashed_password);
          
                      // Redirect to the login page or any other appropriate page after successful password reset
                      redirect('users/login');
                  } else {
                      // There are validation errors, so reload the view with error messages
                      $this->view('users/recover_password', $data);
                  }
              } else {
                  // Display the password reset form
                  $data = [
                      'password' => '',
                      'confirm_password' => '',
                      'password_err' => '',
                      'confirm_password_err' => ''
                  ];
          
                  $this->view('users/recover_password', $data);
              }
          }
          




          public function logout(){
           // Destroy user details
           session_unset();
           session_destroy();
           session_regenerate_id(true);
       
           // Clear browser history
           echo '<script>';
           echo 'if (window.history.replaceState) {';
           echo '   window.history.replaceState(null, null, window.location.href);';
           echo '}';
           echo '</script>';
       
           // Redirect to the login page
           redirect('users/login');
        }


        
    }