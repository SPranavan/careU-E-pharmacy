<?php
// dependencies for phpmailer
use PHPMailer\PHPMailer\PHPMailer;

    class deliverypersons extends Controller{

        private $deliverypersonModel;

    

    public function __construct(){

        $this->deliverypersonModel = $this->model('deliveryperson');
    }

    public function index(){
      
      if (!isset($_SESSION['login'])) {
        redirect('/users/login');
      }
        $this->deliverypersonModel = $this->model('DeliveryPerson');

        $countPendingOrders = $this->deliverypersonModel->getCount_pendingOrders();
        $countInprogressOrders = $this->deliverypersonModel->getCount_acceptedOrders();
        $countDeliveredOrders = $this->deliverypersonModel->getCount_completedOrders();

        $getDeliveredOrdersDetails = $this->deliverypersonModel->getDeliveredOrdersDetails();

        $deliveryStatusCounts = $this->deliverypersonModel->getDeliveryStatusCounts();

       


        $data =[
            'countPendingOrders' => $countPendingOrders,
            'countInprogressOrders' => $countInprogressOrders,
            'countDeliveredOrders' => $countDeliveredOrders,
            'getDeliveredOrdersDetails' => $getDeliveredOrdersDetails,
            'deliveryStatusCounts' => $deliveryStatusCounts

        ];


        $this->view('deliveryPersons/deliveryPersons_dashboard', $data);
    }


    public function locate(){

        if($_SERVER['REQUEST_METHOD'] == 'POST'){

          if(isset($_POST['orderId'])){
              $orderId = (trim($_POST['orderId']));
            } else {
              $orderId = '';
            }
            
            if(isset($_POST['customerID'])){
              $customerID = trim($_POST['customerID']);
            } else {
              $customerID = '';
            }

            if(isset($_POST['deliveryID'])){
              $deliveryID = trim($_POST['deliveryID']);
            } else {
              $deliveryID = '';
            }

            $data = [
              'orderId' => $orderId,
              'customerID' => $customerID,
              'deliveryID' => $deliveryID,
              'user_details' => '',
              'order_details' => '',
              'delivery_details' => ''
            ];

            

            $data['user_details'] = $this->deliverypersonModel->getCustomerDetails($data['customerID']);
            $data['order_details'] = $this->deliverypersonModel->getOrderDetails($data['orderId']);
            $data['delivery_details'] = $this->deliverypersonModel->getDeliveryDetails($data['deliveryID']);

            $data = [
              'user_details' => $data['user_details'],
              'order_details' => $data['order_details'],
              'delivery_details' => $data['delivery_details']
            ];

          

            $this->view('deliveryPersons/locate', $data);
            

      }
      else{
          die("Something went wrong, please try again!");
      }
    }



    public function pending_orders(){

        // $this->deliverypersonModel = $this->model('DeliveryPerson');
        // $data ="";
        // $this->view('deliveryPersons/pending_orders', $data);

        $PendingOrdersDetails = $this->deliverypersonModel->getPendingOrders();
        $PendingOrdersPresDetails = $this->deliverypersonModel->getPendingPrescriptionOrders();

        $data = [
            'PendingOrdersDetails' => $PendingOrdersDetails,
            'PendingOrdersPresDetails' => $PendingOrdersPresDetails
        ];

        $this->view('deliveryPersons/pending_orders', $data);
    }

    public function inprogress_orders(){

        $user_ID = $_SESSION['user_ID'];

        $InprogressOrdersDetails = $this->deliverypersonModel->getInprogressOrders($user_ID);

        $data = [
            'InprogressOrdersDetails' => $InprogressOrdersDetails
        ];

        $this->view('deliveryPersons/inprogress_orders', $data);
    }

    public function delivered_orders(){
            $user_ID = $_SESSION['user_ID'];      

            $DeliveredOrdersDetails = $this->deliverypersonModel->getDeliveredOrders($user_ID);
    
            $data = [
                'DeliveredOrdersDetails' => $DeliveredOrdersDetails
            ];
    
            $this->view('deliveryPersons/delivered_orders', $data);

    }

    public function accept_pendingOrder(){

        if($_SERVER['REQUEST_METHOD'] == 'POST'){

            if(isset($_POST['orderID'])){
                $orderID = (trim($_POST['orderID']));
              } else {
                $orderID = '';
              }
              
              if(isset($_POST['customerID'])){
                $customerID = trim($_POST['customerID']);
              } else {
                $customerID = '';
              }

              if(isset($_POST['prescriptionID'])){
                $prescriptionID = trim($_POST['prescriptionID']);
              } else {
                $prescriptionID = '';
              }

              if(isset($_POST['invoiceID'])){
                $invoiceID = trim($_POST['invoiceID']);
              } else {
                $invoiceID = '';
              }

              if(isset($_POST['date'])){
                $date = trim($_POST['date']);
              } else {
                $date = '';
              }


            
           

            
          
            if($orderID != NULL){
              $data1 = [
                'orderID' => $orderID,
                'customerID' => $customerID,
                'availability_status' => 'in progress',
                'acceptDate' => date("Y-m-d H:i:s"),
                'invoiceID' => $invoiceID,
                'date' => $date,
                
                
            ];
              if($this->deliverypersonModel->accept_pendingOrder($data1)){
                header("Location: ".URLROOT."/deliverypersons/pending_orders");
              }else{
                die("Something went wrong, please try again!");
              }
            }

            elseif($prescriptionID != NULL){
              $data2 = [
                'prescriptionID' => $prescriptionID,
                'customerID' => $customerID,
                'availability_status' => 'in progress',
                'acceptDate' => date("Y-m-d H:i:s"),
                'invoiceID' => $invoiceID,
                'date' => $date,
                
                
            ];
                if($this->deliverypersonModel->accept_pendingPrescriptionOrder($data2)){
                  header("Location: ".URLROOT."/deliverypersons/pending_orders");
                }else{
                  die("Something went wrong, please try again!");
              }
            }
            else{
                die("Something went wrong, please try again!");
            }
            
    
        }else{
            $data = [
                'orderID' => '',
                'customerID' => '',
                'prescriptionID' => '',
                'invoiceID' => '',
                'date' => ''
            ];
        }
        $this->view('deliverypersons/accept_pendingOrder', $data);
    }



    public function inprogress_view(){

        if($_SERVER['REQUEST_METHOD'] == 'POST'){

            if(isset($_POST['orderId'])){
                $orderId = (trim($_POST['orderId']));
              } else {
                $orderId = '';
              }
              
              if(isset($_POST['customerID'])){
                $customerID = trim($_POST['customerID']);
              } else {
                $customerID = '';
              }

              if(isset($_POST['deliveryID'])){
                $deliveryID = trim($_POST['deliveryID']);
              } else {
                $deliveryID = '';
              }

              $data = [
                'orderId' => $orderId,
                'customerID' => $customerID,
                'deliveryID' => $deliveryID,
                'user_details' => '',
                'order_details' => '',
                'delivery_details' => ''
              ];

              

              $data['user_details'] = $this->deliverypersonModel->getCustomerDetails($data['customerID']);
              $data['order_details'] = $this->deliverypersonModel->getOrderDetails($data['orderId']);
              $data['delivery_details'] = $this->deliverypersonModel->getDeliveryDetails($data['deliveryID']);

              $data = [
                'user_details' => $data['user_details'],
                'order_details' => $data['order_details'],
                'delivery_details' => $data['delivery_details']
              ];

              $this->view('deliveryPersons/inprogress_view', $data);
              

        }
        else{
            die("Something went wrong, please try again!");
        }
    
    }


    public function inprogress_action()
    {
      
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {

          if(isset($_POST['deliveryID'])){
            $deliveryID = (trim($_POST['deliveryID']));
          } else {
            $deliveryID = '';
          }
          
          if(isset($_POST['popupTextarea'])){
            $review = trim($_POST['popupTextarea']);
          } else {
            $review = '';
          }


            $data = [
                'deliveryID' => $deliveryID,
                'review' => $review,
                
            ];

          
            
    
           
            if ($review != NULL) {
              $rejectData = [
                  'deliveryID' => $data['deliveryID'],
                  'availability_status' => 'rejected',
                  'rejectedDate' => date("Y-m-d H:i:s"),
                  'review' => $data['review']
              ];
             
  
              if ($this->deliverypersonModel->inprogress_reject($rejectData)) {
                  header("Location: " . URLROOT . "/deliveryPersons/inprogress_orders");
                  exit;
              } else {
                  die("Something went wrong during reject. Please try again!");
              }

            
          }elseif ($review == NULL) {
                $confirmData = [
                    'deliveryID' => $data['deliveryID'],
                    'availability_status' => 'delivered',
                    'deliveredDate' => date("Y-m-d H:i:s"),
                    'review' => 'Successful Delivery'
                ];
                
               
                
                if ($this->deliverypersonModel->inprogress_confirm($confirmData)) {
                    header("Location: " . URLROOT . "/deliveryPersons/inprogress_orders");
                    exit;
                } else {
                    die("Something went wrong during confirm. Please try again!");
                }
            } 
        } else {
            die("Invalid request method. Please try again!");
        }
    }
    



    public function delivered_view(){

      if($_SERVER['REQUEST_METHOD'] == 'POST'){

          if(isset($_POST['orderId'])){
              $orderId = (trim($_POST['orderId']));
            } else {
              $orderId = '';
            }
            
            if(isset($_POST['customerID'])){
              $customerID = trim($_POST['customerID']);
            } else {
              $customerID = '';
            }

            if(isset($_POST['deliveryID'])){
              $deliveryID = trim($_POST['deliveryID']);
            } else {
              $deliveryID = '';
            }

            $data = [
              'orderId' => $orderId,
              'customerID' => $customerID,
              'deliveryID' => $deliveryID,
              'user_details' => '',
              'order_details' => '',
              'delivery_details' => ''
            ];

            

            $data['user_details'] = $this->deliverypersonModel->getCustomerDetails($data['customerID']);
            $data['order_details'] = $this->deliverypersonModel->getOrderDetails($data['orderId']);
            $data['delivery_details'] = $this->deliverypersonModel->getDeliveryDetails($data['deliveryID']);

            $data = [
              'user_details' => $data['user_details'],
              'order_details' => $data['order_details'],
              'delivery_details' => $data['delivery_details']
            ];

           

            $this->view('deliveryPersons/delivered_view', $data);
            

      }
      else{
          die("Something went wrong, please try again!");
      }
  
  }

  public function search_pendingOrders(){

    $result = $this->deliverypersonModel->search_pendingOrders($_POST['search']);

    $output = '';

    if($result>0){
      foreach($result as $row){
        $output .= '<tr class="dataset1">
                      <td>' .$row->orderId. '</td>
                      <td>' .$row->invoiceID. '</td>
                      <td>' .$row->customerID. '</td>
                      <td>' ." ". '</td>
                      <td>' .$row->address." ".$row->city. '</td>
                      
                      <td class="vm">
                          <form action="'.URLROOT.'/deliveryPersons/accept_pendingOrder" method="POST">
                              <input type="hidden" name="orderId" value="' .$row->orderId.'">
                              <input type="hidden" name="customerID" value="' .$row->customerID.'">
                              <button class="viewMore" type="submit">Accept</button>
                          </form>
                      </td>
                  </tr>
                  ';
      }
    }

    else{
      $output .= '
            <tr><td colspan="5">No results found</td></tr>';
    }

    echo $output;
  }


  public function my_account(){
          

    $this->view('deliveryPersons/my_account');
  }

  public function change_password(){

    $this->deliverypersonModel = $this->model('DeliveryPerson');
    $data ="";

    $this->view('DeliveryPersons/change_password', $data);

  }


  public function change_password_action()
{
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $data = [
            'currentPassword' => trim($_POST['cur_pw']),
            'newPassword' => trim($_POST['new_pw']),
            'confirmPassword' => trim($_POST['con_pw']),
            'cur_pw_err' => '',
            'con_pw_err' => '',
        ];

        $user_ID = $_SESSION['user_ID'];

        $UserDetails = $this->deliverypersonModel->findUserByUserID($user_ID);

        if ($UserDetails) {
            $userHashedValue = $UserDetails->password;
            if (password_verify(strval($data['currentPassword']), strval($userHashedValue))) {
                // Current password is validated
            } else {
                $data['cur_pw_err'] = "*Invalid password";
            }
        } else {
            die("Something went wrong!!!");
        }

        if (strval($data["newPassword"]) != strval($data["confirmPassword"])) {
          $data["con_pw_err"] = "*Passwords do not match";
        } 
        elseif (strlen($data['newPassword']) < 8) {
          $data['con_pw_err'] = 'Password must be at least 8 characters';
        }
        elseif (!preg_match('/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z\d]+$/', $data['newPassword'])) {
          $data["con_pw_err"] = "*Password should only contain at least one lowercase letter, one uppercase letter, and one number";
        }
        

        // Check if there are no errors
        if (empty($data['cur_pw_err']) && empty($data['con_pw_err'])) {
            // Allow changing the password
            if ($this->deliverypersonModel->change_password($data)) {
                if ($_SESSION['password_changed'] == false) {
                    $_SESSION['password_changed'] = true;

                    $this->view('admins/change_password');

                    // Send email to the user
                    $userName = $_SESSION['user_fName'];
                    $userEmail = $_SESSION['user_email'];

                    $this->PasswordChangedEmail($userName, $userEmail);

                    echo "<script>
                        Swal.fire({
                            position: 'center',
                            icon: 'success',
                            title: 'Password changed successfully!',
                            showConfirmButton: false,
                            timer: 2000,
                            customClass: {
                                container: 'custom-swal-container',
                                title: 'custom-swal-title',
                            }
                        });
                    </script>";
                } else {
                    redirect('users/login');
                }
            } else {
                die();
            }
        } else {
            // Load the view with errors
            $this->view('DeliveryPersons/change_password', $data);
        }
    } else {
        // If the request is not a POST request, then load the form
        $data = [
            'fName' => '',
            'lName' => '',
            'email' => '',
        ];

        // Load the view
        $this->view('DeliveryPersons/change_password', $data);
    }
}

  public function PasswordChangedEmail($userName, $userEmail){

    $mail = new PHPMailer(true);
  
    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com';
    $mail->SMTPAuth = 'true';
    $mail->Username = 'careu.meds@gmail.com';
    $mail->Password = 'rqoisanoxkfcgbjz
    ';
    $mail->SMTPSecure = 'ssl';
    $mail->Port = 465;
  
    $mail->setFrom('careu.meds@gmail.com');
    $mail->addAddress($userEmail);
  
    $mail->isHTML(true);
  
    $mail->Subject = 'Security Alert';
    $mail->Body = '            
            <html>
            <head>
            <title>Your password was changed '. SITENAME .'</title>
            <style>
                body {
                font-family: Arial, sans-serif;
                font-size: 14px;
                }
                h1 {
                font-size: 18px;
                color: #444;
                margin-bottom: 20px;
                }
                ul {
                list-style-type: none;
                padding: 0;
                margin: 0;
                }
                li {
                margin-bottom: 10px;
                }
            </style>
            </head>
            <body>
            <h1>Password Changed for '.SITENAME.' account</h1>
            <br>
            <p>Dear '. $userName .',</p>
            <p>The password for your '.SITENAME.' account '. $userEmail .' was changed. If you did not change it, you should recover your account.</a>.</p>
            <p>If you did change your password, you can ignore this message.</p>
            <br>
            
            <p>Best regards,<br>The '.SITENAME.' Team</p>
            </body>
            </html>'
        ;
    
    $mail->send();
  
  }

  public function change_profileImg(){

    $this->deliverypersonModel = $this->model('DeliveryPerson');
    $data ="";
  
    $this->view('DeliveryPersons/change_profileImg', $data);
  
  }  

  public function UpdateProfilePicture(){
    if(isset($_POST["submit"])){
      $img_name = $_FILES['image1']['name'];
      $img_size = $_FILES['image1']['size'];
      $tmp_name = $_FILES['image1']['tmp_name'];
      $error = $_FILES['image1']['error'];

      if($error === 0){
          if($img_size > 12500000){
              // $data['image1_err'] = "Sorry, your first image is too large.";
              // $this->landToErrorPage();
              die();
          }
          else{
              $img_ex = pathinfo($img_name, PATHINFO_EXTENSION); //Extension type of image(jpg,png)
              $img_ex_lc = strtolower($img_ex);

              $allowed_exs = array("jpg", "jpeg", "png"); 

              if(in_array($img_ex_lc, $allowed_exs)){

                  $new_img_name = uniqid("IMG-", true).'.'.$img_ex_lc;
                  $img_upload_path = dirname(APPROOT).'/public/img/user-pics/'.$new_img_name;
                  move_uploaded_file($tmp_name, $img_upload_path);
                  // $data['image1'] = $new_img_name;

                  //Insert into database
                  if($this->deliverypersonModel->UploadProfilePicture($new_img_name)){
                      $_SESSION['profile'] = $new_img_name;
                      $this->view('DeliveryPersons/my_account');
                  }
                  else{
                      die('Something went wrong');
                  }
              }
              else{
                  // $data['image1_err'] = "You can't upload files of this type";
                  // $this->landToErrorPage();
                  die();
              }
          }
      }
      else{
          // $data['image1_err'] = "Unknown error occurred!";
          // $this->landToErrorPage();
          die();
      }
  }else{
      // $data['image1_err'] = 'Please upload atleast one image';
 // $this->landToErrorPage();
      die();
  }
  
}

public function search_pending() {
  $result = $this->deliverypersonModel->search_location($_POST['search']);
        
  $output = '';

  if($result>0){
      foreach($result as $row) {
        $output .= '                          
                  <tr class="dataset1">
                  <td>OD'. $row->orderID . '</td>
                  <td>' . $row->invoiceID . '</td>
                  <td>' . $row->customerID . '</td>
                  <td>' . $row->date . '</td>
                  <td>
                      <form action="'.URLROOT.'/deliveryPersons/locate" method="POST">
                          <input type="hidden" name="customerID" value="' . $row->customerID . '">
                          <input type="hidden" name="address" value="' . $row->address . '">
                          <input type="hidden" name="city" value="' . $row->city . '">
                          <input type="submit" id="location" value="' . $row->address . " " . $row->city . '">
                      </form>
                  </td>
                  <td class="vm">
                      <form id="confirmationForm" action="'.URLROOT.'/deliveryPersons/accept_pendingOrder" method="POST">
                          <input type="hidden" name="orderID" value="' . $row->orderID . '">
                          <input type="hidden" name="customerID" value="' . $row->customerID . '">
                          <input type="hidden" name="invoiceID" value="' . $row->invoiceID . '">
                          <input type="hidden" name="date" value="' . $row->date . '">
                          <button id="submitBtn" class="viewMore" type="submit">Accept</button>
                      </form>
                  </td>
              </tr>
                        ';
            }

            foreach ($result as $row) {
            $output .= '
              <tr class="dataset1">
                  <!-- Display the relevant columns from customer_prescription table -->
                  <td>P' . $row->prescriptionID . '</td>
                  <td>' . $row->invoiceID . '</td>
                  <td>' . $row->customerID . '</td>
                  <td>' . $row->date . '</td>
                  <td>
                      <form action="'.URLROOT.'/deliveryPersons/locate" method="POST">
                          <input type="hidden" name="customerID" value="' . $row->customerID . '">
                          <input type="hidden" name="address" value="' . $row->address . '">
                          <input type="hidden" name="city" value="' . $row->city . '">
                          <input type="submit" id="location" value="' . $row->address . " " . $row->city . '">
                      </form>
                  </td>
                  <td class="vm">
                      <form id="confirmationForm" action="'.URLROOT.'/deliveryPersons/accept_pendingOrder" method="POST">
                          <input type="hidden" name="prescriptionID" value="' . $row->prescriptionID . '">
                          <input type="hidden" name="customerID" value="' . $row->customerID . '">
                          <input type="hidden" name="invoiceID" value="' . $row->invoiceID . '">
                          <input type="hidden" name="date" value="' . $row->date . '">
                          <button id="submitBtn" class="viewMore" type="submit">Accept</button>
                      </form>
                  </td>
              </tr>
              ';
          }
        }

        else{
          $output .= '
          <tr><td colspan="5">No results found</td></tr>';
        }
      
        echo $output;
      }


      public function search_inprogress() {
        $result = $this->deliverypersonModel->search_inprogress($_POST['search']);
              
        $output = '';
      
        if($result>0){
            foreach($result as $row) {
              $output .= '                          
                    <tr class="dataset1">
                    <td>' .$row->deliveryID. '</td>
                    <td>' .$row->customerID. '</td>
                    <td>' .$row->acceptDate. '</td>
                    <td>
                        <form action="'.URLROOT.'/deliveryPersons/locate" method="POST">
                            <input type="hidden" name="customerID" value="' .$row->customerID.'">
                            <input type="hidden" name="address" value="' .$row->address.'">
                            <input type="hidden" name="city" value="' .$row->city.'">
                            <input type="submit" id="location" value="' .$row->address." ".$row->city.'">
                        </form>
                    </td>
                    <td class="vm1">
                        <form action="'.URLROOT.'/deliveryPersons/inprogress_view" method="POST">
                            <input type="hidden" name="deliveryID" value="' .$row->deliveryID.'">
                            <input type="hidden" name="customerID" value="' .$row->customerID.'">
                            <button class="viewMore" type="submit"><img src="'.URLROOT.'/public/img/admins/eye.png" alt="view more" style="width:35px;height:25px;"></button>
                        </form>
                    </td>
                </tr>
                              ';
                  }
      
                  
              }
      
              else{
                $output .= '
                <tr><td colspan="5">No results found</td></tr>';
              }
            
              echo $output;
            }


            public function search_completed() {
              $result = $this->deliverypersonModel->search_completed($_POST['search']);
                    
              $output = '';
            
              if($result>0){
                  foreach($result as $row) {
                    $output .= '                          
                      <tr class="dataset1">
                      <td>' .$row->deliveryID. '</td>
                      <td>' .$row->customerID. '</td>
                      <td>' .($row->deliveredDate == NULL ? $row->rejectedDate : $row->deliveredDate). '</td>
                      
                      <td>
                          <form action="'.URLROOT.'/deliveryPersons/locate" method="POST">
                              <input type="hidden" name="customerID" value="' .$row->customerID.'">
                              <input type="hidden" name="address" value="' .$row->address.'">
                              <input type="hidden" name="city" value="' .$row->city.'">
                              <input type="submit" id="location" value="' .$row->address." ".$row->city.'">
                          </form>
                      </td>
                      <td>' .ucfirst($row->availability_status). '</td>
                    
                      <td class="vm1">
                          <form action="'.URLROOT.'/deliveryPersons/delivered_view" method="POST">
                              <input type="hidden" name="deliveryID" value="' .$row->deliveryID.'">
                              <input type="hidden" name="customerID" value="' .$row->customerID.'">
                              <button class="viewMore" type="submit"><img src="'.URLROOT.'/public/img/admins/eye.png" alt="view more" style="width:35px;height:25px;"></button>
                          </form>
                      </td>
                      </tr>
                                    ';
                        }
            
                        
                    }
            
                    else{
                      $output .= '
                      <tr><td colspan="5">No results found</td></tr>';
                    }
                  
                    echo $output;
                  }
      

         

}
        
        
    

