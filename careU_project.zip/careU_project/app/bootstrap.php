<?php

  // Load Config
  require_once 'config/config.php';

  // Helps to create sessions in the web application
  require_once('helpers/session_helper.php');

  //Helps to redirect through the application
  require_once('helpers/url_helper.php');

 

  require_once '../app/helpers/mailer_sender.php';


  require_once "../app/libraries/Controller.php";
  require_once "../app/libraries/Core.php";
  require_once "../app/libraries/Database.php";


  use PHPMailer\PHPMailer\PHPMailer;
  use PHPMailer\PHPMailer\Exception;
  require 'helpers/phpmailer/src/Exception.php';
  require 'helpers/phpmailer/src/PHPMailer.php';
  require 'helpers/phpmailer/src/SMTP.php';

    // Autoload Core Libraries
    spl_autoload_register(function($className){
      require_once 'libraries/' . $className . '.php';
    });





