<?php

  // App Root
  define('APPROOT', (dirname(dirname(__FILE__))));

  //DB Params
  define('DB_HOST', 'localhost');
  define('DB_USER', 'root');
  define('DB_PASS', '');
  define('DB_NAME', 'careu');

  
  // URL Root
  define('URLROOT', 'http://localhost/careU_project');
  
  // Site Name
  define('SITENAME', 'careU-Pharmacy');

  // Set timezone
  date_default_timezone_set('Asia/Kolkata');









