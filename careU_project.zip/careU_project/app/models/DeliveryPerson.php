<?php
     
     class deliveryperson{

        private $db;

        public function __construct()
        {
            $this->db = new Database;
        }

        
        public function getPendingOrders()
        {
            $this->db->query('SELECT * FROM order_details 
                  INNER JOIN users ON order_details.customerID = users.user_ID
                  WHERE order_details.order_status = "pending" 
                  ORDER BY order_details.date DESC');

            $results = $this->db->resultSet();
            
            return $results;

        }
        public function getPendingPrescriptionOrders()
        {
            $this->db->query('SELECT * FROM customer_prescription 
                  INNER JOIN users ON customer_prescription.customerID = users.user_ID
                  WHERE customer_prescription.order_status = "pending" 
                  ORDER BY customer_prescription.date DESC');

            $results = $this->db->resultSet();
            
            return $results;

        }



        public function getInprogressOrders($user_ID)
        {
            $this->db->query('SELECT delivery_guy.deliveryID, delivery_guy.customerID, delivery_guy.acceptDate, users.address, users.city  
            FROM delivery_guy 
            INNER JOIN users ON delivery_guy.customerID = users.user_ID 
            where delivery_guy.availability_status = "in progress" AND delivery_guy.deliverypersonID = :user_ID ORDER BY delivery_guy.acceptDate DESC');
            $this->db->bind(':user_ID', $user_ID);
            $results = $this->db->resultSet();
            return $results;
        }
        

        public function getDeliveredOrders($user_ID)
        {
            $this->db->query('SELECT delivery_guy.deliveryID, delivery_guy.customerID, delivery_guy.deliveredDate , delivery_guy.rejectedDate, delivery_guy.availability_status,users.address, users.city  
            FROM delivery_guy 
            INNER JOIN users ON delivery_guy.customerID = users.user_ID 
            where delivery_guy.availability_status = "delivered" OR delivery_guy.availability_status = "rejected" AND delivery_guy.deliverypersonID = :user_ID ORDER BY delivery_guy.deliveryID DESC');
            $this->db->bind(':user_ID', $user_ID);
            $results = $this->db->resultSet();
            return $results;
        }


        public function accept_pendingOrder($data)
        {
            
            $this->db->query('INSERT INTO delivery_guy (OrderPresID, customerID, deliverypersonID, availability_status, invoiceID, orderDate, acceptDate, deliveredDate,review) 
            VALUES (:orderID, :customerID, :deliverypersonID, :availability_status, :invoiceID, :orderDate, :acceptDate, NULL, NULL)');
            $this->db->bind(':orderID', $data['orderID']);
            $this->db->bind(':customerID', $data['customerID']);
            $this->db->bind(':deliverypersonID', $_SESSION['user_ID']);
            $this->db->bind(':availability_status', $data['availability_status']);
            $this->db->bind(':invoiceID', $data['invoiceID']);
            $this->db->bind(':orderDate', $data['orderDate']);
            $this->db->bind(':acceptDate', $data['acceptDate']);

            if ($this->db->execute()) {
                
                    // Update order_details table
                    $this->db->query('UPDATE order_details SET order_status = "accepted", deliverypersonID = :deliverypersonID WHERE orderID = :orderID');
                    $this->db->bind(':deliverypersonID', $_SESSION['user_ID']);
                    $this->db->bind(':orderID', $data['orderID']);
                

                if ($this->db->execute()) {
                    return true;
                } else {
                    return false;
                }
            } else {
                return false;
            }
        }

        public function accept_pendingPrescriptionOrder($data){
            $this->db->query('INSERT INTO delivery_guy (OrderPresID, customerID, deliverypersonID, availability_status, invoiceID, orderDate, acceptDate, deliveredDate,review) 
            VALUES (:prescriptionID, :customerID, :deliverypersonID, :availability_status, :invoiceID, :orderDate, :acceptDate, NULL, NULL)');
            $this->db->bind(':prescriptionID', $data['prescriptionID']);
            $this->db->bind(':customerID', $data['customerID']);
            $this->db->bind(':deliverypersonID', $_SESSION['user_ID']);
            $this->db->bind(':availability_status', $data['availability_status']);
            $this->db->bind(':invoiceID', $data['invoiceID']);
            $this->db->bind(':orderDate', $data['orderDate']);
            $this->db->bind(':acceptDate', $data['acceptDate']);

            if ($this->db->execute()) {
                
                    // Update order_details table
                    $this->db->query('UPDATE customer_prescription SET order_status = "accepted", deliverypersonID = :deliverypersonID WHERE prescriptionID = :prescriptionID');
                    $this->db->bind(':deliverypersonID', $_SESSION['user_ID']);
                    $this->db->bind(':prescriptionID', $data['prescriptionID']);
                

                if ($this->db->execute()) {
                    return true;
                } else {
                    return false;
                }
            } else {
                return false;
            }
        }



        public function getCustomerDetails($customerID){

            $this->db->query('SELECT * FROM users WHERE user_ID = :customerID');
            $this->db->bind(':customerID', $customerID);
            $row = $this->db->single();
            
            if($this->db->rowCount() > 0){
                return $row;

            }else{
                return false;
            }
        }

        public function getOrderDetails($orderId){

            $this->db->query('SELECT * FROM order_details WHERE orderId = :orderId');
            $this->db->bind(':orderId', $orderId);
            $row = $this->db->single();

            if($this->db->rowCount() > 0){
                return $row;
            }else{
                return false;
            }

        }

        public function getDeliveryDetails($deliveryID){

            $this->db->query('SELECT * FROM delivery_guy WHERE deliveryID = :deliveryID');
            $this->db->bind(':deliveryID', $deliveryID);
            $row = $this->db->single();

            if($this->db->rowCount() > 0){
                return $row;
            }else{
                return false;
            }

        }

        public function inprogress_confirm($data){
                
                $this->db->query('UPDATE delivery_guy SET availability_status = "delivered", deliveredDate = :deliveredDate, review = "Successful Delivery" WHERE deliveryID = :deliveryID');
                $this->db->bind(':deliveredDate', $data['deliveredDate']);
                $this->db->bind(':deliveryID', $data['deliveryID']);
    
                if($this->db->execute()){
                    return true;
                    
                }else{
                    return false;
                }
        }
        
        public function inprogress_reject($data){

            $this->db->query('UPDATE delivery_guy SET availability_status = "rejected", rejectedDate = :rejectedDate, review = :review WHERE deliveryID = :deliveryID');
            $this->db->bind(':rejectedDate', $data['rejectedDate']);
            $this->db->bind(':review', $data['review']);
            $this->db->bind(':deliveryID', $data['deliveryID']);
             
                       
            if($this->db->execute()){
                return true;
            }else{
                return false;
               }

           
        }


      


        public function findUserByEmail($email){
            $this->db->query("SELECT * FROM users where email = :email");
            $this->db->bind(':email', $email);

            $this->db->single();

            //check row
            if($this->db->rowCount() > 0){
                return true;
            }
            else{
                return false;
            }
        }


        public function findUserByUserID($user_ID){

            $this->db->query("SELECT * FROM users where user_ID = :user_ID");
            $this->db->bind(':user_ID', $user_ID);

            $row = $this->db->single();

            //check row
            if($this->db->rowCount() > 0){
                return $row;
            }else{
                return false;
            } 
        }


        public function change_password($data) {
            $newPassword = $data['newPassword'];
            // Hash the password
            $hashedPassword = password_hash(strval($newPassword), PASSWORD_DEFAULT);
            $email = $_SESSION['user_email'];
        
            // Prepare query
            $query = "UPDATE users SET password = :hashedPassword WHERE email = :email";
            $this->db->query($query);
            $this->db->bind(':hashedPassword', $hashedPassword);
            $this->db->bind(':email', $email);
        
            $this->db->execute();
        
            if ($this->db->rowCount() > 0) {
                return true;
            } else {
                return false;
            }
        }

        public function UploadProfilePicture($data){
            $profilePicture = $data;
            $email = $_SESSION['user_email'];
            //prepare query
            $temp = "UPDATE users SET user_img = :profilePicture WHERE email = :email";
            $this->db->query($temp);
            $this->db->bind(':profilePicture', $profilePicture);
            $this->db->bind(':email', $email);

            $this->db->execute();

            if($this->db->rowCount() > 0){
                return true;
            }else{
                return false;
            }
        }


        


        public function getCount_pendingOrders(){
            $this->db->query("SELECT COUNT(*) AS pendingOrders FROM order_details WHERE order_status = 'pending';");
            $row1 = $this->db->single();
            $pendingOrdersCount = $row1->pendingOrders;
        
            // Retrieve data from customer_prescription table where order_status is 'pending'
            $this->db->query("SELECT COUNT(*) AS prescriptionCount FROM customer_prescription WHERE order_status = 'pending';");
            $row2 = $this->db->single();
            $prescriptionCount = $row2->prescriptionCount;
        
            $totalCount = $pendingOrdersCount + $prescriptionCount;
        
            return $totalCount;
        }
        


        
        

        public function getCount_acceptedOrders(){
            $this->db->query("SELECT COUNT(*) AS acceptedOrders FROM delivery_guy WHERE availability_status = 'in progress';");
            $row = $this->db->resultSet();
            return $row[0]->acceptedOrders;

        }

        public function getCount_completedOrders(){
            $this->db->query("SELECT COUNT(*) AS completedOrders FROM delivery_guy WHERE availability_status = 'delivered' OR availability_status = 'rejected' ;");
            $row = $this->db->resultSet();
            return $row[0]->completedOrders;

        }


        public function getDeliveredOrdersDetails(){
            $this->db->query("SELECT * FROM delivery_guy WHERE availability_status = 'delivered' AND deliveredDate IS NOT NULL OR availability_status = 'rejected' ORDER BY deliveredDate DESC LIMIT 5;");
            $row = $this->db->resultSet();
            return $row;
        }


        public function getDeliveryStatusCounts(){
            $this->db->query("SELECT availability_status, COUNT(*) AS count FROM delivery_guy WHERE availability_status IN ('delivered', 'rejected') GROUP BY availability_status;");
            $rows = $this->db->resultSet();
            return $rows;
        }
        

        public function search_location($search) {
            $this->db->query("SELECT * FROM users
                LEFT JOIN order_details ON users.user_ID = order_details.customerID
                LEFT JOIN customer_prescription ON users.user_ID = customer_prescription.customerID
                WHERE (order_details.order_status = 'pending' OR customer_prescription.order_status = 'pending')
                    AND (address LIKE :search OR city LIKE :search)");
            $this->db->bind(':search', '%' . $search . '%');
            $this->db->execute(); // Execute the query
        
            $row = $this->db->resultSet();
        
            if ($this->db->rowCount() > 0) {
                return $row;
            } else {
                return false;
            }
        }


        public function search_inprogress($search){
            $this->db->query("SELECT * FROM delivery_guy
            INNER JOIN users ON delivery_guy.customerID = users.user_ID
            WHERE delivery_guy.availability_status = 'in progress' 
            AND (users.address LIKE :search OR users.city LIKE :search)");
            $this->db->bind(':search', '%' . $search . '%');
            $this->db->execute(); // Execute the query

            $row = $this->db->resultSet();

            if ($this->db->rowCount() > 0) {
                return $row;
            } else {
                return false;
            }
        }

        public function search_completed($search){
            $this->db->query("SELECT * FROM delivery_guy
            INNER JOIN users ON delivery_guy.customerID = users.user_ID
            WHERE delivery_guy.availability_status = 'ejected' OR delivery_guy.availability_status = 'delivered'
            AND (users.address LIKE :search OR users.city LIKE :search)");
            $this->db->bind(':search', '%' . $search . '%');
            $this->db->execute(); // Execute the query

            $row = $this->db->resultSet();

            if ($this->db->rowCount() > 0) {
                return $row;
            } else {
                return false;
            }
        }
        
        
        
        
    

}