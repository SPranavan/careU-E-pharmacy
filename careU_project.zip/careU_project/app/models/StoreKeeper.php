<?php
    class StoreKeeper{
        private $db;

        public function __construct()
        {
            $this->db = new Database;
        }

        public function getlastID()
        {
            $this->db->query("SELECT * FROM medicine ORDER BY medicineID DESC LIMIT 1");
            $row=$this->db->resultSet();
            return $row[0]->medicineID+1;
        }

        public function getHeartMeds()
        {
            $this->db->query("SELECT * FROM medicine WHERE medicine_type1='medicine' AND medicine_type2 ='heart'");
            $row = $this->db->resultSet();
            return $row;
        }

        public function getdiabetesMeds()
        {
            $this->db->query("SELECT * FROM medicine WHERE medicine_type1='medicine' AND medicine_type2 ='diabetes'");
            $row = $this->db->resultSet();
            return $row;
            
        }

        public function getinfectionMeds()
        {
            $this->db->query("SELECT * FROM medicine WHERE medicine_type1='medicine' AND medicine_type2 ='infection'");
            $row = $this->db->resultSet();
            return $row;
            
        }

        public function getgastroMeds()
        {
            $this->db->query("SELECT * FROM medicine WHERE medicine_type1='medicine' AND medicine_type2 ='gastro'");
            $row = $this->db->resultSet();
            return $row;
            
        }

        public function getmuscleMeds()
        {
            $this->db->query("SELECT * FROM medicine WHERE medicine_type1='medicine' AND medicine_type2 ='muscle'");
            $row = $this->db->resultSet();
            return $row;
            
        }

        public function getnourishments()
        {
            $this->db->query("SELECT * FROM medicine WHERE medicine_type1='personal care' AND medicine_type2 ='nourishments'");
            $row = $this->db->resultSet();
            return $row;
            
        }

        public function getaccessories()
        {
            $this->db->query("SELECT * FROM medicine WHERE medicine_type1='personal care' AND medicine_type2 ='accessories'");
            $row = $this->db->resultSet();
            return $row;
            
        }

        public function getskincare()
        {
            $this->db->query("SELECT * FROM medicine WHERE medicine_type1='personal care' AND medicine_type2 ='skin care'");
            $row = $this->db->resultSet();
            return $row;
            
        }

        public function women_personalcare()
        {
            $this->db->query("SELECT * FROM medicine WHERE medicine_type1='personal care' AND medicine_type2 ='women personal care'");
            $row = $this->db->resultSet();
            return $row;
            
        }

        public function oralcare()
        {
            $this->db->query("SELECT * FROM medicine WHERE medicine_type1='personal care' AND medicine_type2 ='oral care'");
            $row = $this->db->resultSet();
            return $row;
            
        }

        public function firstaid()
        {
            $this->db->query("SELECT * FROM medicine WHERE medicine_type1='medical devices' AND medicine_type2 ='first aid'");
            $row = $this->db->resultSet();
            return $row;
            
        }

        public function health_device()
        {
            $this->db->query("SELECT * FROM medicine WHERE medicine_type1='medical devices' AND medicine_type2 ='health device'");
            $row = $this->db->resultSet();
            return $row;
            
        }

        public function support()
        {
            $this->db->query("SELECT * FROM medicine WHERE medicine_type1='medical devices' AND medicine_type2 ='support'");
            $row = $this->db->resultSet();
            return $row;
            
        }

        public function addmedicine($data){
            $this->db->query('INSERT INTO medicine (medicineID,name,quantity,medicine_type1,medicine_type2,price,quantity_measurement,expiry_date,image,flag) VALUES(:medicineID,:name,:quantity,:medicine_type1,:medicine_type2,:price,:quantity_measurement,:expiry_date,:image,:flag)');
            // Bind values
            $this->db->bind(':medicine_type1', $data['service']);
            $this->db->bind(':medicine_type2', $data['medicine_type']);
            $this->db->bind(':medicineID', $data['medicine_id']);
            $this->db->bind(':name', $data['medicine_name']);
            $this->db->bind(':quantity', $data['total_items']);
            $this->db->bind(':price', $data['price']);
            $this->db->bind(':quantity_measurement', $data['quantity_mesurement']);
            $this->db->bind(':expiry_date', $data['date_of_expiry']);
            $this->db->bind(':image', $data['image']);
            $this->db->bind(':flag', $data['prescription']);

            //image input 
      

            // Execute
            if($this->db->execute()){
              return true;
            } else {
              return false;
            }
          }


        //   public function get_rowby_id($id)
        //   {
        //     $this->db->query("select * from medicine where medicineID=$id");
        //     $row = $this->db->single();
        //     return $row;
              
        //   }


          public function getMedicineByID($id)
          {
            $this->db->query("select * from medicine where medicineID=:id");
            $this->db->bind(':id',$id);

            $row = $this->db->single();
            return $row;
          }



          public function editmedicine($data){

            if($data['medicine_radio']=='add'){
              $this->db->query('UPDATE medicine SET quantity=quantity + :quantity, price=:price, expiry_date=:expiry_date where medicineID=:medicineID');
            }
            else if($data['medicine_radio']=='remove'){
              $this->db->query('UPDATE medicine SET quantity=quantity - :quantity, price=:price, expiry_date=:expiry_date where medicineID=:medicineID');
            }

            // $this->db->query('UPDATE medicine SET quantity=:quantity,price=:price,expiry_date=:expiry_date where medicineID=:medicineID');
            // Bind values
            $this->db->bind(':medicineID', $data['medicine_id']);
            $this->db->bind(':quantity', $data['total_items']);
            $this->db->bind(':price', $data['price']);
            $this->db->bind(':expiry_date', $data['expiry_date']);

            // Execute
            if($this->db->execute()){
              return true;
            } else {
              return false;
            }
          }

          public function deletemedicine($id){
            $this->db->query('DELETE FROM medicine WHERE medicineID=:medicineID');
            // Bind values
            $this->db->bind(':medicineID', $id);

            // Execute
            if($this->db->execute()){
              return true;
            } else {
              return false;
            }
          }





          //search

          //medical devices
          public function search_firstaid($str)
          {
              $this->db->query("SELECT * FROM medicine WHERE medicine_type1='medical devices' AND medicine_type2 ='first aid' AND name LIKE '$str%' ");
              
              $row = $this->db->resultSet();
              return $row;
          }

          public function search_healthdevices($str)
          {
              $this->db->query("SELECT * FROM medicine WHERE medicine_type1='medical devices' AND medicine_type2 ='health device' AND name LIKE '$str%' ");
              
              $row = $this->db->resultSet();
              return $row;
          }

          public function search_supports($str)
          {
              $this->db->query("SELECT * FROM medicine WHERE medicine_type1='medical devices' AND medicine_type2 ='support' AND name LIKE '$str%' ");
              
              $row = $this->db->resultSet();
              return $row;
          }



          //personal care
          public function search_nourishments($str)
          {
              $this->db->query("SELECT * FROM medicine WHERE medicine_type1='personal care' AND medicine_type2 ='nourishments' AND name LIKE '$str%' ");
              
              $row = $this->db->resultSet();
              return $row;
          }

          public function search_accessories($str)
          {
              $this->db->query("SELECT * FROM medicine WHERE medicine_type1='personal care' AND medicine_type2 ='accessories' AND name LIKE '$str%' ");
              
              $row = $this->db->resultSet();
              return $row;
          }

          public function search_skincare($str)
          {
              $this->db->query("SELECT * FROM medicine WHERE medicine_type1='personal care' AND medicine_type2 ='skin care' AND name LIKE '$str%' ");
              
              $row = $this->db->resultSet();
              return $row;
          }

          public function search_womenpc($str)
          {
              $this->db->query("SELECT * FROM medicine WHERE medicine_type1='personal care' AND medicine_type2 ='women personal care' AND name LIKE '$str%' ");
              
              $row = $this->db->resultSet();
              return $row;
          }

          public function search_oralcare($str)
          {
              $this->db->query("SELECT * FROM medicine WHERE medicine_type1='personal care' AND medicine_type2 ='oral care' AND name LIKE '$str%' ");
              
              $row = $this->db->resultSet();
              return $row;
          }


   
          //medicine
          public function search_heart($str)
          {
              $this->db->query("SELECT * FROM medicine WHERE medicine_type1='medicine' AND medicine_type2 ='heart' AND name LIKE '$str%' ");
              
              $row = $this->db->resultSet();
              return $row;
          }

          public function search_diabetes($str)
          {
              $this->db->query("SELECT * FROM medicine WHERE medicine_type1='medicine' AND medicine_type2 ='diabetes' AND name LIKE '$str%' ");
              
              $row = $this->db->resultSet();
              return $row;
          }

          public function search_infection($str)
          {
              $this->db->query("SELECT * FROM medicine WHERE medicine_type1='medicine' AND medicine_type2 ='infection' AND name LIKE '$str%' ");
              
              $row = $this->db->resultSet();
              return $row;
          }

          public function search_gastro($str)
          {
              $this->db->query("SELECT * FROM medicine WHERE medicine_type1='medicine' AND medicine_type2 ='gastro' AND name LIKE '$str%' ");
              
              $row = $this->db->resultSet();
              return $row;
          }

          public function search_muscle($str)
          {
              $this->db->query("SELECT * FROM medicine WHERE medicine_type1='medicine' AND medicine_type2 ='muscle' AND name LIKE '$str%' ");
              
              $row = $this->db->resultSet();
              return $row;
          }



          
          public function check_bought_status($mid){
            $this->db->query("SELECT * FROM invoice_medicine WHERE medicineID=:mid ");
            $this->db->bind(':mid',$mid);

            $row = $this->db->resultSet();
            $count=count($row);

            return $count;
          }

          public function get_invoice_id_by_mid($mid){
            $this->db->query("SELECT invoiceID FROM invoice_medicine WHERE medicineID=:mid ");
            $this->db->bind(':mid',$mid);

            $rows = $this->db->resultSet();

            $invoice_ids = array();
            foreach ($rows as $row) {
                $invoice_ids[] = (string) $row->invoiceID;
            }
            
            return $invoice_ids;
          }


          public function get_order_id_by_invoice_id($in_ids){
                $i=0;
                $order=array();

                foreach ($in_ids as $id) {

                    $order_details_table = "order_details";
                    $prescription_orders_table = "customer_prescription";
                    $table_found_orders_table = false;
                    $table_found_prescription_table = false;


                    // Check if order_id exists in order_details table
                    $this->db->query("SELECT orderID FROM $order_details_table WHERE invoiceID = :iID");
                    $this->db->bind(':iID', $id);

                    
                    $order_details_result = $this->db->single();
                    $order[$i]=(string) $order_details_result;

                    if(!empty($order_details_result)) {
                        // Update order_status in order_details table
                        $table_found_orders_table = true;
                    } else {
                        // Check if order_id exists in prescription_orders table
                        $this->db->query("SELECT orderID FROM $prescription_orders_table WHERE invoiceID = :iID");
                        $this->db->bind(':iID', $id);
                        $prescription_orders_result = $this->db->single();
                        $order[$i]=(string) $prescription_orders_result;

                        if(!empty($prescription_orders_result)) {
                            // Update order_status in prescription_orders table
                            // $this->db->query("UPDATE $prescription_orders_table SET order_status='processing' WHERE orderID = :orderID");
                            $table_found_prescription_table = true;
                        }
                    }
                    $i=$i+1;
                }
                if($table_found_orders_table) {
                    return $array;
                } else {
                    return $array;
                }
    
          }







          //sort

          //medical devices

          //first aid
          public function sort_alphebetical_firstaid(){
              $this->db->query("SELECT * FROM medicine WHERE medicine_type1='medical devices' AND medicine_type2 ='first aid' ORDER BY name ASC");
              $row = $this->db->resultSet();
              return $row;
          }

          public function sort_expiry_firstaid(){
              $this->db->query("SELECT * FROM medicine WHERE medicine_type1='medical devices' AND medicine_type2 ='first aid' ORDER BY expiry_date ASC");
              $row = $this->db->resultSet();
              return $row;
          }

          public function sort_quantity_firstaid(){
              $this->db->query("SELECT * FROM medicine WHERE medicine_type1='medical devices' AND medicine_type2 ='first aid' ORDER BY quantity ASC");
              $row = $this->db->resultSet();
              return $row;
          }


          //healthdevice
          public function sort_alphebetical_healthdevice(){
            $this->db->query("SELECT * FROM medicine WHERE medicine_type1='medical devices' AND medicine_type2 ='health device' ORDER BY name ASC");
            $row = $this->db->resultSet();
            return $row;
          }

        public function sort_expiry_healthdevice(){
            $this->db->query("SELECT * FROM medicine WHERE medicine_type1='medical devices' AND medicine_type2 ='health device' ORDER BY expiry_date ASC");
            $row = $this->db->resultSet();
            return $row;
        }

        public function sort_quantity_healthdevice(){
            $this->db->query("SELECT * FROM medicine WHERE medicine_type1='medical devices' AND medicine_type2 ='health device' ORDER BY quantity ASC");
            $row = $this->db->resultSet();
            return $row;
        }


        //supports
        public function sort_alphebetical_supports(){
            $this->db->query("SELECT * FROM medicine WHERE medicine_type1='medical devices' AND medicine_type2 ='support' ORDER BY name ASC");
            $row = $this->db->resultSet();
            return $row;
        }

        public function sort_expiry_supports(){
            $this->db->query("SELECT * FROM medicine WHERE medicine_type1='medical devices' AND medicine_type2 ='support' ORDER BY expiry_date ASC");
            $row = $this->db->resultSet();
            return $row;
        }

        public function sort_quantity_supports(){
            $this->db->query("SELECT * FROM medicine WHERE medicine_type1='medical devices' AND medicine_type2 ='support' ORDER BY quantity ASC");
            $row = $this->db->resultSet();
            return $row;
        }



      //personal care

      //nourishments
      public function sort_alphebetical_nourishments(){
          $this->db->query("SELECT * FROM medicine WHERE medicine_type1='personal care' AND medicine_type2 ='nourishments' ORDER BY name ASC");
          $row = $this->db->resultSet();
          return $row;
      }

      public function sort_expiry_nourishments(){
          $this->db->query("SELECT * FROM medicine WHERE medicine_type1='personal care' AND medicine_type2 ='nourishments' ORDER BY expiry_date ASC");
          $row = $this->db->resultSet();
          return $row;
      }

      public function sort_quantity_nourishments(){
          $this->db->query("SELECT * FROM medicine WHERE medicine_type1='personal care' AND medicine_type2 ='nourishments' ORDER BY quantity ASC");
          $row = $this->db->resultSet();
          return $row;
      }


      //accessories
      public function sort_alphebetical_accessories(){
          $this->db->query("SELECT * FROM medicine WHERE medicine_type1='personal care' AND medicine_type2 ='accessories' ORDER BY name ASC");
          $row = $this->db->resultSet();
          return $row;
      }

      public function sort_expiry_accessories(){
          $this->db->query("SELECT * FROM medicine WHERE medicine_type1='personal care' AND medicine_type2 ='accessories' ORDER BY expiry_date ASC");
          $row = $this->db->resultSet();
          return $row;
      }

      public function sort_quantity_accessories(){
          $this->db->query("SELECT * FROM medicine WHERE medicine_type1='personal care' AND medicine_type2 ='accessories' ORDER BY quantity ASC");
          $row = $this->db->resultSet();
          return $row;
      }

      //skincare
      public function sort_alphebetical_skincare(){
        $this->db->query("SELECT * FROM medicine WHERE medicine_type1='personal care' AND medicine_type2 ='skin care' ORDER BY name ASC");
        $row = $this->db->resultSet();
        return $row;
      }

      public function sort_expiry_skincare(){
          $this->db->query("SELECT * FROM medicine WHERE medicine_type1='personal care' AND medicine_type2 ='skin care' ORDER BY expiry_date ASC");
          $row = $this->db->resultSet();
          return $row;
      }

      public function sort_quantity_skincare(){
          $this->db->query("SELECT * FROM medicine WHERE medicine_type1='personal care' AND medicine_type2 ='skin care' ORDER BY quantity ASC");
          $row = $this->db->resultSet();
          return $row;
      }

      //women pc
      public function sort_alphebetical_womenpc(){
        $this->db->query("SELECT * FROM medicine WHERE medicine_type1='personal care' AND medicine_type2 ='women personal care' ORDER BY name ASC");
        $row = $this->db->resultSet();
        return $row;
      }

      public function sort_expiry_womenpc(){
          $this->db->query("SELECT * FROM medicine WHERE medicine_type1='personal care' AND medicine_type2 ='women personal care' ORDER BY expiry_date ASC");
          $row = $this->db->resultSet();
          return $row;
      }

      public function sort_quantity_womenpc(){
          $this->db->query("SELECT * FROM medicine WHERE medicine_type1='personal care' AND medicine_type2 ='women personal care' ORDER BY quantity ASC");
          $row = $this->db->resultSet();
          return $row;
      }

      //oral care
      public function sort_alphebetical_oralcare(){
        $this->db->query("SELECT * FROM medicine WHERE medicine_type1='personal care' AND medicine_type2 ='oral care' ORDER BY name ASC");
        $row = $this->db->resultSet();
        return $row;
      }

      public function sort_expiry_oralcare(){
          $this->db->query("SELECT * FROM medicine WHERE medicine_type1='personal care' AND medicine_type2 ='oral care' ORDER BY expiry_date ASC");
          $row = $this->db->resultSet();
          return $row;
      }

      public function sort_quantity_oralcare(){
          $this->db->query("SELECT * FROM medicine WHERE medicine_type1='personal care' AND medicine_type2 ='oral care' ORDER BY quantity ASC");
          $row = $this->db->resultSet();
          return $row;
      }


    //medicine

    //heart
    public function sort_alphebetical_heart(){
        $this->db->query("SELECT * FROM medicine WHERE medicine_type1='medicine' AND medicine_type2 ='heart' ORDER BY name ASC");
        $row = $this->db->resultSet();
        return $row;
    }

    public function sort_expiry_heart(){
        $this->db->query("SELECT * FROM medicine WHERE medicine_type1='medicine' AND medicine_type2 ='heart' ORDER BY expiry_date ASC");
        $row = $this->db->resultSet();
        return $row;
    }

    public function sort_quantity_heart(){
        $this->db->query("SELECT * FROM medicine WHERE medicine_type1='medicine' AND medicine_type2 ='heart' ORDER BY quantity ASC");
        $row = $this->db->resultSet();
        return $row;
    }


    //diabetes
    public function sort_alphebetical_diabetes(){
        $this->db->query("SELECT * FROM medicine WHERE medicine_type1='medicine' AND medicine_type2 ='diabetes' ORDER BY name ASC");
        $row = $this->db->resultSet();
        return $row;
    }

    public function sort_expiry_diabetes(){
        $this->db->query("SELECT * FROM medicine WHERE medicine_type1='medicine' AND medicine_type2 ='diabetes' ORDER BY expiry_date ASC");
        $row = $this->db->resultSet();
        return $row;
    }

    public function sort_quantity_diabetes(){
        $this->db->query("SELECT * FROM medicine WHERE medicine_type1='medicine' AND medicine_type2 ='diabetes' ORDER BY quantity ASC");
        $row = $this->db->resultSet();
        return $row;
    }

    //infection
    public function sort_alphebetical_infection(){
      $this->db->query("SELECT * FROM medicine WHERE medicine_type1='medicine' AND medicine_type2 ='infection' ORDER BY name ASC");
      $row = $this->db->resultSet();
      return $row;
    }

    public function sort_expiry_infection(){
        $this->db->query("SELECT * FROM medicine WHERE medicine_type1='medicine' AND medicine_type2 ='infection' ORDER BY expiry_date ASC");
        $row = $this->db->resultSet();
        return $row;
    }

    public function sort_quantity_infection(){
        $this->db->query("SELECT * FROM medicine WHERE medicine_type1='medicine' AND medicine_type2 ='infection' ORDER BY quantity ASC");
        $row = $this->db->resultSet();
        return $row;
    }

    //gastro
    public function sort_alphebetical_gastro(){
      $this->db->query("SELECT * FROM medicine WHERE medicine_type1='medicine' AND medicine_type2 ='gastro' ORDER BY name ASC");
      $row = $this->db->resultSet();
      return $row;
    }

    public function sort_expiry_gastro(){
        $this->db->query("SELECT * FROM medicine WHERE medicine_type1='medicine' AND medicine_type2 ='gastro' ORDER BY expiry_date ASC");
        $row = $this->db->resultSet();
        return $row;
    }

    public function sort_quantity_gastro(){
        $this->db->query("SELECT * FROM medicine WHERE medicine_type1='medicine' AND medicine_type2 ='gastro' ORDER BY quantity ASC");
        $row = $this->db->resultSet();
        return $row;
    }

    //muscle
    public function sort_alphebetical_muscle(){
      $this->db->query("SELECT * FROM medicine WHERE medicine_type1='medicine' AND medicine_type2 ='muscle' ORDER BY name ASC");
      $row = $this->db->resultSet();
      return $row;
    }

    public function sort_expiry_muscle(){
        $this->db->query("SELECT * FROM medicine WHERE medicine_type1='medicine' AND medicine_type2 ='muscle' ORDER BY expiry_date ASC");
        $row = $this->db->resultSet();
        return $row;
    }

    public function sort_quantity_muscle(){
        $this->db->query("SELECT * FROM medicine WHERE medicine_type1='medicine' AND medicine_type2 ='muscle' ORDER BY quantity ASC");
        $row = $this->db->resultSet();
        return $row;
    }
    

    //account page
    public function getuserdetails($email){
        $this->db->query("SELECT fName,lName,mobile,email,user_role,password FROM users WHERE email = :email ");
        $this->db->bind(':email', $email);
        $row = $this->db->resultSet();
        return $row;
    }

    public function updatePassword($email,$hashed)
    {
        $this->db->query("UPDATE users
        SET password= :hashed
        WHERE email=:email;");
        $this->db->bind(':hashed', $hashed);
        $this->db->bind(':email', $email);
        $row = $this->db->execute();
        if ($row) {
            return 1;
        } else {
            return 0;
        }
        
    }

    public function updateProfilePic($filename,$email)
    {
        $this->db->query("UPDATE users
        SET user_img= :picture
        WHERE email=:email;");
        $this->db->bind(':picture', $filename);
        $this->db->bind(':email', $email);
        $row = $this->db->execute();
        if ($row) {
            return 1;
        } else {
            return 0;
        }
    }


    // -------------------------------------------------------NEED TO MERGE-------------------------------------------------------------

    public function get_lowstock_count(){
        $this->db->query("SELECT * from medicine where quantity=0");
        $row=$this->db->resultSet();
        $count=count($row);

        return $count;
    }

    public function get_expired_count(){
        $this->db->query("SELECT expiry_date from medicine where DATE(expiry_date) <= CURDATE()");
        $row = $this->db->resultSet();
        $count = count($row);

        return $count;
    }

    public function get_medicine_count(){
        $this->db->query("SELECT medicineID from medicine where medicine_type1='medicine'");
        $row = $this->db->resultSet();
        $count = count($row);

        return $count;
    }

    public function get_personalcare_count(){
        $this->db->query("SELECT medicineID from medicine where medicine_type1='personal care'");
        $row = $this->db->resultSet();
        $count = count($row);

        return $count;
    }

    public function get_medicaldevices_count(){
        $this->db->query("SELECT medicineID from medicine where medicine_type1='medical devices'");
        $row = $this->db->resultSet();
        $count = count($row);

        return $count;
    }

    public function get_all_meds_count(){
        $this->db->query("SELECT medicineID from medicine");
        $row = $this->db->resultSet();
        $count = count($row);

        return $count;
    }

//------------------------------------------------------------------------0-------------------------------------------------------------

    public function updateQuantityReport(){
                //january
                $this->db->query('
                    SELECT SUM(january_sales) as total_january_sales
                    FROM (
                        SELECT im.quantity as january_sales
                        FROM order_details od 
                        JOIN invoice i ON od.invoiceID = i.invoiceID 
                        JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                        JOIN medicine m ON im.medicineID = m.medicineID 
                        WHERE 
                            MONTH(i.date_time) = 1 
                            AND YEAR(i.date_time) = 2022 
                            AND od.order_status = "completed"
                        
                        UNION ALL
                        
                        SELECT im.quantity as january_sales
                        FROM customer_prescription cp 
                        JOIN invoice i ON cp.invoiceID = i.invoiceID 
                        JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                        JOIN medicine m ON im.medicineID = m.medicineID 
                        WHERE 
                            MONTH(i.date_time) = 1 
                            AND YEAR(i.date_time) = 2022 
                            AND cp.order_status = "completed"
                    ) as january_sales_combined;
                ');
                $result = $this->db->single();
                $january_sales = $result->total_january_sales;

                //february
                $this->db->query('
                    SELECT SUM(february_sales) as total_february_sales
                    FROM (
                        SELECT im.quantity as february_sales
                        FROM order_details od 
                        JOIN invoice i ON od.invoiceID = i.invoiceID 
                        JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                        JOIN medicine m ON im.medicineID = m.medicineID 
                        WHERE 
                            MONTH(i.date_time) = 2 
                            AND YEAR(i.date_time) = 2022 
                            AND od.order_status = "completed"
                        
                        UNION ALL
                        
                        SELECT im.quantity as february_sales
                        FROM customer_prescription cp 
                        JOIN invoice i ON cp.invoiceID = i.invoiceID 
                        JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                        JOIN medicine m ON im.medicineID = m.medicineID 
                        WHERE 
                            MONTH(i.date_time) = 2 
                            AND YEAR(i.date_time) = 2022 
                            AND cp.order_status = "completed"
                    ) as february_sales_combined;
                ');
                $result = $this->db->single();
                $february_sales = $result->total_february_sales;

                //march
                $this->db->query('
                    SELECT SUM(march_sales) as total_march_sales
                    FROM (
                        SELECT im.quantity as march_sales
                        FROM order_details od 
                        JOIN invoice i ON od.invoiceID = i.invoiceID 
                        JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                        JOIN medicine m ON im.medicineID = m.medicineID 
                        WHERE 
                            MONTH(i.date_time) = 3 
                            AND YEAR(i.date_time) = 2022 
                            AND od.order_status = "completed"
                        
                        UNION ALL
                        
                        SELECT im.quantity as march_sales
                        FROM customer_prescription cp 
                        JOIN invoice i ON cp.invoiceID = i.invoiceID 
                        JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                        JOIN medicine m ON im.medicineID = m.medicineID 
                        WHERE 
                            MONTH(i.date_time) = 3 
                            AND YEAR(i.date_time) = 2022 
                            AND cp.order_status = "completed"
                    ) as march_sales_combined;
                ');
                $result = $this->db->single();
                $march_sales = $result->total_march_sales;

                //april
                $this->db->query('
                    SELECT SUM(april_sales) as total_april_sales
                    FROM (
                        SELECT im.quantity as april_sales
                        FROM order_details od 
                        JOIN invoice i ON od.invoiceID = i.invoiceID 
                        JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                        JOIN medicine m ON im.medicineID = m.medicineID 
                        WHERE 
                            MONTH(i.date_time) = 4 
                            AND YEAR(i.date_time) = 2022 
                            AND od.order_status = "completed"
                        
                        UNION ALL
                        
                        SELECT im.quantity as april_sales
                        FROM customer_prescription cp 
                        JOIN invoice i ON cp.invoiceID = i.invoiceID 
                        JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                        JOIN medicine m ON im.medicineID = m.medicineID 
                        WHERE 
                            MONTH(i.date_time) = 4 
                            AND YEAR(i.date_time) = 2022 
                            AND cp.order_status = "completed"
                    ) as april_sales_combined;
                ');
                $result = $this->db->single();
                $april_sales = $result->total_april_sales;

                //may
                $this->db->query('
                    SELECT SUM(may_sales) as total_may_sales
                    FROM (
                        SELECT im.quantity as may_sales
                        FROM order_details od 
                        JOIN invoice i ON od.invoiceID = i.invoiceID 
                        JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                        JOIN medicine m ON im.medicineID = m.medicineID 
                        WHERE 
                            MONTH(i.date_time) = 5 
                            AND YEAR(i.date_time) = 2022 
                            AND od.order_status = "completed"
                        
                        UNION ALL
                        
                        SELECT im.quantity as may_sales
                        FROM customer_prescription cp 
                        JOIN invoice i ON cp.invoiceID = i.invoiceID 
                        JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                        JOIN medicine m ON im.medicineID = m.medicineID 
                        WHERE 
                            MONTH(i.date_time) = 5 
                            AND YEAR(i.date_time) = 2022 
                            AND cp.order_status = "completed"
                    ) as may_sales_combined;
                ');
                $result = $this->db->single();
                $may_sales = $result->total_may_sales;

                //june
                $this->db->query('
                    SELECT SUM(june_sales) as total_june_sales
                    FROM (
                        SELECT im.quantity as june_sales
                        FROM order_details od 
                        JOIN invoice i ON od.invoiceID = i.invoiceID 
                        JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                        JOIN medicine m ON im.medicineID = m.medicineID 
                        WHERE 
                            MONTH(i.date_time) = 6 
                            AND YEAR(i.date_time) = 2022 
                            AND od.order_status = "completed"
                        
                        UNION ALL
                        
                        SELECT im.quantity as june_sales
                        FROM customer_prescription cp 
                        JOIN invoice i ON cp.invoiceID = i.invoiceID 
                        JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                        JOIN medicine m ON im.medicineID = m.medicineID 
                        WHERE 
                            MONTH(i.date_time) = 6 
                            AND YEAR(i.date_time) = 2022 
                            AND cp.order_status = "completed"
                    ) as june_sales_combined;
                ');
                $result = $this->db->single();
                $june_sales = $result->total_june_sales;

                //july
                $this->db->query('
                    SELECT SUM(july_sales) as total_july_sales
                        FROM (
                            SELECT im.quantity as july_sales
                            FROM order_details od 
                            JOIN invoice i ON od.invoiceID = i.invoiceID 
                            JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                            JOIN medicine m ON im.medicineID = m.medicineID 
                            WHERE 
                                MONTH(i.date_time) = 7 
                                AND YEAR(i.date_time) = 2022 
                                AND od.order_status = "completed"
                            
                            UNION ALL
                            
                            SELECT im.quantity as july_sales
                            FROM customer_prescription cp 
                            JOIN invoice i ON cp.invoiceID = i.invoiceID 
                            JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                            JOIN medicine m ON im.medicineID = m.medicineID 
                            WHERE 
                                MONTH(i.date_time) = 7 
                                AND YEAR(i.date_time) = 2022 
                                AND cp.order_status = "completed"
                    ) as july_sales_combined;
                ');
                $result = $this->db->single();
                $july_sales = $result->total_july_sales;

                //august
                $this->db->query('
                    SELECT SUM(august_sales) as total_august_sales
                    FROM (
                        SELECT im.quantity as august_sales
                        FROM order_details od 
                        JOIN invoice i ON od.invoiceID = i.invoiceID 
                        JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                        JOIN medicine m ON im.medicineID = m.medicineID 
                        WHERE 
                            MONTH(i.date_time) = 8 
                            AND YEAR(i.date_time) = 2022 
                            AND od.order_status = "completed"
                        
                        UNION ALL
                        
                        SELECT im.quantity as august_sales
                        FROM customer_prescription cp 
                        JOIN invoice i ON cp.invoiceID = i.invoiceID 
                        JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                        JOIN medicine m ON im.medicineID = m.medicineID 
                        WHERE 
                            MONTH(i.date_time) = 8 
                            AND YEAR(i.date_time) = 2022 
                            AND cp.order_status = "completed"
                    ) as august_sales_combined;
                ');
                $result = $this->db->single();
                $august_sales = $result->total_august_sales;

                //september
                $this->db->query('
                    SELECT SUM(september_sales) as total_september_sales
                    FROM (
                        SELECT im.quantity as september_sales
                        FROM order_details od 
                        JOIN invoice i ON od.invoiceID = i.invoiceID 
                        JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                        JOIN medicine m ON im.medicineID = m.medicineID 
                        WHERE 
                            MONTH(i.date_time) = 9 
                            AND YEAR(i.date_time) = 2022 
                            AND od.order_status = "completed"
                        
                        UNION ALL
                        
                        SELECT im.quantity as september_sales
                        FROM customer_prescription cp 
                        JOIN invoice i ON cp.invoiceID = i.invoiceID 
                        JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                        JOIN medicine m ON im.medicineID = m.medicineID 
                        WHERE 
                            MONTH(i.date_time) = 9 
                            AND YEAR(i.date_time) = 2022 
                            AND cp.order_status = "completed"
                    ) as september_sales_combined;
                ');
                $result = $this->db->single();
                $september_sales = $result->total_september_sales;

                //october
                $this->db->query('
                    SELECT SUM(october_sales) as total_october_sales
                    FROM (
                        SELECT im.quantity as october_sales
                        FROM order_details od 
                        JOIN invoice i ON od.invoiceID = i.invoiceID 
                        JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                        JOIN medicine m ON im.medicineID = m.medicineID 
                        WHERE 
                            MONTH(i.date_time) = 10 
                            AND YEAR(i.date_time) = 2022 
                            AND od.order_status = "completed"
                        
                        UNION ALL
                        
                        SELECT im.quantity as october_sales
                        FROM customer_prescription cp 
                        JOIN invoice i ON cp.invoiceID = i.invoiceID 
                        JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                        JOIN medicine m ON im.medicineID = m.medicineID 
                        WHERE 
                            MONTH(i.date_time) = 10 
                            AND YEAR(i.date_time) = 2022 
                            AND cp.order_status = "completed"
                    ) as october_sales_combined;
                ');
                $result = $this->db->single();
                $october_sales = $result->total_october_sales;

                //november
                $this->db->query('
                    SELECT SUM(november_sales) as total_november_sales
                    FROM (
                        SELECT im.quantity as november_sales
                        FROM order_details od 
                        JOIN invoice i ON od.invoiceID = i.invoiceID 
                        JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                        JOIN medicine m ON im.medicineID = m.medicineID 
                        WHERE 
                            MONTH(i.date_time) = 11 
                            AND YEAR(i.date_time) = 2022 
                            AND od.order_status = "completed"
                        
                        UNION ALL
                        
                        SELECT im.quantity as november_sales
                        FROM customer_prescription cp 
                        JOIN invoice i ON cp.invoiceID = i.invoiceID 
                        JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                        JOIN medicine m ON im.medicineID = m.medicineID 
                        WHERE 
                            MONTH(i.date_time) = 11 
                            AND YEAR(i.date_time) = 2022 
                            AND cp.order_status = "completed"
                    ) as november_sales_combined;
                ');
                $result = $this->db->single();
                $november_sales = $result->total_november_sales;

                //december
                $this->db->query('
                    SELECT SUM(december_sales) as total_december_sales
                    FROM (
                        SELECT im.quantity as december_sales
                        FROM order_details od 
                        JOIN invoice i ON od.invoiceID = i.invoiceID 
                        JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                        JOIN medicine m ON im.medicineID = m.medicineID 
                        WHERE 
                            MONTH(i.date_time) = 12 
                            AND YEAR(i.date_time) = 2022 
                            AND od.order_status = "completed"
                        
                        UNION ALL
                        
                        SELECT im.quantity as december_sales
                        FROM customer_prescription cp 
                        JOIN invoice i ON cp.invoiceID = i.invoiceID 
                        JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                        JOIN medicine m ON im.medicineID = m.medicineID 
                        WHERE 
                            MONTH(i.date_time) = 12 
                            AND YEAR(i.date_time) = 2022 
                            AND cp.order_status = "completed"
                    ) as december_sales_combined;
                ');
                $result = $this->db->single();
                $december_sales = $result->total_december_sales;


                // $this->db->query('
                //                 UPDATE sales_report  
                //                 SET amount = 
                //                     CASE 
                //                         WHEN month = "January" THEN :january
                //                         WHEN month = "February" THEN :february
                //                         WHEN month = "March" THEN :march
                //                         WHEN month = "April" THEN :april
                //                         WHEN month = "May" THEN :may
                //                         WHEN month = "June" THEN :june
                //                         WHEN month = "July" THEN :july
                //                         WHEN month = "August" THEN :august
                //                         WHEN month = "September" THEN :september
                //                         WHEN month = "October" THEN :october
                //                         WHEN month = "November" THEN :november
                //                         WHEN month = "December" THEN :december
                //                     END
                //                 ');

                // $this->db->bind(':january', $january_sales);
                // $this->db->bind(':february', $february_sales);
                // $this->db->bind(':march', $march_sales);
                // $this->db->bind(':april', $april_sales);
                // $this->db->bind(':may', $may_sales);
                // $this->db->bind(':june', $june_sales);
                // $this->db->bind(':july', $july_sales);
                // $this->db->bind(':august', $august_sales);
                // $this->db->bind(':september', $september_sales);
                // $this->db->bind(':october', $october_sales);
                // $this->db->bind(':november', $november_sales);
                // $this->db->bind(':december', $december_sales);

                $sales_array = array($january_sales, $february_sales, $march_sales, $april_sales, $may_sales, $june_sales, $july_sales, $august_sales, $september_sales, $october_sales, $november_sales, $december_sales);

                // Execute
                if($this->db->execute()){
                    return $sales_array;
                } else {
                return false;
                }
            }




            //email reminder 

            
        //low stock medicines
        public function get_count_low_stock(){
            $this->db->query("SELECT medicineID from medicine where quantity=0");
            $row = $this->db->resultSet();
            $count = count($row);
    
            return $count;
            }
    
    
    
            public function get_ids_low_stock(){
            $this->db->query("SELECT medicineID from medicine where quantity=0");
            $rows = $this->db->resultSet();
    
            $ids = array();
            foreach ($rows as $row) {
                $ids[] = (string) $row->medicineID;
            }
            return $ids;
            }
    
    
    
    
        //expired medicines
            public function get_count_expired(){
            $this->db->query("SELECT expiry_date from medicine where DATE(expiry_date) <= CURDATE()");
            $row = $this->db->resultSet();
            $count = count($row);
            
            return $count;
            }
    
    
    
            public function get_ids_expired(){
            $this->db->query("SELECT medicineID from medicine where DATE(expiry_date) <= CURDATE()");
            $rows = $this->db->resultSet();
    
            $ids = array();
            foreach ($rows as $row) {
                $ids[] = (string) $row->medicineID;
            }
            return $ids;
            }
    
    
    
            //storekeeper emails
            public function get_all_storekeeper_emails(){
            $this->db->query("SELECT email from users where user_role='storekeeper'");
            $rows = $this->db->resultSet();
            
            $emails = array();
            foreach ($rows as $row) {
                $emails[] = (string) $row->email;
            }
            
            return $emails;
            }

            // public function get_medicine_type_two_by_id($id){
            //     $this->db->query("SELECT medicine_type2 from medicine where medicineID=:id");

            //     $this->db->bind(':id', $id);
            //     $row = $this->db->single();

            //     return $row;
            // }
    
            public function get_medicine_type_one_by_id($id){
                $this->db->query("SELECT medicine_type1 from medicine where medicineID=:id");

                $this->db->bind(':id', $id);
                $name_object = $this->db->single();

                $name_string = (string) $name_object->medicine_type1;
                return $name_string;
            }
    
  }