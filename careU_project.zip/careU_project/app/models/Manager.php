<?php

    class Manager{
        private $db;

        public function __construct()
        {
            $this->db=new Database;
        }

        public function getCancelledOrders()
        {
            // $this->db->query(
            //     "SELECT od.orderID, i.date_time, i.item_name, i.quantity, i.sub_total, CONCAT(u.address, ' ', u.city) AS shippingAddress, od.payment_status 
            //     FROM order_details od
            //     JOIN users u ON od.customerID = u.user_ID 
            //     JOIN invoice i ON od.invoiceID = i.invoiceID 
            //     WHERE order_status='cancelled' && user_role='customer'"
            // );

            $this->db->query(
                "SELECT orderID, date_time, item_names, quantities, sub_total, shippingAddress, payment_status, invoiceID 
                FROM (
                    SELECT od.orderID, i.date_time, GROUP_CONCAT(m.name) AS item_names, GROUP_CONCAT(im.quantity) AS quantities, GROUP_CONCAT(im.quantity * m.price) AS sub_total, CONCAT(u.address, ' ', u.city) AS shippingAddress, od.payment_status, i.invoiceID
                    FROM order_details od
                    JOIN users u ON od.customerID = u.user_ID 
                    JOIN invoice i ON od.invoiceID = i.invoiceID 
                    JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                    JOIN medicine m ON im.medicineID = m.medicineID 
                    WHERE od.order_status='cancelled' && u.user_role='customer'
                    GROUP BY im.invoiceID
                    UNION
                    SELECT cp.orderID, i.date_time, GROUP_CONCAT(m.name) AS item_names, GROUP_CONCAT(im.quantity) AS quantities, GROUP_CONCAT(im.quantity * m.price) AS sub_total, CONCAT(u.address, ' ', u.city) AS shippingAddress, cp.payment_status, i.invoiceID
                    FROM customer_prescription cp
                    JOIN users u ON cp.customerID = u.user_ID 
                    JOIN invoice i ON cp.invoiceID = i.invoiceID 
                    JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                    JOIN medicine m ON im.medicineID = m.medicineID 
                    WHERE cp.order_status='cancelled' && u.user_role='customer'
                    GROUP BY im.invoiceID
                ) AS combined_table
                ORDER BY date_time DESC"
            );

            $row = $this->db->resultSet();
            return $row;
        }





        public function getInitiatedOrders()
        {
            // $this->db->query(
            //     "SELECT od.orderID, od.customerID, od.invoiceID, i.date_time, i.item_name, i.quantity, i.sub_total, CONCAT(u.address, ' ', u.city) AS shippingAddress
            //     FROM order_details od
            //     JOIN users u ON od.customerID = u.user_ID 
            //     JOIN invoice i ON od.invoiceID = i.invoiceID
            //     WHERE order_status='pending' && user_role='customer'"
            // );

            $this->db->query(
                "SELECT orderID, customerID, invoiceID, date_time, item_names, quantities, sub_total, shippingAddress, packing_status
                FROM (
                    SELECT od.orderID, od.customerID, i.invoiceID, i.date_time, GROUP_CONCAT(m.name) AS item_names, GROUP_CONCAT(im.quantity) AS quantities, GROUP_CONCAT(im.quantity * m.price) AS sub_total, CONCAT(u.address, ' ', u.city) AS shippingAddress, od.packing_status
                    FROM order_details od
                    JOIN invoice i ON od.invoiceID = i.invoiceID
                    JOIN invoice_medicine im ON i.invoiceID = im.invoiceID
                    JOIN medicine m ON im.medicineID = m.medicineID
                    JOIN users u ON od.customerID = u.user_ID 
                    WHERE od.order_status='pending' && u.user_role='customer'
                    GROUP BY im.invoiceID
                    UNION
                    SELECT cp.orderID, cp.customerID, i.invoiceID, i.date_time, GROUP_CONCAT(m.name) AS item_names, GROUP_CONCAT(im.quantity) AS quantities, GROUP_CONCAT(im.quantity * m.price) AS sub_total, CONCAT(u.address, ' ', u.city) AS shippingAddress, cp.packing_status
                    FROM customer_prescription cp
                    JOIN invoice i ON cp.invoiceID = i.invoiceID 
                    JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                    JOIN medicine m ON im.medicineID = m.medicineID 
                    JOIN users u ON cp.customerID = u.user_ID 
                    WHERE cp.order_status='pending' && u.user_role='customer'
                    GROUP BY im.invoiceID
                ) AS combined_table
                ORDER BY date_time DESC"
            );

            $row = $this->db->resultSet();
            return $row;
        }





        public function getProcessingOrders()
        {
            // $this->db->query(
            //     "SELECT od.orderID, i.date_time, i.item_name, i.quantity, CONCAT(u.address, ' ', u.city) AS shippingAddress, od.delivery_status, od.deliverypersonID
            //     FROM order_details od
            //     JOIN users u ON od.customerID = u.user_ID 
            //     JOIN invoice i ON od.InvoiceID = i.InvoiceID 
            //     WHERE order_status='processing' && user_role='customer'"
            // );

            $this->db->query(
                "SELECT orderID, date_time, item_names, quantities, shippingAddress, delivery_status, deliverypersonID, invoiceID
                FROM (
                    SELECT od.orderID, i.date_time, GROUP_CONCAT(m.name) AS item_names, GROUP_CONCAT(im.quantity) AS quantities, CONCAT(u.address, ' ', u.city) AS shippingAddress, od.delivery_status, od.deliverypersonID, i.invoiceID
                    FROM order_details od
                    JOIN users u ON od.customerID = u.user_ID 
                    JOIN invoice i ON od.invoiceID = i.invoiceID
                    JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                    JOIN medicine m ON im.medicineID = m.medicineID 
                    WHERE od.order_status='processing' && u.user_role='customer'
                    GROUP BY im.invoiceID
                    UNION
                    SELECT cp.orderID, i.date_time, GROUP_CONCAT(m.name) AS item_names, GROUP_CONCAT(im.quantity) AS quantities, CONCAT(u.address, ' ', u.city) AS shippingAddress, cp.delivery_status, cp.deliverypersonID, i.invoiceID
                    FROM customer_prescription cp
                    JOIN users u ON cp.customerID = u.user_ID 
                    JOIN invoice i ON cp.invoiceID = i.invoiceID 
                    JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                    JOIN medicine m ON im.medicineID = m.medicineID
                    WHERE cp.order_status='processing' && u.user_role='customer'
                    GROUP BY im.invoiceID
                ) AS combined_table
                ORDER BY date_time DESC"
            );

            $row = $this->db->resultSet();
            return $row;
        }





        public function getCompletedOrders()
        {
            // $this->db->query(
            //     "SELECT od.orderID, i.date_time, i.item_name, i.quantity, CONCAT(u.address, ' ', u.city) AS shippingAddress, od.order_status, od.deliverypersonID
            //     FROM order_details od
            //     JOIN users u ON od.customerID = u.user_ID 
            //     JOIN invoice i ON od.invoiceID = i.invoiceID 
            //     WHERE order_status='completed' && user_role='customer'"
            // );

            $this->db->query(
                "SELECT orderID, date_time, item_names, quantities, sub_total, shippingAddress, order_status, deliverypersonID, invoiceID
                FROM (
                    SELECT od.orderID, i.date_time, GROUP_CONCAT(m.name) AS item_names, GROUP_CONCAT(im.quantity) AS quantities, GROUP_CONCAT(im.quantity * m.price) AS sub_total, CONCAT(u.address, ' ', u.city) AS shippingAddress, od.order_status, od.deliverypersonID, i.invoiceID
                    FROM order_details od
                    JOIN users u ON od.customerID = u.user_ID 
                    JOIN invoice i ON od.invoiceID = i.invoiceID
                    JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                    JOIN medicine m ON im.medicineID = m.medicineID 
                    WHERE od.order_status='completed' && u.user_role='customer'
                    GROUP BY im.invoiceID
                    UNION
                    SELECT cp.orderID, i.date_time, GROUP_CONCAT(m.name) AS item_names, GROUP_CONCAT(im.quantity) AS quantities, GROUP_CONCAT(im.quantity * m.price) AS sub_total, CONCAT(u.address, ' ', u.city) AS shippingAddress, cp.order_status, cp.deliverypersonID, i.invoiceID
                    FROM customer_prescription cp
                    JOIN users u ON cp.customerID = u.user_ID 
                    JOIN invoice i ON cp.invoiceID = i.invoiceID 
                    JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                    JOIN medicine m ON im.medicineID = m.medicineID 
                    WHERE cp.order_status='completed' && u.user_role='customer'
                    GROUP BY im.invoiceID
                ) AS combined_table
                ORDER BY date_time DESC"
            );


            $row = $this->db->resultSet();
            return $row;
        }
        




        public function getRefundedOrders()
        {
            $this->db->query(
                "SELECT orderID, date_time, user_ID, item_names, quantities, sub_total, order_status, invoiceID
                FROM (
                    SELECT od.orderID, i.date_time, u.user_ID, GROUP_CONCAT(m.name) AS item_names, GROUP_CONCAT(im.quantity) AS quantities, GROUP_CONCAT(im.quantity * m.price) AS sub_total, od.order_status, i.invoiceID
                    FROM order_details od
                    JOIN users u ON od.customerID = u.user_ID 
                    JOIN invoice i ON od.invoiceID = i.invoiceID
                    JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                    JOIN medicine m ON im.medicineID = m.medicineID 
                    WHERE od.order_status='refunded' && u.user_role='customer'
                    GROUP BY im.invoiceID
                    UNION
                    SELECT cp.orderID, i.date_time, u.user_ID, GROUP_CONCAT(m.name) AS item_names, GROUP_CONCAT(im.quantity) AS quantities, GROUP_CONCAT(im.quantity * m.price) AS sub_total, cp.order_status, i.invoiceID
                    FROM customer_prescription cp
                    JOIN users u ON cp.customerID = u.user_ID 
                    JOIN invoice i ON cp.invoiceID = i.invoiceID 
                    JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                    JOIN medicine m ON im.medicineID = m.medicineID 
                    WHERE cp.order_status='refunded' && u.user_role='customer'
                    GROUP BY im.invoiceID
                ) AS combined_table
                ORDER BY date_time DESC"
            );


            $row = $this->db->resultSet();
            return $row;
        }





        public function getDeliveryPersons()
        {
            // $this->db->query("SELECT * FROM delivery_guy");
            $this->db->query("SELECT * FROM users where user_role='deliveryperson'");

            $row = $this->db->resultSet();
            return $row;
        }





        public function getDeliveryPersonsFromIndividualTable()
        {
            $this->db->query("SELECT * FROM delivery_person");

            $row = $this->db->resultSet();
            return $row;
        }





        public function getOrderByID($id)
        {
            // $this->db->query("SELECT * FROM order_details WHERE orderID=:orderID");

            // $this->db->query(
            //     "SELECT od.orderID, i.item_name, i.quantity, i.unit_price, i.sub_total 
            //     FROM order_details od
            //     JOIN invoice i ON od.InvoiceID = i.InvoiceID 
            //     WHERE orderID=:orderID"
            // );

            $order_details_table = "order_details";
            $prescription_orders_table = "customer_prescription";
            $table_found = false;

            // Check if order_id exists in order_details table
            $this->db->query("SELECT orderID FROM $order_details_table WHERE orderID = :orderID");
            $this->db->bind(':orderID', $id);
            $order_details_result = $this->db->single();

            if(!empty($order_details_result)) {
                $this->db->query("
                    SELECT od.orderID, GROUP_CONCAT(m.name) AS item_names, GROUP_CONCAT(im.quantity) AS quantities, GROUP_CONCAT(m.price) AS prices, GROUP_CONCAT(im.quantity * m.price) AS sub_totals, GROUP_CONCAT(m.image) AS images, u.address, u.city, u.fName, u.lName, u.email, u.mobile  
                    FROM order_details od
                    JOIN invoice i ON od.invoiceID = i.invoiceID 
                    JOIN invoice_medicine im ON i.invoiceID = im.invoiceID
                    JOIN medicine m ON im.medicineID = m.medicineID
                    JOIN users u ON od.customerID = u.user_ID
                    WHERE od.orderID=:orderID
                    GROUP BY im.invoiceID
                ");
                $table_found = true;
            } else {
                // Check if order_id exists in prescription_orders table
                $this->db->query("SELECT orderID FROM $prescription_orders_table WHERE orderID = :orderID");
                $this->db->bind(':orderID', $id);
                $prescription_orders_result = $this->db->single();

                if(!empty($prescription_orders_result)) {
                    $this->db->query("
                        SELECT cp.orderID, GROUP_CONCAT(m.name) AS item_names, GROUP_CONCAT(im.quantity) AS quantities, GROUP_CONCAT(m.price) AS prices, GROUP_CONCAT(im.quantity * m.price) AS sub_totals, GROUP_CONCAT(m.image) AS images, u.address, u.city, u.fName, u.lName, u.email, u.mobile 
                        FROM customer_prescription cp
                        JOIN invoice i ON cp.invoiceID = i.invoiceID 
                        JOIN invoice_medicine im ON i.invoiceID = im.invoiceID
                        JOIN medicine m ON im.medicineID = m.medicineID
                        JOIN users u ON cp.customerID = u.user_ID
                        WHERE cp.orderID=:orderID
                        GROUP BY im.invoiceID
                    ");
                    $table_found = true;
                }
            }

            if($table_found) {
                // Bind values
                $this->db->bind(':orderID', $id);
                
                $row = $this->db->single();
                return $row;
            }
        }





        public function updateSalesReport()
        {
            //january
            $this->db->query('
                SELECT SUM(january_sales) as total_january_sales
                FROM (
                    SELECT SUM(im.quantity * m.price) as january_sales
                    FROM order_details od 
                    JOIN invoice i ON od.invoiceID = i.invoiceID 
                    JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                    JOIN medicine m ON im.medicineID = m.medicineID 
                    WHERE 
                        MONTH(i.date_time) = 1 
                        AND YEAR(i.date_time) = 2022 
                        AND od.order_status = "completed"
                    
                    UNION ALL
                    
                    SELECT SUM(im.quantity * m.price) as january_sales
                    FROM customer_prescription cp 
                    JOIN invoice i ON cp.invoiceID = i.invoiceID 
                    JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                    JOIN medicine m ON im.medicineID = m.medicineID 
                    WHERE 
                        MONTH(i.date_time) = 1 
                        AND YEAR(i.date_time) = 2022 
                        AND cp.order_status = "completed"
                ) as january_sales_combined;
            ');
            $result = $this->db->single();
            $january_sales = $result->total_january_sales;

            //february
            $this->db->query('
                SELECT SUM(february_sales) as total_february_sales
                FROM (
                    SELECT SUM(im.quantity * m.price) as february_sales
                    FROM order_details od 
                    JOIN invoice i ON od.invoiceID = i.invoiceID 
                    JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                    JOIN medicine m ON im.medicineID = m.medicineID 
                    WHERE 
                        MONTH(i.date_time) = 2 
                        AND YEAR(i.date_time) = 2022 
                        AND od.order_status = "completed"
                    
                    UNION ALL
                    
                    SELECT SUM(im.quantity * m.price) as february_sales
                    FROM customer_prescription cp 
                    JOIN invoice i ON cp.invoiceID = i.invoiceID 
                    JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                    JOIN medicine m ON im.medicineID = m.medicineID 
                    WHERE 
                        MONTH(i.date_time) = 2 
                        AND YEAR(i.date_time) = 2022 
                        AND cp.order_status = "completed"
                ) as february_sales_combined;
            ');
            $result = $this->db->single();
            $february_sales = $result->total_february_sales;

            //march
            $this->db->query('
                SELECT SUM(march_sales) as total_march_sales
                FROM (
                    SELECT SUM(im.quantity * m.price) as march_sales
                    FROM order_details od 
                    JOIN invoice i ON od.invoiceID = i.invoiceID 
                    JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                    JOIN medicine m ON im.medicineID = m.medicineID 
                    WHERE 
                        MONTH(i.date_time) = 3 
                        AND YEAR(i.date_time) = 2022 
                        AND od.order_status = "completed"
                    
                    UNION ALL
                    
                    SELECT SUM(im.quantity * m.price) as march_sales
                    FROM customer_prescription cp 
                    JOIN invoice i ON cp.invoiceID = i.invoiceID 
                    JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                    JOIN medicine m ON im.medicineID = m.medicineID 
                    WHERE 
                        MONTH(i.date_time) = 3 
                        AND YEAR(i.date_time) = 2022 
                        AND cp.order_status = "completed"
                ) as march_sales_combined;
            ');
            $result = $this->db->single();
            $march_sales = $result->total_march_sales;

            //april
            $this->db->query('
                SELECT SUM(april_sales) as total_april_sales
                FROM (
                    SELECT SUM(im.quantity * m.price) as april_sales
                    FROM order_details od 
                    JOIN invoice i ON od.invoiceID = i.invoiceID 
                    JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                    JOIN medicine m ON im.medicineID = m.medicineID 
                    WHERE 
                        MONTH(i.date_time) = 4 
                        AND YEAR(i.date_time) = 2022 
                        AND od.order_status = "completed"
                    
                    UNION ALL
                    
                    SELECT SUM(im.quantity * m.price) as april_sales
                    FROM customer_prescription cp 
                    JOIN invoice i ON cp.invoiceID = i.invoiceID 
                    JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                    JOIN medicine m ON im.medicineID = m.medicineID 
                    WHERE 
                        MONTH(i.date_time) = 4 
                        AND YEAR(i.date_time) = 2022 
                        AND cp.order_status = "completed"
                ) as april_sales_combined;
            ');
            $result = $this->db->single();
            $april_sales = $result->total_april_sales;

            //may
            $this->db->query('
                SELECT SUM(may_sales) as total_may_sales
                FROM (
                    SELECT SUM(im.quantity * m.price) as may_sales
                    FROM order_details od 
                    JOIN invoice i ON od.invoiceID = i.invoiceID 
                    JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                    JOIN medicine m ON im.medicineID = m.medicineID 
                    WHERE 
                        MONTH(i.date_time) = 5 
                        AND YEAR(i.date_time) = 2022 
                        AND od.order_status = "completed"
                    
                    UNION ALL
                    
                    SELECT SUM(im.quantity * m.price) as may_sales
                    FROM customer_prescription cp 
                    JOIN invoice i ON cp.invoiceID = i.invoiceID 
                    JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                    JOIN medicine m ON im.medicineID = m.medicineID 
                    WHERE 
                        MONTH(i.date_time) = 5 
                        AND YEAR(i.date_time) = 2022 
                        AND cp.order_status = "completed"
                ) as may_sales_combined;
            ');
            $result = $this->db->single();
            $may_sales = $result->total_may_sales;

            //june
            $this->db->query('
                SELECT SUM(june_sales) as total_june_sales
                FROM (
                    SELECT SUM(im.quantity * m.price) as june_sales
                    FROM order_details od 
                    JOIN invoice i ON od.invoiceID = i.invoiceID 
                    JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                    JOIN medicine m ON im.medicineID = m.medicineID 
                    WHERE 
                        MONTH(i.date_time) = 6 
                        AND YEAR(i.date_time) = 2022 
                        AND od.order_status = "completed"
                    
                    UNION ALL
                    
                    SELECT SUM(im.quantity * m.price) as june_sales
                    FROM customer_prescription cp 
                    JOIN invoice i ON cp.invoiceID = i.invoiceID 
                    JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                    JOIN medicine m ON im.medicineID = m.medicineID 
                    WHERE 
                        MONTH(i.date_time) = 6 
                        AND YEAR(i.date_time) = 2022 
                        AND cp.order_status = "completed"
                ) as june_sales_combined;
            ');
            $result = $this->db->single();
            $june_sales = $result->total_june_sales;

            //july
            $this->db->query('
                SELECT SUM(july_sales) as total_july_sales
                    FROM (
                        SELECT SUM(im.quantity * m.price) as july_sales
                        FROM order_details od 
                        JOIN invoice i ON od.invoiceID = i.invoiceID 
                        JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                        JOIN medicine m ON im.medicineID = m.medicineID 
                        WHERE 
                            MONTH(i.date_time) = 7 
                            AND YEAR(i.date_time) = 2022 
                            AND od.order_status = "completed"
                        
                        UNION ALL
                        
                        SELECT SUM(im.quantity * m.price) as july_sales
                        FROM customer_prescription cp 
                        JOIN invoice i ON cp.invoiceID = i.invoiceID 
                        JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                        JOIN medicine m ON im.medicineID = m.medicineID 
                        WHERE 
                            MONTH(i.date_time) = 7 
                            AND YEAR(i.date_time) = 2022 
                            AND cp.order_status = "completed"
                ) as july_sales_combined;
            ');
            $result = $this->db->single();
            $july_sales = $result->total_july_sales;

            //august
            $this->db->query('
                SELECT SUM(august_sales) as total_august_sales
                FROM (
                    SELECT SUM(im.quantity * m.price) as august_sales
                    FROM order_details od 
                    JOIN invoice i ON od.invoiceID = i.invoiceID 
                    JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                    JOIN medicine m ON im.medicineID = m.medicineID 
                    WHERE 
                        MONTH(i.date_time) = 8 
                        AND YEAR(i.date_time) = 2022 
                        AND od.order_status = "completed"
                    
                    UNION ALL
                    
                    SELECT SUM(im.quantity * m.price) as august_sales
                    FROM customer_prescription cp 
                    JOIN invoice i ON cp.invoiceID = i.invoiceID 
                    JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                    JOIN medicine m ON im.medicineID = m.medicineID 
                    WHERE 
                        MONTH(i.date_time) = 8 
                        AND YEAR(i.date_time) = 2022 
                        AND cp.order_status = "completed"
                ) as august_sales_combined;
            ');
            $result = $this->db->single();
            $august_sales = $result->total_august_sales;

            //september
            $this->db->query('
                SELECT SUM(september_sales) as total_september_sales
                FROM (
                    SELECT SUM(im.quantity * m.price) as september_sales
                    FROM order_details od 
                    JOIN invoice i ON od.invoiceID = i.invoiceID 
                    JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                    JOIN medicine m ON im.medicineID = m.medicineID 
                    WHERE 
                        MONTH(i.date_time) = 9 
                        AND YEAR(i.date_time) = 2022 
                        AND od.order_status = "completed"
                    
                    UNION ALL
                    
                    SELECT SUM(im.quantity * m.price) as september_sales
                    FROM customer_prescription cp 
                    JOIN invoice i ON cp.invoiceID = i.invoiceID 
                    JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                    JOIN medicine m ON im.medicineID = m.medicineID 
                    WHERE 
                        MONTH(i.date_time) = 9 
                        AND YEAR(i.date_time) = 2022 
                        AND cp.order_status = "completed"
                ) as september_sales_combined;
            ');
            $result = $this->db->single();
            $september_sales = $result->total_september_sales;

            //october
            $this->db->query('
                SELECT SUM(october_sales) as total_october_sales
                FROM (
                    SELECT SUM(im.quantity * m.price) as october_sales
                    FROM order_details od 
                    JOIN invoice i ON od.invoiceID = i.invoiceID 
                    JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                    JOIN medicine m ON im.medicineID = m.medicineID 
                    WHERE 
                        MONTH(i.date_time) = 10 
                        AND YEAR(i.date_time) = 2022 
                        AND od.order_status = "completed"
                    
                    UNION ALL
                    
                    SELECT SUM(im.quantity * m.price) as october_sales
                    FROM customer_prescription cp 
                    JOIN invoice i ON cp.invoiceID = i.invoiceID 
                    JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                    JOIN medicine m ON im.medicineID = m.medicineID 
                    WHERE 
                        MONTH(i.date_time) = 10 
                        AND YEAR(i.date_time) = 2022 
                        AND cp.order_status = "completed"
                ) as october_sales_combined;
            ');
            $result = $this->db->single();
            $october_sales = $result->total_october_sales;

            //november
            $this->db->query('
                SELECT SUM(november_sales) as total_november_sales
                FROM (
                    SELECT SUM(im.quantity * m.price) as november_sales
                    FROM order_details od 
                    JOIN invoice i ON od.invoiceID = i.invoiceID 
                    JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                    JOIN medicine m ON im.medicineID = m.medicineID 
                    WHERE 
                        MONTH(i.date_time) = 11 
                        AND YEAR(i.date_time) = 2022 
                        AND od.order_status = "completed"
                    
                    UNION ALL
                    
                    SELECT SUM(im.quantity * m.price) as november_sales
                    FROM customer_prescription cp 
                    JOIN invoice i ON cp.invoiceID = i.invoiceID 
                    JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                    JOIN medicine m ON im.medicineID = m.medicineID 
                    WHERE 
                        MONTH(i.date_time) = 11 
                        AND YEAR(i.date_time) = 2022 
                        AND cp.order_status = "completed"
                ) as november_sales_combined;
            ');
            $result = $this->db->single();
            $november_sales = $result->total_november_sales;

            //december
            $this->db->query('
                SELECT SUM(december_sales) as total_december_sales
                FROM (
                    SELECT SUM(im.quantity * m.price) as december_sales
                    FROM order_details od 
                    JOIN invoice i ON od.invoiceID = i.invoiceID 
                    JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                    JOIN medicine m ON im.medicineID = m.medicineID 
                    WHERE 
                        MONTH(i.date_time) = 12 
                        AND YEAR(i.date_time) = 2022 
                        AND od.order_status = "completed"
                    
                    UNION ALL
                    
                    SELECT SUM(im.quantity * m.price) as december_sales
                    FROM customer_prescription cp 
                    JOIN invoice i ON cp.invoiceID = i.invoiceID 
                    JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                    JOIN medicine m ON im.medicineID = m.medicineID 
                    WHERE 
                        MONTH(i.date_time) = 12 
                        AND YEAR(i.date_time) = 2022 
                        AND cp.order_status = "completed"
                ) as december_sales_combined;
            ');
            $result = $this->db->single();
            $december_sales = $result->total_december_sales;


            // $this->db->query('
            //                 UPDATE sales_report  
            //                 SET amount = 
            //                     CASE 
            //                         WHEN month = "January" THEN :january
            //                         WHEN month = "February" THEN :february
            //                         WHEN month = "March" THEN :march
            //                         WHEN month = "April" THEN :april
            //                         WHEN month = "May" THEN :may
            //                         WHEN month = "June" THEN :june
            //                         WHEN month = "July" THEN :july
            //                         WHEN month = "August" THEN :august
            //                         WHEN month = "September" THEN :september
            //                         WHEN month = "October" THEN :october
            //                         WHEN month = "November" THEN :november
            //                         WHEN month = "December" THEN :december
            //                     END
            //                 ');

            // $this->db->bind(':january', $january_sales);
            // $this->db->bind(':february', $february_sales);
            // $this->db->bind(':march', $march_sales);
            // $this->db->bind(':april', $april_sales);
            // $this->db->bind(':may', $may_sales);
            // $this->db->bind(':june', $june_sales);
            // $this->db->bind(':july', $july_sales);
            // $this->db->bind(':august', $august_sales);
            // $this->db->bind(':september', $september_sales);
            // $this->db->bind(':october', $october_sales);
            // $this->db->bind(':november', $november_sales);
            // $this->db->bind(':december', $december_sales);

            $sales_array = array($january_sales, $february_sales, $march_sales, $april_sales, $may_sales, $june_sales, $july_sales, $august_sales, $september_sales, $october_sales, $november_sales, $december_sales);

            // Execute
            if($this->db->execute()){
                return $sales_array;
            } else {
            return false;
            }
        }



        

        public function updateSalesLocation()
        {
            //colombo01
            $this->db->query('
            SELECT SUM(colombo01_sales) as total_colombo01_sales
            FROM (
                SELECT SUM(im.quantity * m.price) as colombo01_sales
                FROM order_details od 
                JOIN users u ON od.customerID = u.user_ID
                JOIN invoice i ON od.invoiceID = i.invoiceID 
                JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                JOIN medicine m ON im.medicineID = m.medicineID

                WHERE 
                    u.city="colombo 01" 
                    AND YEAR(i.date_time) = 2022 
                    AND od.order_status = "completed"
                
                UNION ALL
                
                SELECT SUM(im.quantity * m.price) as colombo01_sales
                FROM customer_prescription cp 
                JOIN users u ON cp.customerID = u.user_ID
                JOIN invoice i ON cp.invoiceID = i.invoiceID 
                JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                JOIN medicine m ON im.medicineID = m.medicineID 
                WHERE 
                    u.city="colombo 01" 
                    AND YEAR(i.date_time) = 2022 
                    AND cp.order_status = "completed"
            ) as colombo01_sales_combined;
            ');
            $result = $this->db->single();
            $colombo01_sales = $result->total_colombo01_sales;

            //colombo02
            $this->db->query('
            SELECT SUM(colombo02_sales) as total_colombo02_sales
            FROM (
                SELECT SUM(im.quantity * m.price) as colombo02_sales
                FROM order_details od 
                JOIN users u ON od.customerID = u.user_ID
                JOIN invoice i ON od.invoiceID = i.invoiceID 
                JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                JOIN medicine m ON im.medicineID = m.medicineID 
                WHERE 
                    u.city="colombo 02" 
                    AND YEAR(i.date_time) = 2022 
                    AND od.order_status = "completed"
                
                UNION ALL
                
                SELECT SUM(im.quantity * m.price) as colombo02_sales
                FROM customer_prescription cp 
                JOIN users u ON cp.customerID = u.user_ID
                JOIN invoice i ON cp.invoiceID = i.invoiceID 
                JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                JOIN medicine m ON im.medicineID = m.medicineID 
                WHERE 
                    u.city="colombo 02" 
                    AND YEAR(i.date_time) = 2022 
                    AND cp.order_status = "completed"
            ) as colombo02_sales_combined;
            ');
            $result = $this->db->single();
            $colombo02_sales = $result->total_colombo02_sales;

            //colombo03
            $this->db->query('
            SELECT SUM(colombo03_sales) as total_colombo03_sales
            FROM (
                SELECT SUM(im.quantity * m.price) as colombo03_sales
                FROM order_details od 
                JOIN users u ON od.customerID = u.user_ID
                JOIN invoice i ON od.invoiceID = i.invoiceID 
                JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                JOIN medicine m ON im.medicineID = m.medicineID 
                WHERE 
                    u.city="colombo 03" 
                    AND YEAR(i.date_time) = 2022 
                    AND od.order_status = "completed"
                
                UNION ALL
                
                SELECT SUM(im.quantity * m.price) as colombo03_sales
                FROM customer_prescription cp 
                JOIN users u ON cp.customerID = u.user_ID
                JOIN invoice i ON cp.invoiceID = i.invoiceID 
                JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                JOIN medicine m ON im.medicineID = m.medicineID 
                WHERE 
                    u.city="colombo 03" 
                    AND YEAR(i.date_time) = 2022 
                    AND cp.order_status = "completed"
            ) as colombo03_sales_combined;
            ');
            $result = $this->db->single();
            $colombo03_sales = $result->total_colombo03_sales;

            //colombo04
            $this->db->query('
            SELECT SUM(colombo04_sales) as total_colombo04_sales
            FROM (
                SELECT SUM(im.quantity * m.price) as colombo04_sales
                FROM order_details od 
                JOIN users u ON od.customerID = u.user_ID
                JOIN invoice i ON od.invoiceID = i.invoiceID 
                JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                JOIN medicine m ON im.medicineID = m.medicineID 
                WHERE 
                    u.city="colombo 04" 
                    AND YEAR(i.date_time) = 2022 
                    AND od.order_status = "completed"
                
                UNION ALL
                
                SELECT SUM(im.quantity * m.price) as colombo04_sales
                FROM customer_prescription cp 
                JOIN users u ON cp.customerID = u.user_ID
                JOIN invoice i ON cp.invoiceID = i.invoiceID 
                JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                JOIN medicine m ON im.medicineID = m.medicineID 
                WHERE 
                    u.city="colombo 04" 
                    AND YEAR(i.date_time) = 2022 
                    AND cp.order_status = "completed"
            ) as colombo04_sales_combined;
            ');
            $result = $this->db->single();
            $colombo04_sales = $result->total_colombo04_sales;

            //colombo05
            $this->db->query('
            SELECT SUM(colombo05_sales) as total_colombo05_sales
            FROM (
                SELECT SUM(im.quantity * m.price) as colombo05_sales
                FROM order_details od 
                JOIN users u ON od.customerID = u.user_ID
                JOIN invoice i ON od.invoiceID = i.invoiceID 
                JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                JOIN medicine m ON im.medicineID = m.medicineID 
                WHERE 
                    u.city="colombo 05" 
                    AND YEAR(i.date_time) = 2022 
                    AND od.order_status = "completed"
                
                UNION ALL
                
                SELECT SUM(im.quantity * m.price) as colombo05_sales
                FROM customer_prescription cp 
                JOIN users u ON cp.customerID = u.user_ID
                JOIN invoice i ON cp.invoiceID = i.invoiceID 
                JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                JOIN medicine m ON im.medicineID = m.medicineID 
                WHERE 
                    u.city="colombo 05"  
                    AND YEAR(i.date_time) = 2022 
                    AND cp.order_status = "completed"
            ) as colombo05_sales_combined;
            ');
            $result = $this->db->single();
            $colombo05_sales = $result->total_colombo05_sales;

            //colombo06
            $this->db->query('
            SELECT SUM(colombo06_sales) as total_colombo06_sales
            FROM (
                SELECT SUM(im.quantity * m.price) as colombo06_sales
                FROM order_details od 
                JOIN users u ON od.customerID = u.user_ID
                JOIN invoice i ON od.invoiceID = i.invoiceID 
                JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                JOIN medicine m ON im.medicineID = m.medicineID 
                WHERE 
                    u.city="colombo 06"  
                    AND YEAR(i.date_time) = 2022 
                    AND od.order_status = "completed"
                
                UNION ALL
                
                SELECT SUM(im.quantity * m.price) as colombo06_sales
                FROM customer_prescription cp 
                JOIN users u ON cp.customerID = u.user_ID
                JOIN invoice i ON cp.invoiceID = i.invoiceID 
                JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                JOIN medicine m ON im.medicineID = m.medicineID 
                WHERE 
                    u.city="colombo 06"  
                    AND YEAR(i.date_time) = 2022 
                    AND cp.order_status = "completed"
            ) as colombo06_sales_combined;
            ');
            $result = $this->db->single();
            $colombo06_sales = $result->total_colombo06_sales;

            //colombo07
            $this->db->query('
            SELECT SUM(colombo07_sales) as total_colombo07_sales
                FROM (
                    SELECT SUM(im.quantity * m.price) as colombo07_sales
                    FROM order_details od 
                    JOIN users u ON od.customerID = u.user_ID
                    JOIN invoice i ON od.invoiceID = i.invoiceID 
                    JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                    JOIN medicine m ON im.medicineID = m.medicineID 
                    WHERE 
                        u.city="colombo 07" 
                        AND YEAR(i.date_time) = 2022 
                        AND od.order_status = "completed"
                    
                    UNION ALL
                    
                    SELECT SUM(im.quantity * m.price) as colombo07_sales
                    FROM customer_prescription cp 
                    JOIN users u ON cp.customerID = u.user_ID
                    JOIN invoice i ON cp.invoiceID = i.invoiceID 
                    JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                    JOIN medicine m ON im.medicineID = m.medicineID 
                    WHERE 
                        u.city="colombo 07" 
                        AND YEAR(i.date_time) = 2022 
                        AND cp.order_status = "completed"
            ) as colombo07_sales_combined;
            ');
            $result = $this->db->single();
            $colombo07_sales = $result->total_colombo07_sales;

            //colombo08
            $this->db->query('
            SELECT SUM(colombo08_sales) as total_colombo08_sales
            FROM (
                SELECT SUM(im.quantity * m.price) as colombo08_sales
                FROM order_details od 
                JOIN users u ON od.customerID = u.user_ID
                JOIN invoice i ON od.invoiceID = i.invoiceID 
                JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                JOIN medicine m ON im.medicineID = m.medicineID 
                WHERE 
                    u.city="colombo 08" 
                    AND YEAR(i.date_time) = 2022 
                    AND od.order_status = "completed"
                
                UNION ALL
                
                SELECT SUM(im.quantity * m.price) as colombo08_sales
                FROM customer_prescription cp 
                JOIN users u ON cp.customerID = u.user_ID
                JOIN invoice i ON cp.invoiceID = i.invoiceID 
                JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                JOIN medicine m ON im.medicineID = m.medicineID 
                WHERE 
                    u.city="colombo 08" 
                    AND YEAR(i.date_time) = 2022 
                    AND cp.order_status = "completed"
            ) as colombo08_sales_combined;
            ');
            $result = $this->db->single();
            $colombo08_sales = $result->total_colombo08_sales;

            //colombo09
            $this->db->query('
            SELECT SUM(colombo09_sales) as total_colombo09_sales
            FROM (
                SELECT SUM(im.quantity * m.price) as colombo09_sales
                FROM order_details od 
                JOIN users u ON od.customerID = u.user_ID
                JOIN invoice i ON od.invoiceID = i.invoiceID 
                JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                JOIN medicine m ON im.medicineID = m.medicineID 
                WHERE 
                    u.city="colombo 09" 
                    AND YEAR(i.date_time) = 2022 
                    AND od.order_status = "completed"
                
                UNION ALL
                
                SELECT SUM(im.quantity * m.price) as colombo09_sales
                FROM customer_prescription cp 
                JOIN users u ON cp.customerID = u.user_ID
                JOIN invoice i ON cp.invoiceID = i.invoiceID 
                JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                JOIN medicine m ON im.medicineID = m.medicineID 
                WHERE 
                    u.city="colombo 09" 
                    AND YEAR(i.date_time) = 2022 
                    AND cp.order_status = "completed"
            ) as colombo09_sales_combined;
            ');
            $result = $this->db->single();
            $colombo09_sales = $result->total_colombo09_sales;

            //colombo10
            $this->db->query('
            SELECT SUM(colombo10_sales) as total_colombo10_sales
            FROM (
                SELECT SUM(im.quantity * m.price) as colombo10_sales
                FROM order_details od 
                JOIN users u ON od.customerID = u.user_ID
                JOIN invoice i ON od.invoiceID = i.invoiceID 
                JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                JOIN medicine m ON im.medicineID = m.medicineID 
                WHERE 
                    u.city="colombo 10" 
                    AND YEAR(i.date_time) = 2022 
                    AND od.order_status = "completed"
                
                UNION ALL
                
                SELECT SUM(im.quantity * m.price) as colombo10_sales
                FROM customer_prescription cp 
                JOIN users u ON cp.customerID = u.user_ID
                JOIN invoice i ON cp.invoiceID = i.invoiceID 
                JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                JOIN medicine m ON im.medicineID = m.medicineID 
                WHERE 
                    u.city="colombo 10" 
                    AND YEAR(i.date_time) = 2022 
                    AND cp.order_status = "completed"
            ) as colombo10_sales_combined;
            ');
            $result = $this->db->single();
            $colombo10_sales = $result->total_colombo10_sales;

            //colombo11
            $this->db->query('
            SELECT SUM(colombo11_sales) as total_colombo11_sales
            FROM (
                SELECT SUM(im.quantity * m.price) as colombo11_sales
                FROM order_details od 
                JOIN users u ON od.customerID = u.user_ID
                JOIN invoice i ON od.invoiceID = i.invoiceID 
                JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                JOIN medicine m ON im.medicineID = m.medicineID 
                WHERE 
                    u.city="colombo 11" 
                    AND YEAR(i.date_time) = 2022 
                    AND od.order_status = "completed"
                
                UNION ALL
                
                SELECT SUM(im.quantity * m.price) as colombo11_sales
                FROM customer_prescription cp 
                JOIN users u ON cp.customerID = u.user_ID
                JOIN invoice i ON cp.invoiceID = i.invoiceID 
                JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                JOIN medicine m ON im.medicineID = m.medicineID 
                WHERE 
                    u.city="colombo 11"  
                    AND YEAR(i.date_time) = 2022 
                    AND cp.order_status = "completed"
            ) as colombo11_sales_combined;
            ');
            $result = $this->db->single();
            $colombo11_sales = $result->total_colombo11_sales;

            //colombo12
            $this->db->query('
            SELECT SUM(colombo12_sales) as total_colombo12_sales
            FROM (
                SELECT SUM(im.quantity * m.price) as colombo12_sales
                FROM order_details od 
                JOIN users u ON od.customerID = u.user_ID
                JOIN invoice i ON od.invoiceID = i.invoiceID 
                JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                JOIN medicine m ON im.medicineID = m.medicineID 
                WHERE 
                    u.city="colombo 12"  
                    AND YEAR(i.date_time) = 2022 
                    AND od.order_status = "completed"
                
                UNION ALL
                
                SELECT SUM(im.quantity * m.price) as colombo12_sales
                FROM customer_prescription cp 
                JOIN users u ON cp.customerID = u.user_ID
                JOIN invoice i ON cp.invoiceID = i.invoiceID 
                JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                JOIN medicine m ON im.medicineID = m.medicineID 
                WHERE 
                    u.city="colombo 12" 
                    AND YEAR(i.date_time) = 2022 
                    AND cp.order_status = "completed"
            ) as colombo12_sales_combined;
            ');
            $result = $this->db->single();
            $colombo12_sales = $result->total_colombo12_sales;

            //colombo13
            $this->db->query('
            SELECT SUM(colombo13_sales) as total_colombo13_sales
            FROM (
                SELECT SUM(im.quantity * m.price) as colombo13_sales
                FROM order_details od 
                JOIN users u ON od.customerID = u.user_ID
                JOIN invoice i ON od.invoiceID = i.invoiceID 
                JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                JOIN medicine m ON im.medicineID = m.medicineID 
                WHERE 
                    u.city="colombo 13" 
                    AND YEAR(i.date_time) = 2022 
                    AND od.order_status = "completed"
                
                UNION ALL
                
                SELECT SUM(im.quantity * m.price) as colombo13_sales
                FROM customer_prescription cp 
                JOIN users u ON cp.customerID = u.user_ID
                JOIN invoice i ON cp.invoiceID = i.invoiceID 
                JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                JOIN medicine m ON im.medicineID = m.medicineID 
                WHERE 
                    u.city="colombo 13" 
                    AND YEAR(i.date_time) = 2022 
                    AND cp.order_status = "completed"
            ) as colombo13_sales_combined;
            ');
            $result = $this->db->single();
            $colombo13_sales = $result->total_colombo13_sales;

            //colombo14
            $this->db->query('
            SELECT SUM(colombo14_sales) as total_colombo14_sales
            FROM (
                SELECT SUM(im.quantity * m.price) as colombo14_sales
                FROM order_details od 
                JOIN users u ON od.customerID = u.user_ID
                JOIN invoice i ON od.invoiceID = i.invoiceID 
                JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                JOIN medicine m ON im.medicineID = m.medicineID 
                WHERE 
                    u.city="colombo 14" 
                    AND YEAR(i.date_time) = 2022 
                    AND od.order_status = "completed"
                
                UNION ALL
                
                SELECT SUM(im.quantity * m.price) as colombo14_sales
                FROM customer_prescription cp 
                JOIN users u ON cp.customerID = u.user_ID
                JOIN invoice i ON cp.invoiceID = i.invoiceID 
                JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                JOIN medicine m ON im.medicineID = m.medicineID 
                WHERE 
                    u.city="colombo 14" 
                    AND YEAR(i.date_time) = 2022 
                    AND cp.order_status = "completed"
            ) as colombo14_sales_combined;
            ');
            $result = $this->db->single();
            $colombo14_sales = $result->total_colombo14_sales;

            //colombo15
            $this->db->query('
            SELECT SUM(colombo15_sales) as total_colombo15_sales
            FROM (
                SELECT SUM(im.quantity * m.price) as colombo15_sales
                FROM order_details od 
                JOIN users u ON od.customerID = u.user_ID
                JOIN invoice i ON od.invoiceID = i.invoiceID 
                JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                JOIN medicine m ON im.medicineID = m.medicineID 
                WHERE 
                    u.city="colombo 15" 
                    AND YEAR(i.date_time) = 2022 
                    AND od.order_status = "completed"
                
                UNION ALL
                
                SELECT SUM(im.quantity * m.price) as colombo15_sales
                FROM customer_prescription cp 
                JOIN users u ON cp.customerID = u.user_ID
                JOIN invoice i ON cp.invoiceID = i.invoiceID 
                JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                JOIN medicine m ON im.medicineID = m.medicineID 
                WHERE 
                    u.city="colombo 15"  
                    AND YEAR(i.date_time) = 2022 
                    AND cp.order_status = "completed"
            ) as colombo15_sales_combined;
            ');
            $result = $this->db->single();
            $colombo15_sales = $result->total_colombo15_sales;



            // $this->db->query('
            //             UPDATE sales_location  
            //             SET amount = 
            //                 CASE 
            //                     WHEN location = "colombo 01" THEN :colombo01
            //                     WHEN location = "colombo 02" THEN :colombo02
            //                     WHEN location = "colombo 03" THEN :colombo03
            //                     WHEN location = "colombo 04" THEN :colombo04
            //                     WHEN location = "colombo 05" THEN :colombo05
            //                     WHEN location = "colombo 06" THEN :colombo06
            //                     WHEN location = "colombo 07" THEN :colombo07
            //                     WHEN location = "colombo 08" THEN :colombo08
            //                     WHEN location = "colombo 09" THEN :colombo09
            //                     WHEN location = "colombo 10" THEN :colombo10
            //                     WHEN location = "colombo 11" THEN :colombo11
            //                     WHEN location = "colombo 12" THEN :colombo12
            //                     WHEN location = "colombo 13" THEN :colombo13
            //                     WHEN location = "colombo 14" THEN :colombo14
            //                     WHEN location = "colombo 15" THEN :colombo15
            //                 END
            //             ');

            // $this->db->bind(':colombo01', $colombo01_sales);
            // $this->db->bind(':colombo02', $colombo02_sales);
            // $this->db->bind(':colombo03', $colombo03_sales);
            // $this->db->bind(':colombo04', $colombo04_sales);
            // $this->db->bind(':colombo05', $colombo05_sales);
            // $this->db->bind(':colombo06', $colombo06_sales);
            // $this->db->bind(':colombo07', $colombo07_sales);
            // $this->db->bind(':colombo08', $colombo08_sales);
            // $this->db->bind(':colombo09', $colombo09_sales);
            // $this->db->bind(':colombo10', $colombo10_sales);
            // $this->db->bind(':colombo11', $colombo11_sales);
            // $this->db->bind(':colombo12', $colombo12_sales);
            // $this->db->bind(':colombo13', $colombo13_sales);
            // $this->db->bind(':colombo14', $colombo14_sales);
            // $this->db->bind(':colombo15', $colombo15_sales);

            $sales_location_array = array($colombo01_sales, $colombo02_sales, $colombo03_sales, $colombo04_sales, $colombo05_sales, $colombo06_sales, $colombo07_sales, $colombo08_sales, $colombo09_sales, $colombo10_sales, $colombo11_sales, $colombo12_sales, $colombo13_sales, $colombo14_sales, $colombo15_sales);

            // Execute
            if($this->db->execute()){
            return $sales_location_array;
            } else {
            return false;
            }
        }





        public function updateSalesCategory()
        {
            //medicine
            $this->db->query('
            SELECT SUM(medicine_sales) as total_medicine_sales
            FROM (
                SELECT SUM(im.quantity * m.price) as medicine_sales
                FROM order_details od 
                JOIN invoice i ON od.invoiceID = i.invoiceID 
                JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                JOIN medicine m ON im.medicineID = m.medicineID

                WHERE 
                    m.medicine_type1="medicine"
                    AND YEAR(i.date_time) = 2022 
                    AND od.order_status = "completed"
                
                UNION ALL
                
                SELECT SUM(im.quantity * m.price) as medicine_sales
                FROM customer_prescription cp 
                JOIN invoice i ON cp.invoiceID = i.invoiceID 
                JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                JOIN medicine m ON im.medicineID = m.medicineID 
                WHERE 
                    m.medicine_type1="medicine" 
                    AND YEAR(i.date_time) = 2022 
                    AND cp.order_status = "completed"
            ) as colombo01_sales_combined;
            ');
            $result = $this->db->single();
            $medicine_sales = $result->total_medicine_sales;

            //medical devices
            $this->db->query('
            SELECT SUM(medical_devices_sales) as total_medical_devices_sales
            FROM (
                SELECT SUM(im.quantity * m.price) as medical_devices_sales
                FROM order_details od 
                JOIN invoice i ON od.invoiceID = i.invoiceID 
                JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                JOIN medicine m ON im.medicineID = m.medicineID 
                WHERE 
                    m.medicine_type1="medical devices"  
                    AND YEAR(i.date_time) = 2022 
                    AND od.order_status = "completed"
                
                UNION ALL
                
                SELECT SUM(im.quantity * m.price) as medical_devices_sales
                FROM customer_prescription cp 
                JOIN invoice i ON cp.invoiceID = i.invoiceID 
                JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                JOIN medicine m ON im.medicineID = m.medicineID 
                WHERE 
                    m.medicine_type1="medical devices" 
                    AND YEAR(i.date_time) = 2022 
                    AND cp.order_status = "completed"
            ) as colombo02_sales_combined;
            ');
            $result = $this->db->single();
            $medical_devices_sales = $result->total_medical_devices_sales;

            //personal care
            $this->db->query('
            SELECT SUM(personal_care_sales) as total_personal_care_sales
            FROM (
                SELECT SUM(im.quantity * m.price) as personal_care_sales
                FROM order_details od 
                JOIN invoice i ON od.invoiceID = i.invoiceID 
                JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                JOIN medicine m ON im.medicineID = m.medicineID 
                WHERE 
                    m.medicine_type1="personal care"
                    AND YEAR(i.date_time) = 2022 
                    AND od.order_status = "completed"
                
                UNION ALL
                
                SELECT SUM(im.quantity * m.price) as personal_care_sales
                FROM customer_prescription cp 
                JOIN invoice i ON cp.invoiceID = i.invoiceID 
                JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                JOIN medicine m ON im.medicineID = m.medicineID 
                WHERE 
                    m.medicine_type1="personal care"
                    AND YEAR(i.date_time) = 2022 
                    AND cp.order_status = "completed"
            ) as personal_care_sales_combined;
            ');
            $result = $this->db->single();
            $personal_care_sales = $result->total_personal_care_sales;



            //medicine heart
            $this->db->query('
            SELECT SUM(medicine_heart_sales) as total_medicine_heart_sales
            FROM (
                SELECT SUM(im.quantity * m.price) as medicine_heart_sales
                FROM order_details od 
                JOIN invoice i ON od.invoiceID = i.invoiceID 
                JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                JOIN medicine m ON im.medicineID = m.medicineID

                WHERE 
                    m.medicine_type1="medicine"
                    AND m.medicine_type2="heart" 
                    AND YEAR(i.date_time) = 2022 
                    AND od.order_status = "completed"
                
                UNION ALL
                
                SELECT SUM(im.quantity * m.price) as medicine_heart_sales
                FROM customer_prescription cp 
                JOIN invoice i ON cp.invoiceID = i.invoiceID 
                JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                JOIN medicine m ON im.medicineID = m.medicineID 
                WHERE 
                    m.medicine_type1="medicine" 
                    AND m.medicine_type2="heart" 
                    AND YEAR(i.date_time) = 2022 
                    AND cp.order_status = "completed"
            ) as medicine_heart_sales_combined;
            ');
            $result = $this->db->single();
            $medicine_heart_sales = $result->total_medicine_heart_sales;


            //medicine diabetes
            $this->db->query('
            SELECT SUM(medicine_diabetes_sales) as total_medicine_diabetes_sales
            FROM (
                SELECT SUM(im.quantity * m.price) as medicine_diabetes_sales
                FROM order_details od 
                JOIN invoice i ON od.invoiceID = i.invoiceID 
                JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                JOIN medicine m ON im.medicineID = m.medicineID

                WHERE 
                    m.medicine_type1="medicine"
                    AND m.medicine_type2="diabetes" 
                    AND YEAR(i.date_time) = 2022 
                    AND od.order_status = "completed"
                
                UNION ALL
                
                SELECT SUM(im.quantity * m.price) as medicine_diabetes_sales
                FROM customer_prescription cp 
                JOIN invoice i ON cp.invoiceID = i.invoiceID 
                JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                JOIN medicine m ON im.medicineID = m.medicineID 
                WHERE 
                    m.medicine_type1="medicine" 
                    AND m.medicine_type2="diabetes" 
                    AND YEAR(i.date_time) = 2022 
                    AND cp.order_status = "completed"
            ) as medicine_diabetes_sales_combined;
            ');
            $result = $this->db->single();
            $medicine_diabetes_sales = $result->total_medicine_diabetes_sales;


            //medicine infection
            $this->db->query('
            SELECT SUM(medicine_infection_sales) as total_medicine_infection_sales
            FROM (
                SELECT SUM(im.quantity * m.price) as medicine_infection_sales
                FROM order_details od 
                JOIN invoice i ON od.invoiceID = i.invoiceID 
                JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                JOIN medicine m ON im.medicineID = m.medicineID

                WHERE 
                    m.medicine_type1="medicine"
                    AND m.medicine_type2="infection" 
                    AND YEAR(i.date_time) = 2022 
                    AND od.order_status = "completed"
                
                UNION ALL
                
                SELECT SUM(im.quantity * m.price) as medicine_infection_sales
                FROM customer_prescription cp 
                JOIN invoice i ON cp.invoiceID = i.invoiceID 
                JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                JOIN medicine m ON im.medicineID = m.medicineID 
                WHERE 
                    m.medicine_type1="medicine" 
                    AND m.medicine_type2="infection" 
                    AND YEAR(i.date_time) = 2022 
                    AND cp.order_status = "completed"
            ) as medicine_infection_sales_combined;
            ');
            $result = $this->db->single();
            $medicine_infection_sales = $result->total_medicine_infection_sales;


            //medicine gastro
            $this->db->query('
            SELECT SUM(medicine_gastro_sales) as total_medicine_gastro_sales
            FROM (
                SELECT SUM(im.quantity * m.price) as medicine_gastro_sales
                FROM order_details od 
                JOIN invoice i ON od.invoiceID = i.invoiceID 
                JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                JOIN medicine m ON im.medicineID = m.medicineID

                WHERE 
                    m.medicine_type1="medicine"
                    AND m.medicine_type2="gastro" 
                    AND YEAR(i.date_time) = 2022 
                    AND od.order_status = "completed"
                
                UNION ALL
                
                SELECT SUM(im.quantity * m.price) as medicine_gastro_sales
                FROM customer_prescription cp 
                JOIN invoice i ON cp.invoiceID = i.invoiceID 
                JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                JOIN medicine m ON im.medicineID = m.medicineID 
                WHERE 
                    m.medicine_type1="medicine" 
                    AND m.medicine_type2="gastro" 
                    AND YEAR(i.date_time) = 2022 
                    AND cp.order_status = "completed"
            ) as medicine_gastro_sales_combined;
            ');
            $result = $this->db->single();
            $medicine_gastro_sales = $result->total_medicine_gastro_sales;


            //medicine
            $this->db->query('
            SELECT SUM(medicine_muscle_sales) as total_medicine_muscle_sales
            FROM (
                SELECT SUM(im.quantity * m.price) as medicine_muscle_sales
                FROM order_details od 
                JOIN invoice i ON od.invoiceID = i.invoiceID 
                JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                JOIN medicine m ON im.medicineID = m.medicineID

                WHERE 
                    m.medicine_type1="medicine"
                    AND m.medicine_type2="muscle" 
                    AND YEAR(i.date_time) = 2022 
                    AND od.order_status = "completed"
                
                UNION ALL
                
                SELECT SUM(im.quantity * m.price) as medicine_muscle_sales
                FROM customer_prescription cp 
                JOIN invoice i ON cp.invoiceID = i.invoiceID 
                JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                JOIN medicine m ON im.medicineID = m.medicineID 
                WHERE 
                    m.medicine_type1="medicine" 
                    AND m.medicine_type2="muscle" 
                    AND YEAR(i.date_time) = 2022 
                    AND cp.order_status = "completed"
            ) as medicine_heart_sales_combined;
            ');
            $result = $this->db->single();
            $medicine_muscle_sales = $result->total_medicine_muscle_sales;




            //personal care nourishments
            $this->db->query('
            SELECT SUM(personal_care_nourishments_sales) as total_personal_care_nourishments_sales
            FROM (
                SELECT SUM(im.quantity * m.price) as personal_care_nourishments_sales
                FROM order_details od 
                JOIN invoice i ON od.invoiceID = i.invoiceID 
                JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                JOIN medicine m ON im.medicineID = m.medicineID 
                WHERE 
                    m.medicine_type1="personal care"
                    AND m.medicine_type2="nourishments" 
                    AND YEAR(i.date_time) = 2022 
                    AND od.order_status = "completed"
                
                UNION ALL
                
                SELECT SUM(im.quantity * m.price) as personal_care_nourishments_sales
                FROM customer_prescription cp 
                JOIN invoice i ON cp.invoiceID = i.invoiceID 
                JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                JOIN medicine m ON im.medicineID = m.medicineID 
                WHERE 
                    m.medicine_type1="personal care"
                    AND m.medicine_type2="nourishments" 
                    AND YEAR(i.date_time) = 2022 
                    AND cp.order_status = "completed"
            ) as personal_care_nourishments_sales_combined;
            ');
            $result = $this->db->single();
            $personal_care_nourishments_sales = $result->total_personal_care_nourishments_sales;


            //personal care accessories
            $this->db->query('
            SELECT SUM(personal_care_accessories_sales) as total_personal_care_accessories_sales
            FROM (
                SELECT SUM(im.quantity * m.price) as personal_care_accessories_sales
                FROM order_details od 
                JOIN invoice i ON od.invoiceID = i.invoiceID 
                JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                JOIN medicine m ON im.medicineID = m.medicineID 
                WHERE 
                    m.medicine_type1="personal care"
                    AND m.medicine_type2="accessories" 
                    AND YEAR(i.date_time) = 2022 
                    AND od.order_status = "completed"
                
                UNION ALL
                
                SELECT SUM(im.quantity * m.price) as personal_care_accessories_sales
                FROM customer_prescription cp 
                JOIN invoice i ON cp.invoiceID = i.invoiceID 
                JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                JOIN medicine m ON im.medicineID = m.medicineID 
                WHERE 
                    m.medicine_type1="personal care"
                    AND m.medicine_type2="accessories" 
                    AND YEAR(i.date_time) = 2022 
                    AND cp.order_status = "completed"
            ) as personal_care_accessories_sales_combined;
            ');
            $result = $this->db->single();
            $personal_care_accessories_sales = $result->total_personal_care_accessories_sales;


            //personal care skin care
            $this->db->query('
            SELECT SUM(personal_care_skin_care_sales) as total_personal_care_skin_care_sales
            FROM (
                SELECT SUM(im.quantity * m.price) as personal_care_skin_care_sales
                FROM order_details od 
                JOIN invoice i ON od.invoiceID = i.invoiceID 
                JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                JOIN medicine m ON im.medicineID = m.medicineID 
                WHERE 
                    m.medicine_type1="personal care"
                    AND m.medicine_type2="skin care" 
                    AND YEAR(i.date_time) = 2022 
                    AND od.order_status = "completed"
                
                UNION ALL
                
                SELECT SUM(im.quantity * m.price) as personal_care_sales
                FROM customer_prescription cp 
                JOIN invoice i ON cp.invoiceID = i.invoiceID 
                JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                JOIN medicine m ON im.medicineID = m.medicineID 
                WHERE 
                    m.medicine_type1="personal care"
                    AND m.medicine_type2="skin care" 
                    AND YEAR(i.date_time) = 2022 
                    AND cp.order_status = "completed"
            ) as personal_care_skin_care_sales_combined;
            ');
            $result = $this->db->single();
            $personal_care_skin_care_sales = $result->total_personal_care_skin_care_sales;


            //personal care women pc
            $this->db->query('
            SELECT SUM(personal_care_women_pc_sales) as total_personal_care_women_pc_sales
            FROM (
                SELECT SUM(im.quantity * m.price) as personal_care_women_pc_sales
                FROM order_details od 
                JOIN invoice i ON od.invoiceID = i.invoiceID 
                JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                JOIN medicine m ON im.medicineID = m.medicineID 
                WHERE 
                    m.medicine_type1="personal care" 
                    AND m.medicine_type2="women personal care" 
                    AND YEAR(i.date_time) = 2022 
                    AND od.order_status = "completed"
                
                UNION ALL
                
                SELECT SUM(im.quantity * m.price) as personal_care_women_pc_sales
                FROM customer_prescription cp 
                JOIN invoice i ON cp.invoiceID = i.invoiceID 
                JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                JOIN medicine m ON im.medicineID = m.medicineID 
                WHERE 
                    m.medicine_type1="personal care" 
                    AND m.medicine_type2="women personal care" 
                    AND YEAR(i.date_time) = 2022 
                    AND cp.order_status = "completed"
            ) as personal_care_women_pc_sales_combined;
            ');
            $result = $this->db->single();
            $personal_care_women_pc_sales = $result->total_personal_care_women_pc_sales;


            //personal care oral care
            $this->db->query('
            SELECT SUM(personal_care_oral_care_sales) as total_personal_care_oral_care_sales
            FROM (
                SELECT SUM(im.quantity * m.price) as personal_care_oral_care_sales
                FROM order_details od 
                JOIN invoice i ON od.invoiceID = i.invoiceID 
                JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                JOIN medicine m ON im.medicineID = m.medicineID 
                WHERE 
                    m.medicine_type1="personal care" 
                    AND m.medicine_type2="oral care" 
                    AND YEAR(i.date_time) = 2022 
                    AND od.order_status = "completed"
                
                UNION ALL
                
                SELECT SUM(im.quantity * m.price) as personal_care_oral_care_sales
                FROM customer_prescription cp 
                JOIN invoice i ON cp.invoiceID = i.invoiceID 
                JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                JOIN medicine m ON im.medicineID = m.medicineID 
                WHERE 
                    m.medicine_type1="personal care" 
                    AND m.medicine_type2="oral care" 
                    AND YEAR(i.date_time) = 2022 
                    AND cp.order_status = "completed"
            ) as personal_care_oral_care_sales_combined;
            ');
            $result = $this->db->single();
            $personal_care_oral_care_sales = $result->total_personal_care_oral_care_sales;




            //medical devices first aid
            $this->db->query('
            SELECT SUM(medical_devices_first_aid_sales) as total_medical_devices_first_aid_sales
            FROM (
                SELECT SUM(im.quantity * m.price) as medical_devices_first_aid_sales
                FROM order_details od 
                JOIN invoice i ON od.invoiceID = i.invoiceID 
                JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                JOIN medicine m ON im.medicineID = m.medicineID 
                WHERE 
                    m.medicine_type1="medical devices" 
                    AND m.medicine_type2="first aid" 
                    AND YEAR(i.date_time) = 2022 
                    AND od.order_status = "completed"
                
                UNION ALL
                
                SELECT SUM(im.quantity * m.price) as medical_devices_first_aid_sales
                FROM customer_prescription cp 
                JOIN invoice i ON cp.invoiceID = i.invoiceID 
                JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                JOIN medicine m ON im.medicineID = m.medicineID 
                WHERE 
                    m.medicine_type1="medical devices" 
                    AND m.medicine_type2="first aid" 
                    AND YEAR(i.date_time) = 2022 
                    AND cp.order_status = "completed"
            ) as first_aid_sales_combined;
            ');
            $result = $this->db->single();
            $medical_devices_first_aid_sales = $result->total_medical_devices_first_aid_sales;


            //medical devices health device
            $this->db->query('
            SELECT SUM(medical_devices_health_device_sales) as total_medical_devices_health_device_sales
            FROM (
                SELECT SUM(im.quantity * m.price) as medical_devices_health_device_sales
                FROM order_details od 
                JOIN invoice i ON od.invoiceID = i.invoiceID 
                JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                JOIN medicine m ON im.medicineID = m.medicineID 
                WHERE 
                    m.medicine_type1="medical devices" 
                    AND m.medicine_type2="health device" 
                    AND YEAR(i.date_time) = 2022 
                    AND od.order_status = "completed"
                
                UNION ALL
                
                SELECT SUM(im.quantity * m.price) as medical_devices_health_device_sales
                FROM customer_prescription cp 
                JOIN invoice i ON cp.invoiceID = i.invoiceID 
                JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                JOIN medicine m ON im.medicineID = m.medicineID 
                WHERE 
                    m.medicine_type1="medical devices" 
                    AND m.medicine_type2="health device" 
                    AND YEAR(i.date_time) = 2022 
                    AND cp.order_status = "completed"
            ) as health_device_sales_combined;
            ');
            $result = $this->db->single();
            $medical_devices_health_device_sales = $result->total_medical_devices_health_device_sales;


            //medical devices support
            $this->db->query('
            SELECT SUM(medical_devices_support_sales) as total_medical_devices_support_sales
            FROM (
                SELECT SUM(im.quantity * m.price) as medical_devices_support_sales
                FROM order_details od 
                JOIN invoice i ON od.invoiceID = i.invoiceID 
                JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                JOIN medicine m ON im.medicineID = m.medicineID 
                WHERE 
                    m.medicine_type1="medical devices" 
                    AND m.medicine_type2="support" 
                    AND YEAR(i.date_time) = 2022 
                    AND od.order_status = "completed"
                
                UNION ALL
                
                SELECT SUM(im.quantity * m.price) as medical_devices_support_sales
                FROM customer_prescription cp 
                JOIN invoice i ON cp.invoiceID = i.invoiceID 
                JOIN invoice_medicine im ON i.invoiceID = im.invoiceID 
                JOIN medicine m ON im.medicineID = m.medicineID 
                WHERE 
                    m.medicine_type1="medical devices" 
                    AND m.medicine_type2="support" 
                    AND YEAR(i.date_time) = 2022 
                    AND cp.order_status = "completed"
            ) as support_sales_combined;
            ');
            $result = $this->db->single();
            $medical_devices_support_sales = $result->total_medical_devices_support_sales;




            // $this->db->query('
            //             UPDATE sales_category  
            //             SET amount = 
            //                 CASE 
            //                     WHEN medicine_type1 = "medicine" THEN :medicine
            //                     WHEN medicine_type1 = "medical devices" THEN :medical_devices
            //                     WHEN medicine_type1 = "personal care" THEN :personal_care
            //                 END
            //             ');

            // $this->db->bind(':medicine', $medicine_sales);
            // $this->db->bind(':medical_devices', $medical_devices_sales);
            // $this->db->bind(':personal_care', $personal_care_sales);

            $sales_category_array = array($medicine_sales, $medical_devices_sales, $personal_care_sales, $medicine_heart_sales, $medicine_diabetes_sales, $medicine_infection_sales, $medicine_gastro_sales, $medicine_muscle_sales, $personal_care_nourishments_sales, $personal_care_accessories_sales, $personal_care_skin_care_sales, $personal_care_women_pc_sales, $personal_care_oral_care_sales, $medical_devices_first_aid_sales, $medical_devices_health_device_sales, $medical_devices_support_sales);

            // Execute
            if($this->db->execute()){
            return $sales_category_array;
            } else {
            return false;
            }
        }






        public function getSalesReport()
        {
            $this->db->query("SELECT * from sales_report");
            $result = $this->db->resultSet();

            return $result;
        }





        public function getSalesLocation()
        {
            $this->db->query("SELECT * from sales_location");
            $result = $this->db->resultSet();

            return $result;
        }





        public function getSalesCategory()
        {
            $this->db->query("SELECT * from sales_category");
            $result = $this->db->resultSet();

            return $result;
        }




        public function getFeedback()
        {
            $this->db->query("SELECT * FROM feedback");
            $row = $this->db->resultSet();
            return $row;
        }





        public function sort_feedback_model(){
            $this->db->query("SELECT * FROM feedback ORDER BY date DESC");
            $row = $this->db->resultSet();
            return $row;   
        }




        public function getFeedbackByID($id)
        {
            $this->db->query("SELECT * FROM feedback WHERE feedbackID=:feedbackID");
            // Bind values
            $this->db->bind(':feedbackID',$id);
            
            $row = $this->db->single();
            return $row;
        }





        public function deletefeedback($id)
        {
            $this->db->query('DELETE FROM feedback WHERE feedbackID=:feedbackID');
            // Bind values
            $this->db->bind(':feedbackID', $id);

            // Execute
            if($this->db->execute()){
              return true;
            } else {
              return false;
            }
        }





        public function get_customer_name_from_feedback($id)
        {
            $this->db->query(
                "SELECT CONCAT(u.fName,' ', u.lName) AS name 
                FROM users u
                JOIN feedback f ON u.user_ID = f.customerID 
                WHERE feedbackID=:fID"
            );
             // Bind values
             $this->db->bind(':fID',$id);
             $name = $this->db->single();
     
             return $name;
        }





        //accept order
        public function pending_to_processing($id)
        {
            // $this->db->query("UPDATE order_details SET order_status='processing' WHERE orderID=:orderID");
            // // Bind values
            // $this->db->bind(':orderID',$id);

            $order_details_table = "order_details";
            $prescription_orders_table = "customer_prescription";
            $table_found = false;

            // Check if order_id exists in order_details table
            $this->db->query("SELECT orderID FROM $order_details_table WHERE orderID = :orderID");
            $this->db->bind(':orderID', $id);
            $order_details_result = $this->db->single();

            if(!empty($order_details_result)) {
                // Update order_status in order_details table
                $this->db->query("UPDATE $order_details_table SET order_status='processing' WHERE orderID = :orderID");
                $table_found = true;
            } else {
                // Check if order_id exists in prescription_orders table
                $this->db->query("SELECT orderID FROM $prescription_orders_table WHERE orderID = :orderID");
                $this->db->bind(':orderID', $id);
                $prescription_orders_result = $this->db->single();

                if(!empty($prescription_orders_result)) {
                    // Update order_status in prescription_orders table
                    $this->db->query("UPDATE $prescription_orders_table SET order_status='processing' WHERE orderID = :orderID");
                    $table_found = true;
                }
            }

            if($table_found) {
                // Bind values
                $this->db->bind(':orderID', $id);
                // Execute
                if($this->db->execute()) {
                    return true;
                } else {
                    return false;
                }
            }
        }





        //reject order
        public function initiated_to_cancelled($id)
        {
            // $this->db->query("UPDATE order_details SET order_status='cancelled' WHERE orderID=:orderID");
            // // Bind values
            // $this->db->bind(':orderID',$id);

            $order_details_table = "order_details";
            $prescription_orders_table = "customer_prescription";
            $table_found = false;

            // Check if order_id exists in order_details table
            $this->db->query("SELECT orderID FROM $order_details_table WHERE orderID = :orderID");
            $this->db->bind(':orderID', $id);
            $order_details_result = $this->db->single();

            if(!empty($order_details_result)) {
                // Update order_status in order_details table
                $this->db->query("UPDATE $order_details_table SET order_status='cancelled' WHERE orderID = :orderID");
                $table_found = true;
            } else {
                // Check if order_id exists in prescription_orders table
                $this->db->query("SELECT orderID FROM $prescription_orders_table WHERE orderID = :orderID");
                $this->db->bind(':orderID', $id);
                $prescription_orders_result = $this->db->single();

                if(!empty($prescription_orders_result)) {
                    // Update order_status in prescription_orders table
                    $this->db->query("UPDATE $prescription_orders_table SET order_status='cancelled' WHERE orderID = :orderID");
                    $table_found = true;
                }
            }

            if($table_found) {
                // Bind values
                $this->db->bind(':orderID', $id);
                // Execute
                if($this->db->execute()) {
                    return true;
                } else {
                    return false;
                }
            }
        }





        //after refunding
        public function cancelled_to_refunded($id)
        {
            
            $order_details_table = "order_details";
            $prescription_orders_table = "customer_prescription";
            $table_found = false;

            // Check if order_id exists in order_details table
            $this->db->query("SELECT orderID FROM $order_details_table WHERE orderID = :orderID");
            $this->db->bind(':orderID', $id);
            $order_details_result = $this->db->single();

            if(!empty($order_details_result)) {
                // Update order_status in order_details table
                $this->db->query("UPDATE $order_details_table SET order_status='refunded' WHERE orderID = :orderID");
                $table_found = true;
            } else {
                // Check if order_id exists in prescription_orders table
                $this->db->query("SELECT orderID FROM $prescription_orders_table WHERE orderID = :orderID");
                $this->db->bind(':orderID', $id);
                $prescription_orders_result = $this->db->single();

                if(!empty($prescription_orders_result)) {
                    // Update order_status in prescription_orders table
                    $this->db->query("UPDATE $prescription_orders_table SET order_status='refunded' WHERE orderID = :orderID");
                    $table_found = true;
                }
            }

            if($table_found) {
                // Bind values
                $this->db->bind(':orderID', $id);
                // Execute
                if($this->db->execute()) {
                    return true;
                } else {
                    return false;
                }
            }
        }




        //************************* need to change this for two tables ****************************
        //refund order
        // public function unpaid_to_paid($id){
        //     $this->db->query("UPDATE order_details SET payment_status='paid' WHERE orderID=:orderID");
        //     // Bind values
        //     $this->db->bind(':orderID',$id);

        //     // Execute
        //     if($this->db->execute()){
        //         return true;
        //     } else {
        //         return false;
        //     }
        // }




        
        //change the availability status of delivery person
        public function available_to_unavailable($id)
        {
            $this->db->query("UPDATE delivery_person SET availability_status='unavailable' WHERE deliverypersonID=:ID");
            // Bind values
            $this->db->bind(':ID',$id);

            // Execute
            if($this->db->execute()){
                return true;
            } else {
                return false;
            }
        }





        //assign delivery person to an order
        public function assign_deliveryperson_order($d_id,$o_id)
        {
            // $this->db->query("UPDATE order_details SET deliverypersonID=:DID where orderID=:OID");
            // // Bind values
            // $this->db->bind(':DID',$d_id);
            // $this->db->bind(':OID',$o_id);

            $order_details_table = "order_details";
            $prescription_orders_table = "customer_prescription";
            $table_found = false;

            // Check if order_id exists in order_details table
            $this->db->query("SELECT orderID FROM $order_details_table WHERE orderID = :orderID");
            $this->db->bind(':orderID', $o_id);
            $order_details_result = $this->db->single();

            if(!empty($order_details_result)) {
                // Update order_status in order_details table
                $this->db->query("UPDATE $order_details_table SET deliverypersonID=:DID, delivery_status='not delivered' where orderID=:OID");
                $table_found = true;
            } else {
                // Check if order_id exists in prescription_orders table
                $this->db->query("SELECT orderID FROM $prescription_orders_table WHERE orderID = :orderID");
                $this->db->bind(':orderID', $o_id);
                $prescription_orders_result = $this->db->single();

                if(!empty($prescription_orders_result)) {
                    // Update order_status in prescription_orders table
                    $this->db->query("UPDATE $prescription_orders_table SET deliverypersonID=:DID, delivery_status='not delivered' where orderID=:OID");
                    $table_found = true;
                }
            }

            if($table_found){
                // Bind values
                $this->db->bind(':DID', $d_id);
                $this->db->bind(':OID', $o_id);
        
                // Execute
                if($this->db->execute()){
                    return true;
                } else {
                    return false;
                }
            } 
        }
        




        //get email of delivery person by id 
        public function get_email_by_id($d_id)
        {
            $this->db->query("SELECT email FROM users WHERE user_ID=:dID");
            // Bind values
            $this->db->bind(':dID',$d_id);
            $email_object = $this->db->single();
    
            $email_string = (string) $email_object->email;
            return $email_string;
        }





        //get name of delivery person by id 
        public function get_deliveryperson_name_by_id($d_id)
        {
            $this->db->query("SELECT CONCAT(fName,' ',lName) as name FROM users WHERE user_ID=:dID");
            // Bind values
            $this->db->bind(':dID',$d_id);
            $name_object = $this->db->single();
    
            $name_string = (string) $name_object->name;
            return $name_string;
        }





        //get name of customer by order id 
        public function get_customer_name_by_order_id($o_id)
        {
            // $this->db->query(
            //     "SELECT CONCAT(c.fName, ' ', c.lName) AS name 
            //     FROM order_details od
            //     JOIN users u ON od.customerID = u.user_ID 
            //     WHERE orderID=:oID"
            // );

            $order_details_table = "order_details";
            $prescription_orders_table = "customer_prescription";
            $table_found = false;

            // Check if order_id exists in order_details table
            $this->db->query("SELECT orderID FROM $order_details_table WHERE orderID = :orderID");
            $this->db->bind(':orderID', $o_id);
            $order_details_result = $this->db->single();

            if(!empty($order_details_result)) {
                $this->db->query("
                    SELECT CONCAT(u.fName, ' ', u.lName) AS name 
                    FROM order_details od
                    JOIN users u ON od.customerID = u.user_ID 
                    WHERE orderID=:orderID
                ");
                $table_found = true;
            } else {
                // Check if order_id exists in prescription_orders table
                $this->db->query("SELECT orderID FROM $prescription_orders_table WHERE orderID = :orderID");
                $this->db->bind(':orderID', $o_id);
                $prescription_orders_result = $this->db->single();

                if(!empty($prescription_orders_result)) {
                    $this->db->query("
                        SELECT CONCAT(u.fName,' ', u.lName) AS name 
                        FROM customer_prescription cp
                        JOIN users u ON cp.customerID = u.user_ID 
                        WHERE orderID=:orderID
                    ");
                    $table_found = true;
                }
            }

            if($table_found) {
                // Bind values
                $this->db->bind(':orderID', $o_id);
                $name_object = $this->db->single();

                $name_string = (string) $name_object->name;
                return $name_string;
            }
        }






         //get name of customer by order id 
         public function get_customer_phone_by_order_id($o_id)
         {
             // $this->db->query(
             //     "SELECT CONCAT(c.fName, ' ', c.lName) AS name 
             //     FROM order_details od
             //     JOIN users u ON od.customerID = u.user_ID 
             //     WHERE orderID=:oID"
             // );
 
             $order_details_table = "order_details";
             $prescription_orders_table = "customer_prescription";
             $table_found = false;
 
             // Check if order_id exists in order_details table
             $this->db->query("SELECT orderID FROM $order_details_table WHERE orderID = :orderID");
             $this->db->bind(':orderID', $o_id);
             $order_details_result = $this->db->single();
 
             if(!empty($order_details_result)) {
                 $this->db->query("
                     SELECT u.mobile AS mobile 
                     FROM order_details od
                     JOIN users u ON od.customerID = u.user_ID 
                     WHERE orderID=:orderID
                 ");
                 $table_found = true;
             } else {
                 // Check if order_id exists in prescription_orders table
                 $this->db->query("SELECT orderID FROM $prescription_orders_table WHERE orderID = :orderID");
                 $this->db->bind(':orderID', $o_id);
                 $prescription_orders_result = $this->db->single();
 
                 if(!empty($prescription_orders_result)) {
                     $this->db->query("
                         SELECT u.mobile AS mobile 
                         FROM customer_prescription cp
                         JOIN users u ON cp.customerID = u.user_ID 
                         WHERE orderID=:orderID
                     ");
                     $table_found = true;
                 }
             }
 
             if($table_found) {
                 // Bind values
                 $this->db->bind(':orderID', $o_id);
                 $mobile_object = $this->db->single();
 
                 $mobile_string = (string) $mobile_object->mobile;
                 return $mobile_string;
             }
         }

         




        //get delivery address of order by order id 
        public function get_delivery_address_by_order_id($o_id)
        {
            // $this->db->query(
            //     "SELECT CONCAT(c.street_address, ' ', c.city) AS address 
            //     FROM order_details od
            //     JOIN customer c ON od.customerID = c.customerID 
            //     WHERE orderID=:oID"
            // );

            $order_details_table = "order_details";
            $prescription_orders_table = "customer_prescription";
            $table_found = false;

            // Check if order_id exists in order_details table
            $this->db->query("SELECT orderID FROM $order_details_table WHERE orderID = :orderID");
            $this->db->bind(':orderID', $o_id);
            $order_details_result = $this->db->single();

            if(!empty($order_details_result)) {
                $this->db->query("
                    SELECT CONCAT(u.address, ' ', u.city) AS address  
                    FROM order_details od
                    JOIN users u ON od.customerID = u.user_ID 
                    WHERE orderID=:orderID
                ");
                $table_found = true;
            } else {
                // Check if order_id exists in prescription_orders table
                $this->db->query("SELECT orderID FROM $prescription_orders_table WHERE orderID = :orderID");
                $this->db->bind(':orderID', $o_id);
                $prescription_orders_result = $this->db->single();

                if(!empty($prescription_orders_result)) {
                    $this->db->query("
                        SELECT CONCAT(u.address, ' ', u.city) AS address 
                        FROM customer_prescription cp
                        JOIN users u ON cp.customerID = u.user_ID 
                        WHERE orderID=:orderID
                    ");
                    $table_found = true;
                }
            }

            if($table_found) {
                // Bind values
                $this->db->bind(':orderID', $o_id);
                $address_object = $this->db->single();

                $address_string = (string) $address_object->address;
                return $address_string;
            }
        }





        function get_customer_email_by_id($c_id)
        {
            $this->db->query("SELECT email FROM users WHERE user_ID=:cID");
            // Bind values
            $this->db->bind(':cID',$c_id);
            $email_object = $this->db->single();
    
            $email_string = (string) $email_object->email;
            return $email_string;
        }




        
        function get_customer_name_by_id($c_id)
        {
            $this->db->query("SELECT CONCAT(fName, ' ',lName) AS name FROM users WHERE user_ID=:cID");
            // Bind values
            $this->db->bind(':cID',$c_id);
            $name_object = $this->db->single();

            $name_string = (string) $name_object->name;
            return $name_string;
        }
 
        



        //low stock medicines
        public function get_count_low_stock(){
        $this->db->query("SELECT medicineID from medicine where quantity=0");
        $row = $this->db->resultSet();
        $count = count($row);

        return $count;
        }



        public function get_ids_low_stock(){
        $this->db->query("SELECT medicineID from medicine where quantity=0");
        $rows = $this->db->resultSet();

        $ids = array();
        foreach ($rows as $row) {
            $ids[] = (string) $row->medicineID;
        }
        return $ids;
        }




        //expired medicines
        public function get_count_expired(){
        $this->db->query("SELECT expiry_date from medicine where DATE(expiry_date) <= CURDATE()");
        $row = $this->db->resultSet();
        $count = count($row);
        
        return $count;
        }



        public function get_ids_expired(){
        $this->db->query("SELECT medicineID from medicine where DATE(expiry_date) <= CURDATE()");
        $rows = $this->db->resultSet();

        $ids = array();
        foreach ($rows as $row) {
            $ids[] = (string) $row->medicineID;
        }
        return $ids;
        }



        //storekeeper emails
        public function get_all_storekeeper_emails(){
        $this->db->query("SELECT email from users where user_role='storekeeper'");
        $rows = $this->db->resultSet();
        
        $emails = array();
        foreach ($rows as $row) {
            $emails[] = (string) $row->email;
        }
        
        return $emails;
        }




        //account page
        public function getuserdetails($email){
            $this->db->query("SELECT fName,lName,mobile,email,user_role,password FROM users WHERE email = :email ");
            $this->db->bind(':email', $email);
            $row = $this->db->resultSet();
            return $row;
        }


        public function updatePassword($email,$hashed)
        {
            $this->db->query("UPDATE users
            SET password= :hashed
            WHERE email=:email;");
            $this->db->bind(':hashed', $hashed);
            $this->db->bind(':email', $email);
            $row = $this->db->execute();
            if ($row) {
                return 1;
            } else {
                return 0;
            }
            
        }

        public function updateProfilePic($filename,$email)
        {
            $this->db->query("UPDATE users
            SET user_img= :picture
            WHERE email=:email;");
            $this->db->bind(':picture', $filename);
            $this->db->bind(':email', $email);
            $row = $this->db->execute();
            if ($row) {
                return 1;
            } else {
                return 0;
            }
        }



        //dashboard
        public function get_feedback_count()
        {
            $this->db->query("SELECT * from feedback");
            $row = $this->db->resultSet();
            $count = count($row);
    
            return $count;
        }

        public function get_deliveryguy_count()
        {
            $this->db->query("SELECT deliverypersonID from delivery_person where availability_status='available'");
            $row = $this->db->resultSet();
            $count = count($row);
    
            return $count;
        }

        public function get_pending_count()
        {
        $this->db->query(
            "SELECT orderID
                    FROM (
                        SELECT od.orderID
                        FROM order_details od
                        WHERE od.order_status='pending' 
                        UNION
                        SELECT cp.orderID 
                        FROM customer_prescription cp 
                        WHERE cp.order_status='pending'
                    ) AS combined_table
                    ORDER BY orderID DESC"
            );

            $row = $this->db->resultSet();
            $count = count($row);

            return $count;
        }

        public function get_cancelled_count()
        {
        $this->db->query(
            "SELECT orderID
                    FROM (
                        SELECT od.orderID
                        FROM order_details od
                        WHERE od.order_status='cancelled' 
                        UNION
                        SELECT cp.orderID 
                        FROM customer_prescription cp 
                        WHERE cp.order_status='cancelled'
                    ) AS combined_table
                    ORDER BY orderID DESC"
            );

            $row = $this->db->resultSet();
            $count = count($row);

            return $count;
        }

        public function get_completed_count()
        {
        $this->db->query(
            "SELECT orderID
                    FROM (
                        SELECT od.orderID
                        FROM order_details od
                        WHERE od.order_status='completed' 
                        UNION
                        SELECT cp.orderID 
                        FROM customer_prescription cp 
                        WHERE cp.order_status='completed'
                    ) AS combined_table
                    ORDER BY orderID DESC"
            );

            $row = $this->db->resultSet();
            $count = count($row);

            return $count;
        }
        
}

