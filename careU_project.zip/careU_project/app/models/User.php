<?php

// dependencies for phpmailer
use PHPMailer\PHPMailer\PHPMailer;

    class User{
        private $db;

        public function __construct()
        {
            $this->db = new Database;
        }

        // Login Function
        public function login($email, $password){
            $this->db->query("SELECT * FROM users where email = :email");
            $this->db->bind(':email', $email);
            
            $row = $this->db->single();

            $hashed_password = $row->password;
            if(password_verify($password, $hashed_password)){
                return $row;
            } else {
                return false;
            }
        }

        public function findUserByEmail($email){
            $this->db->query("SELECT * FROM users where email = :email");
            $this->db->bind(':email', $email);

            $this->db->single();

            //check row
            if($this->db->rowCount() > 0){
                return true;
            }
            else{
                return false;
            }
        }

        public function findUserByEmailLogin($email){
            $this->db->query("SELECT * FROM users where email = :email and active_status = 'Active'");
            $this->db->bind(':email', $email);

            $this->db->single();

            //check row
            if($this->db->rowCount() > 0){
                return true;
            }
            else{
                return false;
            }
        }

        public function findUserByMobile($mobile){
            $this->db->query("SELECT * FROM users where mobile = :mobile");
            $this->db->bind(':mobile', $mobile);

            $this->db->single();

            //check row
            if($this->db->rowCount() > 0){
                return true;
            }
            else{
                return false;
            }
        }



        // Regsiter user


        public function getLastUserID()
        {
            $stmt = $this->db->prepare("SELECT user_ID FROM users where user_role = 'customer' ORDER BY user_ID DESC LIMIT 1");
            $stmt->execute();

            return $stmt->fetchColumn();
        }

      

        public function register($data){
                     
            $this->db->query('INSERT INTO users (user_ID, fName, lName, birthDate, mobile, email, address, city, password, user_role, joinedDate, active_status) VALUES(:user_ID, :fName, :lName, :birthDate, :mobile, :email, :address, :city, :password, :user_role, :joinedDate, :active_status)');
            // Bind values
            $this->db->bind(':user_ID', $data['user_ID']);
            $this->db->bind(':fName', $data['fName']);
            $this->db->bind(':lName', $data['lName']);
            $this->db->bind(':birthDate', $data['birthDate']);
            $this->db->bind(':mobile', $data['mobile']);
            $this->db->bind(':email', $data['email']);
            $this->db->bind(':address', $data['address']);
            $this->db->bind(':city', $data['city']);
            $this->db->bind(':password', $data['password']);
            $this->db->bind(':user_role', 'customer');
            $this->db->bind(':joinedDate', date('Y-m-d H:i:s'));
            $this->db->bind(':active_status', 'Active');

        
            // Execute
            if($this->db->execute()){
                return true;
            } else {
                return false;
            }
        }

        public function sendPasswordResetEmail($email)
        {
            

            // Generate a unique token (e.g., using random_bytes or any other method)
            $token = bin2hex(random_bytes(32));
        
            // Save the token and email in the database or any other storage mechanism
            $this->db->query("INSERT INTO password_resets (email, token) VALUES (:email, :token)");
            $this->db->bind(':email', $email);
            $this->db->bind(':token', $token);
            
            // Execute the database query
            if ($this->db->execute()) {
                // Compose the email message
                $subject = 'Password Reset';
                $message = '<p>Dear user, to reset your password, click the button below:</p>';
                $message .= '<p><a href="' . URLROOT . '/users/recover_password?token=' . $token . '" style="display:inline-block;background-color:#1A4C67;color:#ffffff;text-decoration:none;padding:10px 20px;border-radius:5px;">Reset Password</a></p>';
                $message .= '<p>If you did not request a password reset, feel free to disregard this email—your password will not be changed.</p>';
        
                // Send the email using PHPMailer
                $mail = new PHPMailer(true);
                try {
                    // Configure SMTP settings
                    $mail->isSMTP();
                    $mail->Host = 'smtp.gmail.com';
                    $mail->SMTPAuth = true;
                    $mail->Username = 'careu.meds@gmail.com';
                    $mail->Password = 'rqoisanoxkfcgbjz';
                    $mail->SMTPSecure = 'ssl';
                    $mail->Port = 465;
                    
                    // Set email details
                    $mail->setFrom('careu.meds@gmail.com', 'CareU Pharmacy');
                    $mail->addAddress($email);
                    $mail->Subject = $subject;
                    $mail->Body = $message;
                    $mail->isHTML(true);

                    // Send the email
                    if ($mail->send()) {
                        return true;
                    } else {
                        return false;
                    }
                } catch (Exception $e) {
                   
                    // Exception occurred while sending the email
                    return false;
                }
            } else {
                // Database query failed
                return false;
            }
        }
        
            
        public function updatePasswordByEmail($email, $password)
        {
            $this->db->query('UPDATE users SET password = :password WHERE email = :email');
            $this->db->bind(':email', $email);
            $this->db->bind(':password', $password);
            // Execute
            if($this->db->execute()){
                return true;
            } else {
                return false;
            }
        }


        
  


        public function getMeds(){
            $this->db->query("SELECT * FROM medicine WHERE flag=0");
            $row = $this->db->resultSet();
            return $row;
        }

        
    }

    
    



  