<?php
    
    class Customer{
    private $db;

    public function __construct()
    {
        $this->db = new Database;
    }

    public function Medicine()
    {
        $this->db->query("SELECT * FROM medicine WHERE medicine_type1='medicine' && flag='0' && quantity > 20");
        $row = $this->db->resultSet();
        return $row;
    }

    public function Personal_Care()
    {
        $this->db->query("SELECT * FROM medicine WHERE medicine_type1='personal care' && flag='0' && quantity > 20");
        $row = $this->db->resultSet();
        return $row;
    }

    public function Medical_Devices()
    {
        $this->db->query("SELECT * FROM medicine WHERE medicine_type1='medical devices' && flag='0' && quantity > 20");
        $row = $this->db->resultSet();
        return $row;
    }

    

    public function findUserByID($id){
        $this->db->query("SELECT * FROM users where user_ID = :id");
        $this->db->bind(':id', $id);

        $row=$this->db->single();

        //check row
        if($this->db->execute()){
            return $row;
        }
        else{
            return false;
        }
    }

    public function showorder(){
        $this->db->query("SELECT orderID, customerID, date, order_status, payment_status, delivery_status, packing_status FROM order_details WHERE customerID = :user_ID && delivery_status = 'not delivered'");
        $this->db->bind(':user_ID', $_SESSION['user_ID']);


        $row=$this->db->resultSet();

        if($this->db->execute()){
            return $row;
        }
        else{
            return false;
        }
    }

    public function cancelorder($orderID){
        $this->db->query("UPDATE order_details SET order_status='cancelled' WHERE orderID = :orderID");
        $this->db->bind(':orderID', $orderID);

        if ($this->db->execute()) {
            return true;
        } else {
            return false;
        }
    }

    public function showcart(){
        $this->db->query("SELECT med.name, med.price, ca.quantity, ca.cartID, ca.orderID FROM cart ca, medicine med where ca.medicineID = med.medicineID");
   
        $row=$this->db->resultSet();

        if($this->db->execute()){
            return $row;
        }
        else{
            return false;
        }
    }
    

    public function updatecart($cartID, $quantity){
        // $this->db->beginTransaction();

    // Update quantity in cart table
    // print_r($quantity);die();
        $this->db->query("UPDATE cart SET quantity = :quantity WHERE cartID = :cartID");
        $this->db->bind(':quantity',$quantity);
        $this->db->bind(':cartID',$cartID);
        $this->db->execute();

    // Update quantity in medicine table
        $this->db->query("UPDATE medicine SET quantity = quantity - :quantity /2 WHERE medicineID = (SELECT medicineID FROM cart WHERE cartID = :cartID)");
        $this->db->bind(':quantity',$quantity);
        $this->db->bind(':cartID',$cartID);
        $this->db->execute();
     

        if ($this->db->execute()) {
            return true;
        } else {
            return false;
        }
    }

    public function deletecart($cartID){
        $this->db->query("DELETE FROM cart WHERE cartID = :cartID");
        $this->db->bind(':cartID', $cartID);

        if ($this->db->execute()) {
            return true;
        } else {
            return false;
        }
    }

    public function cart_sum(){
        $query = $this->db->query("SELECT SUM(cart.quantity * medicine.price) AS total FROM cart INNER JOIN medicine ON cart.medicineID = medicine.medicineID");
        
        $amount=$this->db->single();

        $amount_string=(string) $amount->total;

        return $amount_string;
    }

    public function deletecartall($cartID){
        $this->db->query("DELETE FROM cart WHERE cartID = :cartID");
        $this->db->bind(':cartID', $cartID);

        if ($this->db->execute()) {
            return true;
        } else {
            return false;
        }
    }

    public function getlastID()
        {
            $this->db->query("SELECT * FROM invoice ORDER BY invoiceID DESC LIMIT 1");
            $row=$this->db->resultSet();
            return $row[0]->invoiceID+1;
        }


    public function upload_prescription_db($cid,$pname,$message,$date,$invoiceID){
        $this->db->query("INSERT into invoice(invoiceID,date_time) VALUES (:invoiceID,:date)");
        $this->db->bind(':date', $date); 
        $this->db->bind(':invoiceID', $invoiceID); 
        $this->db->execute();
        
        $this->db->query("SELECT invoiceID FROM invoice WHERE date_time = (SELECT MAX(date_time) FROM invoice)");
        $invoiceID =  $this->db->single();
        // print_r($invoiceID->invoiceID);die();
        $this->db->bind(':invoiceID', $invoiceID->invoiceID);
        // print_r($invoiceID);die();

        $this->db->query("INSERT into customer_prescription(customerID,invoiceID,prescription,message,date) VALUES (:cid,:invoiceID,:pname,:message,:date)");
        $this->db->bind(':cid', $cid);
        $this->db->bind(':invoiceID', $invoiceID->invoiceID);
        $this->db->bind(':pname', $pname);
        $this->db->bind(':message', $message);
        $this->db->bind(':date', $date);

        // redirect('Customers/home');  

        if($this->db->execute()){
            return true;
        }
        else{
            return false;   
        }
    }

    public function order_upload($cid,$medicineID,$date){
        $this->db->query("SELECT * FROM cart WHERE customerID = :cid AND medicineID = :medicineID");
        $this->db->bind(':cid', $cid);
        $this->db->bind(':medicineID', $medicineID);
        // $this->db->bind(':date', $date);
        $result = $this->db->single();

        if ($result) {
            echo '<script>alert("Medicine already added to cart.")</script>';
            redirect('Customers/order');
        } else {
            $this->db->query("INSERT into cart(customerID,medicineID,date) VALUES(:cid,:medicineID,:date)");
            $this->db->bind(':cid', $cid);
            $this->db->bind(':medicineID', $medicineID);
            $this->db->bind(':date', $date);
        

        if($this->db->execute()){
            return true;
            }
        else {
            return false;
            }   
        } 
    } 
    
    public function medicine_upload($cid,$medicineID,$date){
        $this->db->query("INSERT into cart(customerID,medicineID,date) VALUES(:cid,:medicineID,:date)");
        $this->db->bind(':cid', $cid);
        $this->db->bind(':medicineID', $medicineID);
        $this->db->bind(':date', $date);

        if($this->db->execute()){
            return true;
        }
        else{
            return false;
        }   
    } 

    public function getcartdetails(){
        $this->db->query('SELECT * FROM cart WHERE medicineID = :medicineID');
        $this->db->bind(':medicineID', $medicineID);
        $result = $this->db->single();
        return $result;
    }

    public function feedback_upload($date,$cid,$description){
        $this->db->query("INSERT into feedback VALUES(DEFAULT,:description,:cid,:date)");
        $this->db->bind(':date', $date);
        $this->db->bind(':cid', $cid);
        $this->db->bind(':description', $description);

        if($this->db->execute()){
            return true;
        }
        else{
            return false;
        }
    }

    public function updatePassword($email,$hashed)
        {
         $this->db->query("UPDATE users
            SET password= :hashed
            WHERE email=:email;");
            $this->db->bind(':hashed', $hashed);
            $this->db->bind(':email', $email);
            $row = $this->db->execute();
            if ($row) {
                return 1;
            } else {
                return 0;
            }
            
        }

    public function updateUser($email, $mobile, $address, $city)
        {
            $this->db->query("UPDATE users
                SET email=:email, mobile=:mobile, address=:address, city=:city
                WHERE user_ID=:user_ID");
            $this->db->bind(':user_ID', $_SESSION['user_ID']);
            $this->db->bind(':email', $email);
            $this->db->bind(':mobile', $mobile);
            $this->db->bind(':address', $address);
            $this->db->bind(':city', $city);
            // print_r(updateUser);die();
            $row = $this->db->execute();
            if ($row) {
                return 1;
            } else {
                return 0;
            }
        }

}


    