<?php
    class Pharmacist{
        private $db;

        public function __construct()
        {
            $this->db = new Database;
        }

        public function getHeartMeds()
        {
            $this->db->query("SELECT * FROM medicine WHERE medicine_type1='medicine' AND medicine_type2 ='heart'");
            $row = $this->db->resultSet();
            return $row;
            
        }

        public function getdiabetesMeds()
        {
            $this->db->query("SELECT * FROM medicine WHERE medicine_type1='medicine' AND medicine_type2 ='diabetes'");
            $row = $this->db->resultSet();
            return $row;
            
        }

        public function getinfectionMeds()
        {
            $this->db->query("SELECT * FROM medicine WHERE medicine_type1='medicine' AND medicine_type2 ='infection'");
            $row = $this->db->resultSet();
            return $row;
            
        }

        public function getgastroMeds()
        {
            $this->db->query("SELECT * FROM medicine WHERE medicine_type1='medicine' AND medicine_type2 ='gastro'");
            $row = $this->db->resultSet();
            return $row;
            
        }

        public function getmuscleMeds()
        {
            $this->db->query("SELECT * FROM medicine WHERE medicine_type1='medicine' AND medicine_type2 ='muscle'");
            $row = $this->db->resultSet();
            return $row;
            
        }

        public function getnourishments()
        {
            $this->db->query("SELECT * FROM medicine WHERE medicine_type1='personal care' AND medicine_type2 ='nourishments'");
            $row = $this->db->resultSet();
            return $row;
            
        }

        public function getaccessories()
        {
            $this->db->query("SELECT * FROM medicine WHERE medicine_type1='personal care' AND medicine_type2 ='accessories'");
            $row = $this->db->resultSet();
            return $row;
            
        }

        public function getskincare()
        {
            $this->db->query("SELECT * FROM medicine WHERE medicine_type1='personal care' AND medicine_type2 ='skin care'");
            $row = $this->db->resultSet();
            return $row;
            
        }

        public function women_personalcare()
        {
            $this->db->query("SELECT * FROM medicine WHERE medicine_type1='personal care' AND medicine_type2 ='women personal care'");
            $row = $this->db->resultSet();
            return $row;
            
        }

        public function oralcare()
        {
            $this->db->query("SELECT * FROM medicine WHERE medicine_type1='personal care' AND medicine_type2 ='oral care'");
            $row = $this->db->resultSet();
            return $row;
            
        }

        public function firstaid()
        {
            $this->db->query("SELECT * FROM medicine WHERE medicine_type1='medical devices' AND medicine_type2 ='first aid'");
            $row = $this->db->resultSet();
            return $row;
            
        }

        public function health_device()
        {
            $this->db->query("SELECT * FROM medicine WHERE medicine_type1='medical devices' AND medicine_type2 ='health device'");
            $row = $this->db->resultSet();
            return $row;
            
        }

        

        public function support()
        {
            $this->db->query("SELECT * FROM medicine WHERE medicine_type1='medical devices' AND medicine_type2 ='support'");
            $row = $this->db->resultSet();
            return $row;
            
        }

        public function available_prescription()
        {
            $this->db->query("SELECT * FROM customer_prescription
            INNER JOIN users ON users.user_ID = customer_prescription.customerID
            WHERE status <> :status
            AND status <> :reject");
            $this->db->bind(':status', "1");
            $this->db->bind(':reject', "2");
            $row = $this->db->resultSet();
            return $row;
        }

        public function accept_presc($id,$pharmacistID)
        {
            $this->db->query("UPDATE customer_prescription
            SET status= :status, pharmacistID = :pharmacist_id
            WHERE prescriptionID=:prescriptionID;");
            $this->db->bind(':prescriptionID', $id);
            $this->db->bind(':status', "1");
            $this->db->bind(':pharmacist_id', $pharmacistID);
            $row = $this->db->execute();
            if ($row) {
                return 1;
            } else {
                return 0;
            }
            
        }

        

        public function reject_presc($id)
        {
            $this->db->query("UPDATE customer_prescription
            SET status= :status
            WHERE prescriptionID=:prescriptionID;");
            $this->db->bind(':prescriptionID', $id);
            $this->db->bind(':status', "2");
            $row = $this->db->execute();
            if ($row) {
                return 1;
            } else {
                return 0;
            }
            
        }

        public function accepted_prescription()
        {
            $this->db->query("SELECT * FROM customer_prescription 
            INNER JOIN users ON users.user_ID = customer_prescription.customerID
            WHERE status = :status
            AND packing_status <> :pack");
            $this->db->bind(':status', "1");
            $this->db->bind(':pack', "completed");
            $row = $this->db->resultSet();
            return $row;
        }

        public function completed_prescription()
        {
            $this->db->query("SELECT * FROM customer_prescription
            INNER JOIN users ON users.user_ID = customer_prescription.customerID
            WHERE packing_status = :status");
            $this->db->bind(':status', "completed");
            $row = $this->db->resultSet();
            return $row;
        }

        public function packed($id)
        {
            $this->db->query("UPDATE customer_prescription
            SET packing_status= :status
            WHERE prescriptionID=:prescriptionID;");
            $this->db->bind(':prescriptionID', $id);
            $this->db->bind(':status', "packed");
            $row = $this->db->execute();
            if ($row) {
                return 1;
            } else {
                return 0;
            }
        }

        public function unpacked($id)
        {
            $this->db->query("UPDATE customer_prescription
            SET packing_status= :status
            WHERE prescriptionID=:prescriptionID;");
            $this->db->bind(':prescriptionID', $id);
            $this->db->bind(':status', "unpacked");
            $row = $this->db->execute();
            if ($row) {
                return 1;
            } else {
                return 0;
            }
        }

        public function completed($id)
        {
            $this->db->query("UPDATE customer_prescription
            SET packing_status= :status
            WHERE prescriptionID=:prescriptionID;");
            $this->db->bind(':prescriptionID', $id);
            $this->db->bind(':status', "completed");
            $row = $this->db->execute();
            if ($row) {
                return 1;
            } else {
                return 0;
            }
            
        }

        public function new_order()
        {
            $this->db->query("SELECT * FROM invoice_medicine 
            INNER JOIN order_details ON invoice_medicine.invoiceID = order_details.invoiceID
            INNER JOIN medicine ON medicine.medicineID = invoice_medicine.medicineID
            INNER JOIN users ON users.user_ID = order_details.customerID
            WHERE status =:status");
            $this->db->bind(':status', "0");
            $row = $this->db->resultSet();
            return $row;
        }

        public function get_pharmacistID($email){
            $this->db->query("SELECT user_ID FROM users where email = :email ");
            $this->db->bind(':email',$email);
            $row = $this->db->resultSet();
            return $row;
        }

        public function accept_order($id,$pharmacistID)
        {
            $this->db->query("UPDATE order_details
            SET status= :status ,pharmacistID = :pharmacist_id
            WHERE orderID=:orderID;");
            $this->db->bind(':orderID', $id);
            $this->db->bind(':status', "1");
            $this->db->bind(':pharmacist_id',$pharmacistID);
            $row = $this->db->execute();
            if ($row) {
                return 1;
            } else {
                return 0;
            }
            
        }


        public function reject_order($id)
        {
            $this->db->query("UPDATE order_details
            SET status= :status
            WHERE orderID=:orderID;");
            $this->db->bind(':orderID', $id);
            $this->db->bind(':status', "2");
            $row = $this->db->execute();
            if ($row) {
                return 1;
            } else {
                return 0;
            }
            
        }

        public function accepted_order()
        {
            $this->db->query("SELECT * FROM invoice_medicine 
            INNER JOIN order_details ON invoice_medicine.invoiceID = order_details.invoiceID
            INNER JOIN medicine ON medicine.medicineID = invoice_medicine.medicineID
            INNER JOIN users ON users.user_ID = order_details.customerID
            
            -- INNER JOIN invoice_medicine ON invoice.invoiceID = invoice_medicine.invoiceID
            -- INNER JOIN medicine ON invoice_medicine.medicineID = medicine.medicineID
            WHERE status = :status AND packing_status <> :pack_st");
            $this->db->bind(':status', "1");
            $this->db->bind(':pack_st', "completed");
            $row = $this->db->resultSet();
           
            return $row;
            
        }

        public function packed_ord($id)
        {
            $this->db->query("UPDATE order_details
            SET packing_status= :status
            WHERE orderID=:orderID;");
            $this->db->bind(':orderID', $id);
            $this->db->bind(':status', "packed");
            $row = $this->db->execute();
            if ($row) {
                return 1;
            } else {
                return 0;
            }
        }

        public function unpacked_ord($id)
        {
            $this->db->query("UPDATE order_details
            SET packing_status= :status
            WHERE orderID=:orderID;");
            $this->db->bind(':orderID', $id);
            $this->db->bind(':status', "unpacked");
            $row = $this->db->execute();
            if ($row) {
                return 1;
            } else {
                return 0;
            }
        }

        public function completed_ord($id)
        {
            $this->db->query("UPDATE order_details
            SET packing_status= :status
            WHERE orderID=:orderID;");
            $this->db->bind(':orderID', $id);
            $this->db->bind(':status', "completed");
            $row = $this->db->execute();
            if ($row) {
                return 1;
            } else {
                return 0;
            }
            
        }

        public function completed_orders()
        {
            $this->db->query("SELECT * FROM invoice_medicine 
            INNER JOIN order_details ON invoice_medicine.invoiceID = order_details.invoiceID
            INNER JOIN medicine ON medicine.medicineID = invoice_medicine.medicineID
            INNER JOIN users ON users.user_ID = order_details.customerID
            WHERE packing_status = :status");
            $this->db->bind(':status', "completed");
            $row = $this->db->resultSet();
            return $row;
        }

        public function deletePost($id){
            $this->db->query("DELETE FROM order_details WHERE orderID=:orderID;");
            $this->db->bind(':orderID', $id);
            $row = $this->db->execute();
            if ($row) {
                return 1;
            } else {
                return 0;
            }
        }

        public function getCount_Heart(){
            $this->db->query("SELECT COUNT(medicine_type2) AS heart FROM medicine WHERE medicine_type2 = 'heart';");
            $row = $this->db->resultSet();
            return $row[0]->heart;

        }

        public function getCount_diabetes(){
            $this->db->query("SELECT COUNT(medicine_type2) AS diabetes FROM medicine WHERE medicine_type2 = 'diabetes';");
            $row = $this->db->resultSet();
            return $row[0]->diabetes;

        }

        public function getCount_infection(){
            $this->db->query("SELECT COUNT(medicine_type2) AS infection FROM medicine WHERE medicine_type2 = 'infection';");
            $row = $this->db->resultSet();
            return $row[0]->infection;

        }

        public function getCount_gastro(){
            $this->db->query("SELECT COUNT(medicine_type2) AS gastro FROM medicine WHERE medicine_type2 = 'gastro';");
            $row = $this->db->resultSet();
            return $row[0]->gastro;

        }

        public function getCount_muscle(){
            $this->db->query("SELECT COUNT(medicine_type2) AS muscle FROM medicine WHERE medicine_type2 = 'muscle';");
            $row = $this->db->resultSet();
            return $row[0]->muscle;

        }

        public function getCount_customer(){
            $this->db->query("SELECT COUNT(user_ID) AS customerID FROM users WHERE user_role = 'customer';");
            $row = $this->db->resultSet();
            return $row[0]->customerID;

        }

        public function getexpiredate($cur_date){
            $this->db->query("SELECT COUNT(medicine_type2) AS expired FROM medicine WHERE expiry_date IS NOT NULL AND expiry_date < :date;");
            $this->db->bind(':date', $cur_date);
            $row = $this->db->resultSet();
            return $row[0]->expired;
        }

        public function view_expiredate($cur_date){
            $this->db->query("SELECT * FROM medicine WHERE expiry_date IS NOT NULL AND expiry_date < :date;");
            $this->db->bind(':date', $cur_date);
            $row = $this->db->resultSet();
            return $row;
        }

        public function getuserdetails($email){
            $this->db->query("SELECT fName,lName,mobile,email,user_role,password FROM users WHERE email = :email ");
            $this->db->bind(':email', $email);
            $row = $this->db->resultSet();
            return $row;
        }

        public function countuser($email){
            $this->db->query("SELECT COUNT(fName) FROM users WHERE email = :email ");
            $this->db->bind(':email', $email);
            $row = $this->db->resultSet();
            return $row;
        }

        public function updatePassword($email,$hashed)
        {
            $this->db->query("UPDATE users
            SET password= :hashed
            WHERE email=:email;");
            $this->db->bind(':hashed', $hashed);
            $this->db->bind(':email', $email);
            $row = $this->db->execute();
            if ($row) {
                return 1;
            } else {
                return 0;
            }
            
        }

        public function updateProfilePic($filename,$email)
        {
            $this->db->query("UPDATE users
            SET user_img= :picture
            WHERE email=:email;");
            $this->db->bind(':picture', $filename);
            $this->db->bind(':email', $email);
            $row = $this->db->execute();
            if ($row) {
                return 1;
            } else {
                return 0;
            }
        }

        public function search_heart($search){
            $this->db->query("SELECT * FROM medicine WHERE medicine_type1='medicine' AND medicine_type2 ='heart' 
            AND name LIKE :search");
            $this->db->bind(':search', '%'.$search.'%');
            $row = $this->db->resultSet();
            return $row;
        }

        public function search_diabetes($search){
            $this->db->query("SELECT * FROM medicine WHERE medicine_type1='medicine' AND medicine_type2 ='diabetes' 
            AND name LIKE :search");
            $this->db->bind(':search', '%'.$search.'%');
            $row = $this->db->resultSet();
            return $row;
        }

        public function search_infection($search){
            $this->db->query("SELECT * FROM medicine WHERE medicine_type1='medicine' AND medicine_type2 ='infection' 
            AND name LIKE :search");
            $this->db->bind(':search', '%'.$search.'%');
            $row = $this->db->resultSet();
            return $row;
        }

        public function search_gastro($search){
            $this->db->query("SELECT * FROM medicine WHERE medicine_type1='medicine' AND medicine_type2 ='gastro' 
            AND name LIKE :search");
            $this->db->bind(':search', '%'.$search.'%');
            $row = $this->db->resultSet();
            return $row;
        }

        public function search_muscle($search){
            $this->db->query("SELECT * FROM medicine WHERE medicine_type1='medicine' AND medicine_type2 ='muscle' 
            AND name LIKE :search");
            $this->db->bind(':search', '%'.$search.'%');
            $row = $this->db->resultSet();
            return $row;
        }

        public function search_nourishment($search){
            $this->db->query("SELECT * FROM medicine WHERE medicine_type1='Personal Care' AND medicine_type2 ='nourishments' 
            AND name LIKE :search");
            $this->db->bind(':search', '%'.$search.'%');
            $row = $this->db->resultSet();
            return $row;
        }

        public function search_accessories($search){
            $this->db->query("SELECT * FROM medicine WHERE medicine_type1='Personal Care' AND medicine_type2 ='accessories' 
            AND name LIKE :search");
            $this->db->bind(':search', '%'.$search.'%');
            $row = $this->db->resultSet();
            return $row;
        }

        public function search_skincare($search){
            $this->db->query("SELECT * FROM medicine WHERE medicine_type1='Personal Care' AND medicine_type2 ='Skin care' 
            AND name LIKE :search");
            $this->db->bind(':search', '%'.$search.'%');
            $row = $this->db->resultSet();
            return $row;
        }

        public function search_womenpc($search){
            $this->db->query("SELECT * FROM medicine WHERE medicine_type1='Personal Care' AND medicine_type2 ='women personal care' 
            AND name LIKE :search");
            $this->db->bind(':search', '%'.$search.'%');
            $row = $this->db->resultSet();
            return $row;
        }

        public function search_oralcare($search){
            $this->db->query("SELECT * FROM medicine WHERE medicine_type1='Personal Care' AND medicine_type2 ='oral care' 
            AND name LIKE :search");
            $this->db->bind(':search', '%'.$search.'%');
            $row = $this->db->resultSet();
            return $row;
        }

        public function search_firstaid($search){
            $this->db->query("SELECT * FROM medicine WHERE medicine_type1='medical devices' AND medicine_type2 ='first aid' 
            AND name LIKE :search");
            $this->db->bind(':search', '%'.$search.'%');
            $row = $this->db->resultSet();
            return $row;
        }

        public function search_healthdevice($search){
            $this->db->query("SELECT * FROM medicine WHERE medicine_type1='medical devices' AND medicine_type2 ='health device' 
            AND name LIKE :search");
            $this->db->bind(':search', '%'.$search.'%');
            $row = $this->db->resultSet();
            return $row;
        }

        public function search_support($search){
            $this->db->query("SELECT * FROM medicine WHERE medicine_type1='medical devices' AND medicine_type2 ='support' 
            AND name LIKE :search");
            $this->db->bind(':search', '%'.$search.'%');
            $row = $this->db->resultSet();
            return $row;
        }

        public function getMedicineType(){
            $this->db->query("SELECT DISTINCT(medicine_type1) FROM medicine");
            $row = $this->db->resultSet();
            return $row;
        }

        public function getMedicineType2($med){
            $this->db->query("SELECT DISTINCT(medicine_type2) FROM medicine
            WHERE medicine_type1= :med");
            $this->db->bind(':med', $med);
            $row = $this->db->resultSet();
            return $row;
        }

        public function getMedicineName($med){
            $this->db->query("SELECT name FROM medicine
            WHERE medicine_type2= :med");
            $this->db->bind(':med', $med);
            $row = $this->db->resultSet();
            return $row;
        }

        public function checkInvoiceNull($preid){
            $this->db->query("SELECT invoiceID FROM customer_prescription
            WHERE prescriptionID= :preid");
            $this->db->bind(':preid', $preid);
            $row = $this->db->resultSet();
            return $row;
        }

        public function addInvoice($cur_date){
            $this->db->query("INSERT INTO invoice(date_time) VALUES (:cur_date)");
            $this->db->bind(':cur_date', $cur_date);
            $row = $this->db->execute();
            if ($row) { 
                return 1;
            } else {
                return 0;
            }
        }

        public function getInvoiceNo($cur_date){
            $this->db->query("SELECT invoiceID FROM invoice
            WHERE date_time= :cur_date");
            $this->db->bind(':cur_date', $cur_date);
            $row = $this->db->resultSet();
            return $row;
        }

        public function getMedId($name){
            $this->db->query("SELECT medicineID FROM medicine
            WHERE name= :name");
            $this->db->bind(':name', $name);
            $row = $this->db->resultSet();
            return $row;
        }

        public function addmed($invid,$medid,$quan){
            $this->db->query("INSERT INTO invoice_medicine(invoiceID,medicineID,quantity) VALUES (:invid, :medid, :quan)");
            $this->db->bind(':invid', $invid);
            $this->db->bind(':medid', $medid);
            $this->db->bind(':quan', $quan);
            $row = $this->db->execute();
            if ($row) {
                return 1;
            } else {
                return 0;
            }
        }

        public function getAllmed($invid){
            $this->db->query("SELECT medicine.name,invoice_medicine.quantity  FROM invoice_medicine
            INNER JOIN medicine ON medicine.medicineID = invoice_medicine.medicineID
            WHERE invoice_medicine.invoiceID= :invid");
            $this->db->bind(':invid', $invid);
            $row = $this->db->resultSet();
            return $row;
        }

        public function updateInvid($invid,$pid){
            $this->db->query("UPDATE customer_prescription
            SET invoiceID= :invid
            WHERE prescriptionID=:pid;");
            $this->db->bind(':invid', $invid);
            $this->db->bind(':pid', $pid);
            $row = $this->db->execute();
            if ($row) {
                return 1;
            } else {
                return 0;
            }
        }

        public function checkMed($invid,$medid){
            $this->db->query("SELECT quantity FROM invoice_medicine
            WHERE medicineID = :medid
            AND invoiceID = :invid");
            $this->db->bind(':invid', $invid);
            $this->db->bind(':medid', $medid);
            $row = $this->db->resultSet();
            return $row;
        }
        

        public function updatemed($invid,$medid,$quan){
            $this->db->query("UPDATE invoice_medicine
            SET quantity= :quan
            WHERE invoiceID=:invid
            AND medicineID= :medid;");
            $this->db->bind(':invid', $invid);
            $this->db->bind(':medid', $medid);
            $this->db->bind(':quan', $quan);
            $row = $this->db->execute();
            if ($row) {
                return 1;
            } else {
                return 0;
            }
        }

        public function getQuantity($medname)
        {
            $this->db->query("SELECT quantity FROM medicine
            WHERE name = :medname");
            $this->db->bind(':medname', $medname);
            $row = $this->db->resultSet();
            return $row;
        }


        public function getDailyCompletedorders($pharmacistID)
    {
        $days = array();
        for ($i = 0; $i < 7; $i++) {
            $days[date('D', strtotime("-$i day"))] = 0;
        }
        // print_r($days);die();
        $this->db->query("SELECT COUNT(*) as count,date FROM order_details
            WHERE pharmacistID = :pharmacistID AND
            packing_status = 'completed'
            GROUP BY DAY(date)"
            );
            $this->db->bind(':pharmacistID', $pharmacistID);
            $row = $this->db->resultSet();
            // print_r($row);die();
        // If the year and month of the donation is in the array, add the count to the array
        foreach ($row as $item) {
            $day = date('D', strtotime($item->date));
            if (array_key_exists($day, $days)) {
                $days[$day] += $item->count;
            }
        }


        //Rename the key of the array to month plus year 
        $days = array_combine(array_map(function ($key) {
            return date('D', strtotime($key));
        }, array_keys($days)), array_values($days));

        //Reverse the array to show the earliest month first
        $days = array_reverse($days);
        // print_r($days);die();
        return $days;
    }

    public function getDailyCompletedprescription($pharmacistID)
    {
        $days = array();
        for ($i = 0; $i < 7; $i++) {
            $days[date('D', strtotime("-$i day"))] = 0;
        }
        // print_r($days);die();
        $this->db->query("SELECT COUNT(*) as count,date FROM customer_prescription
            WHERE pharmacistID = :pharmacistID AND
            packing_status = 'completed'
            GROUP BY DAY(date)"
            );
            $this->db->bind(':pharmacistID', $pharmacistID);
            $row = $this->db->resultSet();
            // print_r($row);die();
        // If the year and month of the donation is in the array, add the count to the array
        foreach ($row as $item) {
            $day = date('D', strtotime($item->date));
            if (array_key_exists($day, $days)) {
                $days[$day] += $item->count;
            }
        }


        //Rename the key of the array to month plus year 
        $days = array_combine(array_map(function ($key) {
            return date('D', strtotime($key));
        }, array_keys($days)), array_values($days));

        //Reverse the array to show the earliest month first
        $days = array_reverse($days);
        // print_r($days);die();
        return $days;
    }

    public function getCustomerDetails($pre_id) {
        $this->db->query("SELECT * FROM customer_prescription
        INNER JOIN users ON users.user_ID = customer_prescription.customerID
        WHERE customer_prescription.prescriptionID = :pre_id");
        $this->db->bind(':pre_id', $pre_id);
        $row = $this->db->resultSet();
        return $row;
    }

    public function getCustomername($ord_id) {
        $this->db->query("SELECT * FROM order_details
        INNER JOIN users ON users.user_ID = order_details.customerID
        WHERE order_details.orderID = :ord_id");
        $this->db->bind(':ord_id', $ord_id);
        $row = $this->db->resultSet();
        return $row;
    }

    public function get_amount($pre_id){
        $this->db->query("SELECT SUM(m.price*i.quantity) AS sub_total FROM customer_prescription cp
        JOIN invoice_medicine i ON cp.invoiceID = i.invoiceID
        JOIN medicine m on m.medicineID = i.medicineID 
        WHERE cp.prescriptionID = :pre_id
        GROUP BY i.invoiceID");
        $this->db->bind(':pre_id',$pre_id);
        $row = $this->db->resultSet();
        return $row;
    }

        

        
    }

    
    



  