<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

//Load Composer's autoloader
require '../app/vendor/autoload.php';

//MANAGER
//reminder email from manager to delivery person 
function PHP_mailer_email_reminder($order_id,$email_address,$delivery_person_name,$customer_name,$delivery_address){
    // Create a new instance of the PHPMailer class
    $mail = new PHPMailer(true);

    try {
        //Server settings
        $mail->isSMTP();                                            
        $mail->Host       = 'smtp.gmail.com';                       
        $mail->SMTPAuth   = true;                                   
        $mail->Username   = 'careU.meds@gmail.com';                     
        $mail->Password   = 'rqoisanoxkfcgbjz';                           
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;            
        $mail->Port       = 465;                                    

        //Recipients
        $mail->setFrom('careU.meds@gmail.com');
        $mail->addAddress($email_address);     //Add a recipient
        
        //Content
        $mail->isHTML(true);                              
        $mail->Subject = "Delivery Request - Order #$order_id";
        $mail->Body    = "<h2>Delivery Request - Order #$order_id</h2><br><br>"
                        ."<p>Dear $delivery_person_name,</p><br>"
                        ."<p>I am writing to request your assistance with delivering an order from careU-E-Pharmacy.</p><br>"
                        ."<p>The order details are as follows:</p>"
                        ."<ul><li>Order ID: #$order_id</li>"
                        ."<li>Customer Name: $customer_name</li>"
                        ."<li>Delivery Address: $delivery_address</li>"
                        ."<p>We kindly request that you deliver this order to the customer at your earliest convenience. If you have any questions or concerns regarding this request, please do not hesitate to contact us.</p><br>"
                        ."<p>Thank you for your continued support in providing reliable delivery services to our customers.</p><br>"
                        ."<p>Best regards,<br>
                          <p>careU E-Pharmacy</p>
                          <p>careU.meds@gmail.com</p>";

        // Send the email
        $mail->send();
        return 1;

    } catch (Exception $e) {
        echo "Email could not be sent. Mailer Error: {$mail->ErrorInfo}";
    }
}



function PHP_mailer_email_feedback_reponse($email_address,$customer_name,$feedback_type){
    // Create a new instance of the PHPMailer class
    $mail = new PHPMailer(true);

    try {
        //Server settings
        $mail->isSMTP();                                            
        $mail->Host       = 'smtp.gmail.com';                       
        $mail->SMTPAuth   = true;                                   
        $mail->Username   = 'careU.meds@gmail.com';                     
        $mail->Password   = 'rqoisanoxkfcgbjz';                           
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;            
        $mail->Port       = 465;                                    

        //Recipients
        $mail->setFrom('careU.meds@gmail.com');
        $mail->addAddress($email_address);     //Add a recipient
        

        $positive_response= "<h2>Thank You for Your Feedback</h2><br>"
                            ."<p>Dear $customer_name,</p><br>"
                            ."<p>Thank you for your recent purchase at careU E-Pharmacy, and for taking the time to provide us with your feedback. We greatly appreciate your feedback, as it helps us improve our products and services to better meet the needs of our customers.</p>"
                            ."<p>We are pleased to hear that you had a positive experience with our pharmacy, and we look forward to continuing to serve you in the future. If you have any further feedback or questions, please do not hesitate to contact us at careU.meds@gmail.com.</p>"
                            ."<p>Thank you for choosing careU E-Pharmacy for your healthcare needs.</p><br>"
                            ."<p>Best regards,<br>
                            <p>careU E-Pharmacy</p>
                            <p>careU.meds@gmail.com</p>";

        $negative_response= "<h2>Thank You for Your Feedback</h2><br>"
                            ."<p>Dear $customer_name,</p><br>"
                            ."<p>Thank you for your recent purchase at careU E-Pharmacy, and for taking the time to provide us with your feedback. We greatly appreciate your feedback, as it helps us improve our products and services to better meet the needs of our customers.</p>"
                            ."<p>We are sorry to hear that you had a bad experience with our pharmacy. Please know that we take your feedback seriously, and we are committed to making improvements to better serve our customers. We appreciate your honesty and hope to have the opportunity to make things right for you in the future. If you have any further feedback or questions, please do not hesitate to contact us at careU.meds@gmail.com.</p>"
                            ."<p>Thank you for choosing careU E-Pharmacy for your healthcare needs.</p><br>"
                            ."<p>Best regards,<br>
                            <p>careU E-Pharmacy</p>
                            <p>careU.meds@gmail.com</p>";

        //Content
        $mail->isHTML(true);                              
        $mail->Subject = "Thank You for Your Feedback - careU E-Pharmacy";
        if($feedback_type=="1"){
            $mail->Body=$positive_response; 
        }elseif($feedback_type=="0"){
            $mail->Body=$negative_response;
        }

        // Send the email
        $mail->send();
        return 1;

    } catch (Exception $e) {
        echo "Email could not be sent. Mailer Error: {$mail->ErrorInfo}";
    }
}






//STOREKEEPER
//low stock email from careU to storekeepers      
function PHP_mailer_zero_medicine($count,$emails,$ids){

    if ($count>0) {
        // Create a new instance of the PHPMailer class
        $mail = new PHPMailer(true);

        try {
            // Server settings
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';
            $mail->SMTPAuth = true;
            $mail->Username = 'careU.meds@gmail.com'; 
            $mail->Password = 'rqoisanoxkfcgbjz';
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
            $mail->Port = 465;

            // Set the sender's email address
            $mail->setFrom('careU.meds@gmail.com');

            // Loop through the email addresses and send the email to each one
            foreach ($emails as $email) {
                $email_address = $email;

                // $medicine_id = $ids;

                // Set the recipient's email address
                $mail->addAddress($email_address);

                // Set the email message
                $mail->isHTML(true);
                $ids_string = implode(',', $ids);
                $mail->Subject = "Low Stock Alert - Medicine(s) #$ids_string";

                $mail->Body =  "<h2>Low Stock Alert - Medicine(s) #$ids_string</h2><br><br>"
                              ."<p>Dear storekeeper,</p><br>"
                              ."<p>I am writing to inform you that we have detected low stock for the following medicines:</p>"
                              ."<ul><li>Medicine ID(s): $ids_string</li>"
                              ."<p>We kindly request that you take necessary action to restock the medicines at the earliest to avoid any inconvenience to our customers.</p><br>"
                              ."<p>Thank you for your continued support in ensuring our customers receive their medicines on time.</p><br>"
                              ."<p>Best regards,<br>
                              <p>careU E-Pharmacy</p>
                              <p>careU.meds@gmail.com</p>";

                // Send the email
                $mail->send();

                // Clear the recipient's email address for the next iteration of the loop
                $mail->clearAddresses();
            }
        } catch (Exception $e) {
            echo "Email could not be sent. Mailer Error: {$mail->ErrorInfo}";
        }
    }
}


//expired medicine email from careU to storekeepers      
function PHP_mailer_expired_medicine($count,$emails,$ids){

    // Check if the query returned any rows
    if ($count>0) {
        // Create a new instance of the PHPMailer class
        $mail = new PHPMailer(true);

        try {
            // Server settings
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';
            $mail->SMTPAuth = true;
            $mail->Username = 'careU.meds@gmail.com';
            $mail->Password = 'rqoisanoxkfcgbjz'; 
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
            $mail->Port = 465;

            // Set the sender's email address
            $mail->setFrom('careU.meds@gmail.com');

            // Loop through the email addresses and send the email to each one
            foreach ($emails as $email) {
                $email_address = $email;

                // $medicine_id = $ids['medicineID'];

                // Set the recipient's email address
                $mail->addAddress($email_address);

                // Set the email message
                $mail->isHTML(true);
                $ids_string = implode(',', $ids);
                $mail->Subject = "Expired Medicine Alert - Medicine(s) #$ids_string";

                $mail->Body = "<h2>Expired Medicine Alert - Medicine(s) #$ids_string</h2><br><br>"
                             ."<p>Dear Storekeeper,</p><br>"
                             ."<p>This email is to alert you that the following medicine(s) have expired:</p>"
                             ."<ul><li>Medicine ID(s): $ids_string</li></ul>"
                             ."<p>Please take immediate action to dispose of these medicines properly.</p><br>"
                             ."<p>Thank you for your attention to this matter.</p><br>"
                             ."<p>Best regards,<br>
                             <p>careU E-Pharmacy</p>
                             <p>care.meds@gmail.com</p>";

                // Send the email
                $mail->send();

                // Clear the recipient's email address for the next iteration of the loop
                $mail->clearAddresses();
            }
        } catch (Exception $e) {
            echo "Email could not be sent. Mailer Error: {$mail->ErrorInfo}";
        }
    }
}





//invoice email from careU to customer      
function PHP_mailer_invoice_details($order_id,$total_amount,$email_address){
    // Create a new instance of the PHPMailer class
    $mail = new PHPMailer(true);

    try {
        //Server settings
        $mail->isSMTP();                                            
        $mail->Host       = 'smtp.gmail.com';                       
        $mail->SMTPAuth   = true;                                   
        $mail->Username   = 'careU.meds@gmail.com';                     
        $mail->Password   = 'rqoisanoxkfcgbjz';                           
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;            
        $mail->Port       = 465;                                    

        //Recipients
        $mail->setFrom('careU.meds@gmail.com');
        $mail->addAddress($email_address);     //Add a recipient
        
        // Set the email message
        $mail->isHTML(true);
        $mail->Subject = "Invoice Details - Order #$order_id";

        $mail->Body = "<h2>Invoice Details - Order #$order_id</h2><br><br>"
                    ."<p>Dear Customer,</p><br>"
                    ."<p>Thank you for your recent order with careU E-Pharmacy. Please find your invoice details below:</p>"
                    ."<ul>"
                    ."<li>Order ID: $order_id</li>"
                    ."<li>Order Date: $order_date</li>"
                    ."<li>Total Amount: $total_amount LKR</li>"
                    ."</ul>"
                    ."<p>Please make sure to review the invoice and contact us if you have any questions or concerns.</p><br>"
                    ."<p>Thank you for your business and we look forward to serving you again soon.</p><br>"
                    ."<p>Best regards,<br>"
                    ."<p>careU E-Pharmacy</p>"
                    ."<p>care.meds@gmail.com</p>";


        // Send the email
        $mail->send();
        return 1;

    } catch (Exception $e) {
        echo "Email could not be sent. Mailer Error: {$mail->ErrorInfo}";
    }
}


?>