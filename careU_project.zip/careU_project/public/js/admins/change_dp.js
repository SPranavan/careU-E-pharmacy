// Get the file input element
const fileInput = document.getElementById('image1');

// Get the preview image element
const previewImage = document.getElementById('previewImage');

// Add an event listener to the file input
fileInput.addEventListener('change', function() {
  // Get the selected file
  const file = fileInput.files[0];

  // Check if a file is selected
  if (file) {
    // Create a FileReader object
    const reader = new FileReader();

    // Set the onload event handler
    reader.onload = function(e) {
      // Set the source of the preview image to the data URL
      previewImage.src = e.target.result;
      previewImage.style.display = 'block'; // Show the preview image
    };

    // Read the file as a data URL
    reader.readAsDataURL(file);
  } else {
    // If no file is selected, hide the preview image
    previewImage.style.display = 'none';
  }
});
