// Retrieve the flash message from the URL parameter
const urlParams = new URLSearchParams(window.location.search);
const flashMessage = urlParams.get('flashMessage');

// Display the flash message if it exists
if (flashMessage) {
    const flashMessageElement = document.createElement('div');
    flashMessageElement.className = 'flash-message';
    flashMessageElement.textContent = decodeURIComponent(flashMessage);
    document.body.appendChild(flashMessageElement);

    // Hide the flash message after 3 seconds
    setTimeout(function () {
        flashMessageElement.remove();
    }, 3000);
}