"use strict";

function initAutocomplete() {
  const inputAddress = document.getElementById("address-input");
  const inputCity = document.getElementById("city-input");

  const options = {
    componentRestrictions: { country: "lk" }, // Restrict to Sri Lanka
    fields: ["address_components", "geometry", "name"],
    types: ["geocode"],
  };

  const autocompleteAddress = new google.maps.places.Autocomplete(
    inputAddress,
    options
  );

  autocompleteAddress.addListener("place_changed", function () {
    const place = autocompleteAddress.getPlace();
    if (!place.geometry) {
      console.log("No details available for input: " + place.name);
      return;
    }
    console.log(place);

    // Extract the address components
    const addressComponents = place.address_components;
    let address = "";
    let city = "";

    // Extract the words before the city and eliminate the country
    for (const component of addressComponents) {
      if (
        component.types.includes("route") ||
        component.types.includes("neighborhood") ||
        component.types.includes("premise") ||
        component.types.includes("locality") 
        // component.types.includes("administrative_area_level_1")
      ) {
        address += component.long_name + " ";
      }
      if (
        
        component.types.includes("administrative_area_level_2")
      ) {
        city = component.long_name;
      }
    }

    // Trim trailing whitespace from address
    address = address.trim();

    // Fill the address input field with the address
    inputAddress.value = address;

    // Fill the city input field with the city and auto-fill
    inputCity.value = city;
  });
}
