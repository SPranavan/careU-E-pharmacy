function paymentgateway(){

    var xhttp=new XMLHttpRequest();
    xhttp.onreadystatechange=()=>{
        if(xhttp.readyState==4 && xhttp.status==200){
            // alert(xhttp.responseText);
            var obj=JSON.parse(xhttp.responseText);

            // Payment completed. It can be a successful failure.
            payhere.onCompleted = function onCompleted(order_id) {
                console.log("Payment completed. OrderID:" + order_id);
                window.location.replace("http://localhost/careU_project/Customers/cart_finish/");

                // Note: validate the payment and show success or failure page to the customer
            };

            // Payment window closed
            payhere.onDismissed = function onDismissed() {
                // Note: Prompt user to pay again or show an error page
                console.log("Payment dismissed");
            };

            // Error occurred
            payhere.onError = function onError(error) {
                // Note: show an error page
                console.log("Error:"  + error);
            };

            // Put the payment variables here
            var payment = {
                sandbox: true,
                merchant_id: "1222979",    // Replace your Merchant ID

                return_url: "http://localhost/careU_project/Managers/refunded_complete_orders/"+obj['order_id'],   

                cancel_url: "http://localhost/careU_project/Managers/refund/"+obj['order_id'],     

                notify_url: "http://localhost/careU_project/Managers/refunded_complete_orders/"+obj['order_id'],
                
                order_id: obj["order_id"],
                items: obj["item"],
                amount: obj["amount"],
                currency: obj["currency"],
                hash: obj["hash"], 
                first_name: obj["first_name"],
                last_name: obj["last_name"],
                email: obj["email"],
                phone: obj["phone"],
                address: obj["address"],
                city: obj["city"],
                country: "Sri Lanka",

                delivery_address: "No 18, Nelson place, Colombo 06",
                delivery_city: "Colombo",
                delivery_country: "Sri Lanka",
                custom_1: "",
                custom_2: ""
            };

            payhere.startPayment(payment);
            // window.location.href = "http://localhost/careU_project/Managers/refunded_orders/"+obj['order_id'];
        }
    };

    xhttp.open("GET","http://localhost/careU_project/customers/payhereprocess",true);
    xhttp.send();
}