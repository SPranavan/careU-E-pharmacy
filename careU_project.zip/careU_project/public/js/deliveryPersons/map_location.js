function initMap() {
  // Create a map object and specify the DOM element for display.
  var map = new google.maps.Map(document.getElementById('map'), {
    center: {lat: 37.7749, lng: -122.4194}, // Default center position (San Francisco)
    zoom: 13
  });

  // Create a DirectionsService object to use the route method and get distance/time.
  var directionsService = new google.maps.DirectionsService();

  // Create a DirectionsRenderer object to display the route.
  var directionsDisplay = new google.maps.DirectionsRenderer();

  // Bind the DirectionsRenderer to the map.
  directionsDisplay.setMap(map);

  // Add event listeners to the input fields to calculate distance and time.
  document.getElementById('origin').addEventListener('input', function() {
    calculateDistance(directionsService, directionsDisplay);
  });

  document.getElementById('destination').addEventListener('input', function() {
    calculateDistance(directionsService, directionsDisplay);
  });

  // Trigger initial calculation when the page loads.
  calculateDistance(directionsService, directionsDisplay);
}

function calculateDistance(directionsService, directionsDisplay) {
  // Get the origin and destination addresses from the input fields.
  var origin = document.getElementById('origin').value;
  var destination = document.getElementById('destination').value;

  // Create a DirectionsRequest object with the provided origin and destination.
  var request = {
    origin: origin,
    destination: destination,
    travelMode: 'DRIVING' // You can change the travel mode here
  };

  // Call the route method of the DirectionsService to calculate the distance and time.
  directionsService.route(request, function(result, status) {
    if (status == 'OK') {
      // Display the route on the map.
      directionsDisplay.setDirections(result);

      // Get the distance and duration from the result.
      var distance = result.routes[0].legs[0].distance.text;
      var duration = result.routes[0].legs[0].duration.text;

      // Display the distance and duration in the HTML.
      document.getElementById('distance').value = distance;
      document.getElementById('duration').value = duration;
    } else {
      // Display an error message if the request fails.
      window.alert('Directions request failed due to ' + status);
    }
  });
}