function paymentgateway(){

    var xhttp=new XMLHttpRequest();
    xhttp.onreadystatechange=()=>{
        if(xhttp.readyState==4 && xhttp.status==200){
            // alert(xhttp.responseText);
            var obj=JSON.parse(xhttp.responseText);

            // Payment completed. It can be a successful failure.
            payhere.onCompleted = function onCompleted(order_id) {
                console.log("Payment completed. OrderID:" + order_id);
                window.location.replace("http://localhost/careU_project/Managers/refund_completed_order/"+obj['order_id']);

                // Note: validate the payment and show success or failure page to the customer
            };

            // Payment window closed
            payhere.onDismissed = function onDismissed() {
                // Note: Prompt user to pay again or show an error page
                console.log("Payment dismissed");
            };

            // Error occurred
            payhere.onError = function onError(error) {
                // Note: show an error page
                console.log("Error:"  + error);
            };

            // Put the payment variables here
            var payment = {
                sandbox: true,
                merchant_id: "1222979",    // Replace your Merchant ID

                return_url: "http://localhost/careU_project/Managers/refunded_complete_orders/"+obj['order_id'],   

                cancel_url: "http://localhost/careU_project/Managers/refund/"+obj['order_id'],     

                notify_url: "http://localhost/careU_project/Managers/refunded_complete_orders/"+obj['order_id'],
                
                order_id: obj["order_id"],
                items: obj["item"],
                amount: obj["amount"],
                currency: obj["currency"],
                hash: obj["hash"], 
                first_name: obj["first_name"],
                last_name: obj["last_name"],
                email: obj["email"],
                phone: obj["phone"],
                address: obj["address"],
                city: obj["city"],
                country: "Sri Lanka",

                delivery_address: "No 18, Nelson place, Colombo 06",
                delivery_city: "Colombo",
                delivery_country: "Sri Lanka",
                custom_1: "",
                custom_2: ""
            };

            payhere.startPayment(payment);
            // window.location.href = "http://localhost/careU_project/Managers/refunded_orders/"+obj['order_id'];
        }
    };

    xhttp.open("GET","http://localhost/careU_project/Managers/payhereprocess",true);
    xhttp.send();
}



// function refund_paymentgateway() {
//     var xhttp = new XMLHttpRequest();
//     xhttp.onreadystatechange = () => {
//       if (xhttp.readyState == 4 && xhttp.status == 200) {
//         alert(xhttp.responseText);
//         var obj = JSON.parse(xhttp.responseText);
  
//         // Call the PayHere refund API
//         var payment_id = obj["payment_id"];
//         var amount = obj["amount"];
//         var reason = "Customer requested a refund";
//         var merchant_id = "1222979";
//         var merchant_secret = "MzExNzg4Mzc2NTE2MjMyOTc1NTA0MTk3NzUxOTcyMjY2NTQ3NTQyNw==";
//         var refund_url = "https://sandbox.payhere.lk/merchant/v1/payment/refund";
  
//         var xhttp_refund = new XMLHttpRequest();
//         xhttp_refund.onreadystatechange = () => {
//           if (xhttp_refund.readyState == 4 && xhttp_refund.status == 200) {
//             console.log("Refund completed.");
//             window.location.replace(
//               "http://localhost/careU_project/Managers/refund_completed_order/" + obj["order_id"]
//             );
//           }
//         };
//         xhttp_refund.open("POST", refund_url, true);
//         xhttp_refund.setRequestHeader(
//           "Content-Type",
//           "application/json;charset=UTF-8"
//         );
//         var auth = merchant_id + ":" + merchant_secret;
//         var encodedAuth = btoa(auth);

//         xhttp_refund.setRequestHeader(
//           "Authorization",
//           "Basic " + encodedAuth
//         );
//         var refund_data = {
//           payment_id: payment_id,
//           amount: amount,
//           reason: reason,
//         };
//         xhttp_refund.send(JSON.stringify(refund_data));
//       }
//     };
//     xhttp.open(
//       "GET",
//       "http://localhost/careU_project/Managers/payhereprocess",
//       true
//     );
//     xhttp.send();
//   }
  




// function refund_different() {

//         var payment_id = "320032340391";
//         var amount = "1000"
//         var curreny = "LKR"
//         var description = "customer needs refund"
    
//         var xhr = new XMLHttpRequest();
//         var url = "https://sandbox.payhere.lk/pay/transactions/refund";
//         var params = "payment_id=" + payment_id + "&amount=" + amount + "&currency=" + currency + "&description=" + description;
//         xhr.open("POST", url, true);
        
//         xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
        
//         xhr.onreadystatechange = function() {
//           if(xhr.readyState == 4 && xhr.status == 200) {
//             var response = JSON.parse(xhr.responseText);
//             if (response.status === "success") {
//               console.log("Refund successful.");
//             } else {
//               console.log("Refund failed: " + response.message);
//             }
//           }
//         };
        
//         xhr.send(params);
//     }




// function refund_p() {
//     // get the transaction ID and amount from the form
//     var transactionId = "320032340426";
//     var amount = "5800";
  
//     // create a new XMLHttpRequest object
//     var xhr = new XMLHttpRequest();
  
//     // set the callback function
//     xhr.onreadystatechange = function() {
//       if (xhr.readyState == 4 && xhr.status == 200) {
//         // handle the response from the server
//         var response = JSON.parse(xhr.responseText);
//         if (response.status == "success") {
//           alert("Refund successful!");
//         } else {
//           alert("Refund failed: " + response.message);
//         }
//       }
//     };
  
//     // open a new POST request
//     xhr.open("POST", "https://sandbox.payhere.lk/pay/transactions/refund", true);
  
//     // set the request headers
//     xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
  
//     // send the request with the transaction ID and amount as data
//     xhr.send("transaction_id=" + transactionId + "&amount=" + amount);
//   }
  




// window.alert = function(message, timeout=null){
//     const alert = document.createElement('div');
//     const alertButton = document.createElement('button');
//     alertButton.innerText = 'OK'; 
//     alert.classList.add('alert');
//     alert.setAttribute( 'style',` 
//         position:fixed;
//         top: 200px;
//         left: 50%;
//         padding: 20px;
//         border-radius: 2Opx;
//         box-shadow: 0 lOpx 5px 0 #00000022;
//         display:flex;
//         flex-direction:column;
//         border: 1px solid #333;
//         transform: translateX(-50%); 
//     `); 
//     alertButton.setAttribute('style',`
//         border: 1px solid #333;
//         background: white;
//         border-radius: 5px;
//         padding: 5px;
//     `); 
//     alert.innerHTML = `<span style="padding:10px">${message}</span>`; 
//     alert.appendChild(alertButton);
//     alertButton.addEventListener('click', (e)=>{ 
//         alert.remove();
//     });
//     if(timeout!=null){
//         setTimeout(()=>{
//             alert.remove();
//         },Number(timeout))
//     }
//     document.body.appendChild(alert);
// }


