const dropdown1 = document.getElementById('dropdown1');
const dropdown2 = document.getElementById('dropdown2');

const options = {
  option1: ['Option 1.1', 'Option 1.2', 'Option 1.3'],
  option2: ['Option 2.1', 'Option 2.2', 'Option 2.3'],
  option3: ['Option 3.1', 'Option 3.2', 'Option 3.3']
};

function populateDropdown2() {
  const selectedOption = dropdown1.value;
  dropdown2.innerHTML = '';
  if (selectedOption) {
    options[selectedOption].forEach(option => {
      const optionElement = document.createElement('option');
      optionElement.value = option;
      optionElement.textContent = option;
      dropdown2.appendChild(optionElement);
    });
  } else {
    const defaultOption = document.createElement('option');
    defaultOption.value = '';
    defaultOption.textContent = 'Select an option';
    dropdown2.appendChild(defaultOption);
  }
}

dropdown1.addEventListener('change', populateDropdown2);